package cn.doitedu.day13;

public class SQLHolder {

    public static String[] split(String str) {
        return str.split(";");
    }
}
