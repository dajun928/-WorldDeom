package com.cn.bds.utils

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.alibaba.fastjson.annotation.JSONField

import java.{lang, util}
import scala.beans.BeanProperty
import scala.collection.JavaConversions.asScalaBuffer
import scala.collection.{JavaConverters, mutable}

object SortUtil {
  def main(args: Array[String]): Unit = {
    val array: JSONArray = getJSONArray()
    println("voes1:" + array.toString)
    val resultStr = sort(array.toString)
    val voes2 = JSON.parseArray(resultStr,classOf[JSONArray])

    println("voes2:" + voes2)
  }

  def sort(str: String): String = {
//    val voes: util.List[Vo] = JSON.parseArray(str, classOf[Vo])
    //    val seqVo: mutable.Seq[Vo] = voes.sortBy(element => {
    //      val lastUpdateTime = element.lastUpdateTime
    //      val lastUpdateTimeLong: Long = DateTimeUtil.date2Stamp(lastUpdateTime)
    //      lastUpdateTimeLong
    //    }).reverse
    //    val voes1: lang.Iterable[Vo] = JavaConverters.asJavaIterable(seqVo)
    //    val voes2 = JavaConverters.asJavaCollection(seqVo)
    ""
  }

  def getJSONArray(): JSONArray = {
    val jsonArray = new JSONArray
    val json1 = new JSONObject
    json1.put("last_update_time", "2021-08-21 03:17:12.100")
    json1.put("id", "1")
    val json2 = new JSONObject
    json2.put("last_update_time", "2021-08-21 03:13:12.100")
    json2.put("id", "2")
    val json3 = new JSONObject
    json3.put("last_update_time", "2021-08-21 03:15:12.100")
    json3.put("id", "3")
    jsonArray.add(json1)
    jsonArray.add(json2)
    jsonArray.add(json3)
    jsonArray
  }

}


case class Vo(
               @BeanProperty @JSONField(name = "last_update_time") var lastUpdateTime: String,
               @BeanProperty @JSONField(name = "id") var id: String
             )