package com.cn.bds.ende

import org.apache.commons.codec.binary.Base64
import org.apache.logging.log4j.{LogManager, Logger}

import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.{GCMParameterSpec, SecretKeySpec}

/**
 * aes-gcm加密工具类
 *
 */
object AesGcmUtil {
  val logger: Logger = LogManager.getLogger(this.getClass)
  val KEY_ALGORITHM = "AES"
  val DEFAULT_CIPHER_ALGORITHM = "AES/GCM/PKCS5Padding"

  val GCM_TAG_LENGTH = 128
  val IV_LENGTH = 16

  def main(args: Array[String]): Unit = {
    val content = "1029804"
    val pass = "ispp2"
    //    logger.info("generateSecureBytes:{}", generateSecureBytes(16))
    //    logger.info("加密前的数据:{}", content)
    //    logger.info("加密前的数据:{}", encryptByGcm(content, pass))
    logger.info("加密前的数据:{}", decryptByGcm("aGxADwLNsiVeVO4RyClY7V0t/Xziv0VTOdUccXbrqsuLVyeTscgv", pass))

  }

  def encryptByGcm(content: String, key: String): String = {
    val input: Array[Byte] = content.getBytes(StandardCharsets.UTF_8)
    val bytes: Array[Byte] = encryptByGcm(input, key)
    Base64.encodeBase64String(bytes)
  }

  def decryptByGcm(content: String, key: String): String = {
    var resultStr = ""
    try {
      val input: Array[Byte] = Base64.decodeBase64(content)
      val decryptData: Array[Byte] = decryptByGcm(input, key)
      resultStr = new String(decryptData)
    } catch {
      case ex: Exception => {
      }
    } finally {
    }
    resultStr
  }


  def createGcm(mode: Int, key: String, iv: Array[Byte]): Cipher = {
    val cipher: Cipher = Cipher.getInstance(DEFAULT_CIPHER_ALGORITHM)
    cipher.init(mode, getKey(key), new GCMParameterSpec(GCM_TAG_LENGTH, iv))
    cipher
  }


  private def encryptByGcm(input: Array[Byte], key: String): Array[Byte] = {
    val iv: Array[Byte] = generateSecureBytes(IV_LENGTH)
    val cipher: Cipher = createGcm(Cipher.ENCRYPT_MODE, key, iv)
    val encrypted: Array[Byte] = cipher.doFinal(input)
    val data: Array[Byte] = new Array[Byte](IV_LENGTH + encrypted.length)
    System.arraycopy(iv, 0, data, 0, IV_LENGTH)
    System.arraycopy(encrypted, 0, data, IV_LENGTH, encrypted.length)
    data
  }

  private def decryptByGcm(input: Array[Byte], key: String): Array[Byte] = {
    val iv: Array[Byte] = new Array[Byte](IV_LENGTH)
    System.arraycopy(input, 0, iv, 0, IV_LENGTH)
    val cipher: Cipher = createGcm(Cipher.DECRYPT_MODE, key, iv)
    val encrypted: Array[Byte] = new Array[Byte](input.length - IV_LENGTH)
    System.arraycopy(input, IV_LENGTH, encrypted, 0, encrypted.length)
    cipher.doFinal(encrypted)
  }


  def generateSecureBytes(num: Int): Array[Byte] = {
    val bytes: Array[Byte] = new Array[Byte](num)
    new SecureRandom().nextBytes(bytes)
    bytes
  }

  def getKey(userKeyParams: String): SecretKeySpec = {
    val userKey: String = userKeyParams.trim()
    val plus: Int = 16 - userKey.length
    val data: Array[Byte] = userKey.getBytes(StandardCharsets.UTF_8)
    val raw = new Array[Byte](16)
    val plusByte: Array[Byte] = Array(0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f)
    for (i <- 0 to 15) {
      if (data.length > i) {
        raw(i) = data(i)
      } else {
        raw(i) = plusByte(plus)
      }
    }
    new SecretKeySpec(raw, KEY_ALGORITHM)
  }
}
