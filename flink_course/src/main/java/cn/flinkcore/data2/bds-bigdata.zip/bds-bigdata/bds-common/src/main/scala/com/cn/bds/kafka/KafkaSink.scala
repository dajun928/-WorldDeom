package com.cn.bds.kafka

import org.apache.kafka.clients.producer.{Callback, KafkaProducer, ProducerRecord, RecordMetadata}

import java.util.Properties
import scala.collection.mutable

class KafkaSink [K, V](createProducer: () => KafkaProducer[K, V]) extends Serializable {
  lazy val producer = createProducer()

  def sendValue(topic: String, value: V): Unit = {
    producer.send(new ProducerRecord(topic, value), new Callback {
      override def onCompletion(recordMetadata: RecordMetadata, e: Exception): Unit = {
        if (null != e) {
//          println("send data to kafka faild")
        }
      }
    })
  }

  def sendKeyValue(topic: String, key: K, value: V): Unit = {
    producer.send(new ProducerRecord(topic, key, value), new Callback {
      override def onCompletion(recordMetadata: RecordMetadata, e: Exception): Unit = {
        if (null != e) {
//          println("send data to kafka faild")
        }
      }
    })
  }

  def close(): Unit = {
    producer.close()
  }

}


object KafkaSink {

  def apply[K, V](pro: Option[Properties] = None): KafkaSink[K, V] = {
    val kafkaConfig = pro.getOrElse(null)
    apply(kafkaConfig)
  }

  def apply[K,V](kafkaConfig:Properties):KafkaSink[K, V] = {
    val kafkaSinkMap = new mutable.HashMap[String, KafkaSink[K, V]]
    val sinkName = "kafkaSinkName"
    val f = () => {
      val kafkaProducer = new KafkaProducer[K, V](kafkaConfig)
      sys.addShutdownHook {
        kafkaProducer.close()
      }
      kafkaProducer
    }

    //存在就直接返回，不走同步代码块
    if (None != kafkaSinkMap.get(sinkName)) {
      return kafkaSinkMap.getOrElse(sinkName, new KafkaSink(f))
    }
    //防止多线程
    this.synchronized {
      if (None == kafkaSinkMap.get(sinkName)) {
        kafkaSinkMap.put(sinkName, new KafkaSink(f))
      }
    }
    kafkaSinkMap.getOrElse(sinkName, new KafkaSink(f))
  }
}
