package com.cn.bds.utils

object DataCountUtil {
  def main(args: Array[String]): Unit = {
    val v1="3"
    val v2="2"
    println("res:"+divide(v1,v2,2,1))
    println("res:"+divide(v1,v2,2,2))
    println("res:"+divide(v1,v2,2,3))
    println("res:"+divide(v1,v2,2,4))
    println("res:"+divide(v1,v2,2,5))
    println("res:"+divide(v1,v2,2,6))
    println("res:"+add(v1,v2))

  }


  def divide(v1: String, v2: String, rate: Int = 2, mode: Int = java.math.BigDecimal.ROUND_HALF_UP): BigDecimal = {
    val decimalV1 = new java.math.BigDecimal(v1)
    val decimalV2 = new java.math.BigDecimal(v2)
    if (decimalV2.doubleValue() == 0) {
      new java.math.BigDecimal(0)
    } else {
      decimalV1.divide(decimalV2, rate, mode).abs()
    }
  }
  def add(v1: String, v2: String): BigDecimal = {
    val decimalV1 = new java.math.BigDecimal(v1)
    val decimalV2 = new java.math.BigDecimal(v2)
    decimalV1.add(decimalV2)
  }
}
