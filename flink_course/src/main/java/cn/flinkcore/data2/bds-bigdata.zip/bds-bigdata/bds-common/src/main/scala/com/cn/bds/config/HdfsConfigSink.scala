package com.cn.bds.config

import com.cn.bds.config.HdfsConfigSink.{confTypeSys, confTypeUser}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FSDataInputStream, FileSystem, Path}
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.SparkContext

import java.io.{ByteArrayInputStream, File}
import java.nio.charset.StandardCharsets
import java.util
import java.util.{Map, Properties}
import scala.collection.mutable

class HdfsConfigSink(getConfigMap: () => mutable.HashMap[String, Configuration]) extends Serializable {
  lazy val configMap = getConfigMap()

  def getHdfsUserConfig(): Configuration = {
    configMap.getOrElse(confTypeUser, new Configuration())
  }

  def getHdfsSysConfig(): Configuration = {
    configMap.getOrElse(confTypeSys, new Configuration())
  }


}

object HdfsConfigSink {
  val logger: Logger = LogManager.getLogger(this.getClass)
  private val sinkName = "userConfigSink"
  private val confTypeUser = "user"
  private val confTypeSys = "system"
  private val devHdfsDir = "D:\\codehub\\"
  private val proHdfsDir = "/bigdata/config/"
  private var finalHdfsDir = ""

  var configMapValue = new mutable.HashMap[String, Configuration]()
  val userConfigSinkMap = new mutable.HashMap[String, HdfsConfigSink]()

  def apply(env: String): HdfsConfigSink = {
    if (env.equalsIgnoreCase("dev")) {
      finalHdfsDir = devHdfsDir
    } else if (env.equalsIgnoreCase("beta")) {

    } else if (env.equalsIgnoreCase("prd")) {
      finalHdfsDir = proHdfsDir
    } else {
      ;
    }
    val initConf = () => {
      initUserConf()
      //      initSysConf()
    }
    //存在就返回,不走同代码块
    if (None != userConfigSinkMap.get(sinkName)) {
      return userConfigSinkMap.getOrElse(sinkName, new HdfsConfigSink(initConf))
    }
    //防止多线程
    this.synchronized {
      if (None == userConfigSinkMap.get(sinkName)) {
        userConfigSinkMap.put(sinkName, new HdfsConfigSink(initConf))
      }
    }
    userConfigSinkMap.getOrElse(sinkName, new HdfsConfigSink(initConf))
  }

  def initUserConf(): mutable.HashMap[String, Configuration] = {
    val config = new Configuration()
    config.addResource(getConfigurationFromHdfs(finalHdfsDir + "user-site.xml"))
    configMapValue += (HdfsConfigSink.confTypeUser -> config)
  }


  def initSysConf(): mutable.HashMap[String, Configuration] = {
    val config = new Configuration()
    try {
      //            config.addResource(getConfigurationFromHdfs(DEFAULT_CONFIG_FILE_DIR + "core-site.xml"))
      config.addResource(getConfigurationFromHdfs(finalHdfsDir + "hdfs-site.xml"))
      //            config.addResource(getConfigurationFromHdfs(DEFAULT_CONFIG_FILE_DIR + "hbase-site.xml"))
    } catch {
      case exception: Throwable => {
        logger.info("can not get user config,default config will be loaded:{}", exception.printStackTrace())
      }
    }
    configMapValue += (confTypeSys -> config)
  }

  def getConfigurationFromHdfs(sc: SparkContext, fileName: String, hdfsPath: String = finalHdfsDir): Configuration = {
    val config = new Configuration()
    for (content <- sc.wholeTextFiles(hdfsPath + fileName).toLocalIterator) {
      val inputStream = new ByteArrayInputStream(content._2.getBytes(StandardCharsets.UTF_8))
      config.addResource(inputStream)
    }
    config
  }

  def getConfigurationFromHdfs(config: Configuration, hdfsPath: String): FSDataInputStream = {
    FileSystem.newInstance(config).open(new Path(hdfsPath))
  }

  def getConfigurationFromHdfs(hdfsPath: String): Configuration = {
    var fs: FileSystem = null
    var in: FSDataInputStream = null
    val config = new Configuration()
    try {
      fs = FileSystem.newInstance(config)
      in = fs.open(new Path(hdfsPath))
      config.addResource(in)
    } catch {
      case ex: Exception => {
        logger.info("hdfs config path:::{}" + hdfsPath)
        logger.info("read hdfs config file Exception:::" + ex.printStackTrace())
      }
    }
    config
  }

  def getConfigurationFromLocal(fileName: String): Configuration = {
    val curLocalPath = "./" + fileName
    val execLocalPath = System.getProperty("user.dir") + "/" + fileName
    var localPath: String = null
    if (new File(curLocalPath).exists()) {
      localPath = curLocalPath
    } else if (new File(execLocalPath).exists()) {
      localPath = execLocalPath
    } else {

    }
    val config = new Configuration()
    config.addResource(new Path(new File(localPath).getAbsolutePath))
    config
  }

  def getConfigurationFromJar(fileName: String): Configuration = {
    val config = new Configuration()
    val is = getClass.getClassLoader().getResourceAsStream(fileName)
    config.addResource(is)
    config
  }

  def getConfigValue(key: String): String = {
    configMapValue.getOrElse(confTypeUser, new Configuration()).get(key, "")
  }

  //   获取配置文件  UserConfig.getConfiguration(UserConfig.confTypeUser)
  def getConfiguration(configType: String = confTypeSys): Configuration = {
    configMapValue.getOrElse(configType, new Configuration())
  }

  def convertConfig2Props(config: Configuration): Properties = {
    val props = new Properties()
    val iter: util.Iterator[Map.Entry[String, String]] = config.iterator()
    while (iter.hasNext) {
      val item: Map.Entry[String, String] = iter.next()
      props.put(item.getKey, item.getValue)
    }
    props
  }

  def convertProps2Config(props: Properties): Configuration = {
    val config = new Configuration()
    val iter = props.entrySet().iterator()
    while (iter.hasNext) {
      val entry = iter.next()
      config.set(entry.getKey.toString, entry.getValue.toString)
    }
    config
  }
}
