package com.cn.jbds.beans;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HbaseTableBean implements Serializable {

    private static final long serialVersionUID = 4770514317553165548L;
    @JSONField(name="rowkey")
    private String rowkey;

    @JSONField(name="rowkey_content")
    private String rowkeyContent;

    @JSONField(name="id")
    private String id;
}
