package com.cn.bds.ende

import com.cn.bds.utils.BaseUtil
import org.apache.commons.codec.digest.DigestUtils

import java.security.MessageDigest

object MD5Util {
  def main(args: Array[String]): Unit = {
    println(MD5("test"))
    println(MD5("testzhang"))
    println(md5Hex("testzhang").toUpperCase)

  }

  def md5Hex(text: Any*): String = {
    val sb = new StringBuffer()
    for (str <- text) {
      sb.append(BaseUtil.isEmptyAs(str))
    }
    DigestUtils.md5Hex(sb.toString)
  }

  def MD5(s: String): String = {
    val hexDigits: Array[Char] = Array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F')
    val btInput: Array[Byte] = s.getBytes
    var str: Array[Char] = null
    try {
      val mdInst: MessageDigest = MessageDigest.getInstance("MD5")
      mdInst.update(btInput)
      val md: Array[Byte] = mdInst.digest()
      val j: Int = md.length
      str = new Array[Char](j * 2)
      var k = 0
      for (i <- 0 until j) {
        val byte0: Byte = md(i)

        str(k) = hexDigits(byte0 >>> 4 & 0xf)
        k = k + 1
        str(k) = hexDigits(byte0 & 0xf)
        k = k + 1
      }
    } catch {
      case ex: Exception => {
        println(ex)
      }
    }
    str.mkString
  }

}
