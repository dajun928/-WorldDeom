package com.cn.bds.config

import com.cn.bds.utils.BdsDbUtil
import org.apache.commons.lang3.StringUtils
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.{HBaseConfiguration, HConstants}
import org.apache.kafka.clients.consumer.ConsumerConfig
import org.apache.kafka.clients.producer.ProducerConfig
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.logging.log4j.{LogManager, Logger}

import java.sql.Connection
import java.util.Properties
import scala.collection.immutable.Map

object UserConfigUtil{
  val logger: Logger = LogManager.getLogger(this.getClass)

  private val bootstrapServers: String = ProFilesUtil.getYml("kafka.bootstrap_servers")
  val ZK_ADDRESS: String = ProFilesUtil.getYml("zk.address")
  val ZK_PORT: String = ProFilesUtil.getYml("zk.port")
  // LOCAL MYSQL INFO
  val MYSQL_DRIVER: String = ProFilesUtil.getYml("mysql.driver")
  val MYSQL_LOCAL_IP: String = ProFilesUtil.getYml("mysql.local.ip")
  val MYSQL_LOCAL_PORT: Int = ProFilesUtil.getYml("mysql.local.port").toInt
  val MYSQL_LOCAL_USER = ProFilesUtil.getYml("mysql.local.user")
  val MYSQL_LOCAL_PW = ProFilesUtil.getYml("mysql.local.pw")


  def main(args: Array[String]): Unit = {

  }


  def getLocalMysqlConn(dbName: String = "test1", port: Int = MYSQL_LOCAL_PORT): Connection = {
    BdsDbUtil.getDbConn(MYSQL_LOCAL_IP, dbName, port, MYSQL_LOCAL_USER, MYSQL_LOCAL_PW)
  }


  def getlocalMysqlPro(dbName: String = "test1"): Properties = {
    val props = new Properties()
    props.setProperty("mysql.driver", MYSQL_DRIVER)
    props.setProperty("mysql.user", MYSQL_LOCAL_USER)
    props.setProperty("mysql.pw", MYSQL_LOCAL_PW)
    props.setProperty("mysql.url", BdsDbUtil.getDbUrl(MYSQL_LOCAL_IP, dbName))
    props
  }

  def getKafkaProducerParams(acks: String = "0", retries: Int = 3): Properties = {
    val pros = new Properties()
    pros.put(ProducerConfig.ACKS_CONFIG, acks)
    pros.put(ProducerConfig.RETRIES_CONFIG, retries.toString)
    pros.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer")
    pros.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer")
    pros.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers)
    pros
  }


  def getKafkaConsumerParams(groupId: String, offsetReset: String = "latest", autoCommit: java.lang.Boolean = true)
  : Properties = {
    val pro = new Properties()
    pro.put(ConsumerConfig.GROUP_ID_CONFIG, groupId)
    pro.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, offsetReset)
    pro.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, autoCommit)
    pro.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, classOf[StringDeserializer])
    pro.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, classOf[StringDeserializer])
    pro.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers)

    //    pro.put("security.protocol", "SASL_PLAINTEXT")
    //    pro.put("sasl.mechanism", "PLAIN")
    pro
  }


  def getHbaseConfig(): Configuration = {
    val config: Configuration = HBaseConfiguration.create()
    if (StringUtils.isNotEmpty(ZK_ADDRESS)) {
      logger.info("ZK_ADDRESS is: {}", ZK_ADDRESS)
      config.set("hbase.zookeeper.quorum111", ZK_ADDRESS) //填写节点
    }
    if (StringUtils.isNotEmpty(ZK_PORT)) {
      logger.info("ZK_PORT is: {}", ZK_PORT)
      config.set("hbase.zookeeper.property.clientPort", ZK_PORT) //填写节点
    }
    config.setInt("hbase.client.retries.number", 3);
    config.setInt("zookeeper.recovery.retry", 3);
    config.setInt("hbase.zookeeper.property.maxClientCnxns", 0);
    config
  }

  def getHbaseConfigbak(): Configuration = {
    val config: Configuration = HBaseConfiguration.create()
    if (StringUtils.isNotEmpty(ZK_ADDRESS)) {
      logger.info("ZK_ADDRESS is: {}", ZK_ADDRESS)
      config.set(HConstants.ZOOKEEPER_QUORUM, ZK_ADDRESS) //填写节点
    }
    if (StringUtils.isNotEmpty(ZK_PORT)) {
      logger.info("ZK_PORT is: {}", ZK_PORT)

      config.set(HConstants.ZOOKEEPER_CLIENT_PORT, ZK_PORT) //填写节点


    }
    config.setInt(HConstants.HBASE_CLIENT_RETRIES_NUMBER, 3);
    config.setInt("zookeeper.recovery.retry", 3);
    config.setInt(HConstants.ZOOKEEPER_MAX_CLIENT_CNXNS, 0);
    config
  }
  def getHbaseConfigPro(): Properties = {
    val configPro=new Properties()
    if (StringUtils.isNotEmpty(ZK_ADDRESS)) {
      logger.info("ZK_ADDRESS is: {}", ZK_ADDRESS)
      configPro.put("hbase.zookeeper.quorum", ZK_ADDRESS) //填写节点
    }
    if (StringUtils.isNotEmpty(ZK_PORT)) {
      logger.info("ZK_PORT is: {}", ZK_PORT)
      configPro.put("hbase.zookeeper.property.clientPort", ZK_PORT) //填写节点
    }
    configPro.put("hbase.client.retries.number", "3");
    configPro.put("zookeeper.recovery.retry", "3");
    configPro.put("hbase.zookeeper.property.maxClientCnxns", "0");
    configPro
  }


  def getKafkaConsumerParamsMap(groupId: String, offsetReset: String = "latest", autoCommit: java.lang.Boolean = false)
  : Map[String, Object] = {
    var map: Map[String, Object] = Map()
    map += (ConsumerConfig.GROUP_ID_CONFIG -> groupId)
    map += (ConsumerConfig.AUTO_OFFSET_RESET_CONFIG -> offsetReset)
    map += (ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG -> (autoCommit))
    map += (ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG -> classOf[StringDeserializer])
    map += (ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG -> classOf[StringDeserializer])
    map += (ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG -> bootstrapServers)
    map
  }
}
