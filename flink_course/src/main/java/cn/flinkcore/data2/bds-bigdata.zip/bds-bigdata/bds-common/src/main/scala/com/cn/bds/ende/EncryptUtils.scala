package com.cn.bds.ende

import org.apache.commons.codec.binary.Base64
import org.apache.commons.lang3.StringUtils
import sun.misc.BASE64Decoder

import javax.crypto.spec.SecretKeySpec
import javax.crypto.{Cipher, KeyGenerator}

object EncryptUtils {
  val algorithmstr = "AES/ECB/PKCS5Padding"
  val KEY = "qwertyuioplkjhgf"

  def main(args: Array[String]): Unit = {
    val content = "004567823";
    System.out.println("加密前：" + content);

    System.out.println("加密密钥和解密密钥：" + KEY);

    val encrypt = aesEncrypt(content, KEY);
    System.out.println("加密后：" + encrypt);

    val decrypt = aesDecrypt(encrypt, KEY);

    System.out.println("解密后：" + decrypt);
  }

  /**
   * base 64 encode
   *
   * @param _bytes 待编码的Array[Byte]
   * @return 编码后的base 64 code
   */
  def base64Encode(_bytes: Array[Byte]): String = Base64.encodeBase64String(_bytes)

  /**
   * base 64 decode
   *
   * @param base64Code 待解码的base 64 code
   * @return 解码后的byte[]
   * @throws Exception 抛出异常
   */
  def base64Decode(base64Code: String): Array[Byte] = {
    if (StringUtils.isEmpty(base64Code)) null else new BASE64Decoder().decodeBuffer(base64Code)
  }

  def aesEncrypt(content: String, encryptKey: String): String = {
    base64Encode(aesEncryptToBytes(content, encryptKey))
  }

  def aesDecrypt(encryptStr: String, decryptKey: String): String = {
    //    return StringUtils.isEmpty(encryptStr) ? null : aesDecryptByBytes(base64Decode(encryptStr), decryptKey);
    if (StringUtils.isEmpty(encryptStr)) {
      null
    } else {
      aesDecryptByBytes(base64Decode(encryptStr), decryptKey)
    }
  }

  def aesDecryptByBytes(encryptBytes: Array[Byte], decryptKey: String): String = {
    val cipher: Cipher = initCipher(decryptKey)
    val decryptBytes: Array[Byte] = cipher.doFinal(encryptBytes);
    new String(decryptBytes)
  }

  /**
   * AES加密
   *
   * @param content    待加密的内容
   * @param encryptKey 加密密钥
   * @return 加密后的byte[]
   */
  def aesEncryptToBytes(content: String, encryptKey: String): Array[Byte] = {
    val cipher: Cipher = initCipher(encryptKey)
    cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(encryptKey.getBytes(), "AES"))
    cipher.doFinal(content.getBytes("utf-8"))
  }

  def initCipher(key: String): Cipher = {
    val kgen: KeyGenerator = KeyGenerator.getInstance("AES")
    kgen.init(128)
    val cipher: Cipher = Cipher.getInstance(algorithmstr)
    cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key.getBytes(), "AES"))
    cipher
  }
}
