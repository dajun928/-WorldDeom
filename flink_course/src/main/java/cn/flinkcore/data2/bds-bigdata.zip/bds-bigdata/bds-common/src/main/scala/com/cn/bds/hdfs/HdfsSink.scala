package com.cn.bds.hdfs

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FSDataOutputStream, FileSystem, Path}

class HdfsSink(createFileSystem: () => FileSystem) extends Serializable {
  lazy val fileSystem = createFileSystem()

  def appendLine(filePath: String, msg: String): Unit = {
    var fsops: FSDataOutputStream = null
    if (fileSystem.exists(new Path(filePath))) {
      fileSystem.append(new Path(filePath))
    } else {
      fileSystem.create(new Path(filePath))
    }
    fsops.writeChars("\n" + msg)
    fsops.flush()
    fsops.close()
  }


  def appendLines(filePath: String, msgs: List[String]): Unit = {
    var fsops: FSDataOutputStream = null
    if (msgs.length > 0 && msgs.nonEmpty) {
      if (fileSystem.exists(new Path(filePath))) {
        fileSystem.append(new Path(filePath))
      } else {
        fileSystem.create(new Path(filePath))
      }
      msgs.foreach(msg => {
        fsops.writeChars("\n" + msg)
      })
      fsops.flush()
      fsops.close()
    }
  }

  def deleteFilePathHdfs(destFile: String, isDelete: Boolean): Boolean = {
    if (fileSystem.exists(new Path(destFile)) && isDelete) {
      fileSystem.delete(new Path(destFile), true)
    } else {
      false
    }
  }

  def move(srcFilePath: String, destFilePath: String): Unit = {
    val srcPath = new Path(srcFilePath)
    val destPath = new Path(destFilePath)
    if (fileSystem.exists(srcPath) && fileSystem.exists(destPath)) {
      fileSystem.rename(srcPath, destPath)
      fileSystem.delete(srcPath, false)
    }
  }
}

object HdfsSink {
  def apply(conn: Option[Configuration] = None): HdfsSink = {
    val f = () => {
      val fileSystemConfig = conn.getOrElse(new Configuration)
      val fs = FileSystem.get(fileSystemConfig)
      sys.addShutdownHook {
        fs.close()
      }
      fs
    }
    new HdfsSink(f)
  }
}
