package com.cn.model.utils

import com.cn.bds.model.SparkModel
import org.apache.hadoop.hbase.client.{Admin, ConnectionFactory}
import org.apache.hadoop.hbase.{HBaseConfiguration, HColumnDescriptor, HTableDescriptor, NamespaceDescriptor, TableName}
import org.apache.spark.sql.SparkSession

import java.util.Locale
import scala.collection.mutable.ArrayBuffer

object HbaseInterface {
  val hbaseDelimeter = ":"
  val defaultNameSpaces = "bds"
  val defaultFamily = "info"

  def main(args: Array[String]): Unit = {
    val sparkModel: SparkModel = new SparkModel(args, "")
    val sparkSession: SparkSession = sparkModel.getSparkSession()
    val action = sparkModel.getUserParamsVal("action", "test")
    val sparkContext = sparkSession.sparkContext
    val conf = sparkContext.getConf
    val configuration = HBaseConfiguration.create()
    val connection = ConnectionFactory.createConnection(configuration)

    val hbaseAdmin = connection.getAdmin

    if (action.equalsIgnoreCase("create")) {

    } else if (action.equalsIgnoreCase("delete")) {

    } else if (action.equalsIgnoreCase("truncate")) {

    } else if (action.equalsIgnoreCase("drop")) {

    } else {
      ;
    }

    hbaseAdmin.close()
    connection.close()
    configuration.clear()
    sparkSession.stop()
  }

  def createTable(sparkModel: SparkModel, hbaseAdmin: Admin): Unit = {
    val hbaseTables = sparkModel.getUserParamsVal("hbaseTables", "")
    val family = sparkModel.getUserParamsVal("family", defaultFamily)
    val ddl = sparkModel.getUserParamsVal("ddl", "abc")
    // 判断是否多个表
    val hbaseTableArray = hbaseTables.trim.split(",")
    hbaseTableArray.foreach(table => {
      // 组合命名空间和表名
      var resultTable = ""
      if (table.contains(hbaseDelimeter)) {
        resultTable = table
      } else {
        resultTable = defaultNameSpaces + hbaseDelimeter + table
      }
      // 切分 得到命名空间和表名
      val array = resultTable.split(hbaseDelimeter)
      val userNameSpace = array(0)
      val userHbaseTableName = array(1)

      // 判断是否存在
      var nameSpaceExists: Boolean = false
      val listNameSpace = hbaseAdmin.listNamespaceDescriptors()
      for (nameSpace <- listNameSpace if !nameSpaceExists) {
        if (userNameSpace.equals(nameSpace.getName)) {
          nameSpaceExists = true
        }
      }
      // 当不存在的时候创建 命名空间
      if (!nameSpaceExists) {
        println("namespace of hbase not exist! create new namespace:{}" + userNameSpace)
        hbaseAdmin.createNamespace(NamespaceDescriptor.create(userNameSpace).build())
      } else {

      }
      // 获取table对象
      val userHbaseTable: TableName = TableName.valueOf(resultTable)
      if (hbaseAdmin.isTableAvailable(userHbaseTable)) {
        println("hbase table not exists! create new table:{}" + resultTable)
        val tableDesc = new HTableDescriptor(userHbaseTable)
        val tableColumn = new HColumnDescriptor(family.getBytes())
        if (ddl.matches("\\d")) {
          tableColumn.setTimeToLive(String.valueOf(ddl))
        }
        tableDesc.addFamily(tableColumn)
        hbaseAdmin.createTable(tableDesc)
        println("hbase table is create" + table)
      } else {
        println("hbase table is already" + table)
      }
    })
  }

  def deleteHbaseData(): Unit = {


  }


  def truncateHbase(): Unit = {


  }

  def dropHbaseTable(): Unit = {


  }

}
