package com.cn.bds.config

import com.alibaba.fastjson.serializer.SerializerFeature
import com.alibaba.fastjson.{JSON, JSONPath}
import com.fasterxml.jackson.databind.{JsonNode, ObjectMapper}
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.logging.log4j.{LogManager, Logger}
import org.yaml.snakeyaml.Yaml

import java.io.InputStream
import java.util
import java.util.Properties

object ProFilesUtil {
  val logger: Logger = LogManager.getLogger(this.getClass)
  // properties 文件
  val properties = new Properties()

  val appInputStream: InputStream = getInputStream("application-env.properties")
  properties.load(appInputStream)
  val pomEnvFileName: String = properties.getProperty("env")
  logger.warn("pomEnvFileName is :{}", pomEnvFileName)
  // 多个文件处理 (yml目前支持一个)
  val yaml = new Yaml()
  var ymlJsonObj: JsonNode = null
  var ymlStr = "{}"

  // jsonConfig
  var jsonConfig: Config = null;


  val fileNameArr: Array[String] = pomEnvFileName.split(";")
  init(fileNameArr)

  def init(fileNameArr: Array[String]): Unit = {
    fileNameArr.foreach(singleFileName => {
      logger.warn("singleFileName is :{}", singleFileName)
      val ios: InputStream = getInputStream(singleFileName)
      // 处理加载 properties,properties文件会使用同一个 文件的数据  load完后会自动释放
      if (singleFileName.toLowerCase().contains("properties")) {
        properties.load(ios)
      } else if (singleFileName.toLowerCase().contains("yaml") || singleFileName.toLowerCase().contains("yml")) {
        // 处理加载 yaml 数据
        //            initYml(ios)    //   /a/bb
        initWithYml(ios)
      } else if (singleFileName.toLowerCase().contains("json")) {
        jsonConfig = ConfigFactory.load()
      }
    })
  }

  def get(key: String, defaultValue: String = ""): String = {
    properties.getOrDefault(key, defaultValue).toString
  }

  def set(key: String, value: String): Unit = {
    properties.put(key, value)
  }

  def getYml(userKey: String, defaultValue: String = ""): String = {
    var resultStr = defaultValue
    try {
      resultStr = JSONPath.read(ymlStr, userKey).toString
    } catch {
      case ex: Exception => {}
    } finally {
    }
    resultStr
  }

  def getJsonConfig(): Config = {
    jsonConfig
  }

  def getYml2bak(key: String)(): String = {
    var valueStr: String = ymlJsonObj.at(key).toString
    if (valueStr.startsWith(s""""""")) {
      valueStr = valueStr.substring(1, valueStr.length - 1)
    }
    if (valueStr.endsWith(s""""""")) {
      valueStr = valueStr.substring(0, valueStr.length - 1)
    }
    valueStr
  }

  def getInputStream(proFile: String): InputStream = {
    val inputStream: InputStream = ProFilesUtil.getClass()
      .getClassLoader
      .getResourceAsStream(proFile)
    inputStream
  }

  // yml 配置文件处理
  def initYml(ios: InputStream): Unit = {
    val yamlObj = yaml.loadAs(ios, classOf[Any])
    val mapper = new ObjectMapper().registerModules(DefaultScalaModule)
    val jsonString: String = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(yamlObj) // Formats YAML to a pretty printed JSON string - easy to read
    ymlJsonObj = mapper.readTree(jsonString)
  }

  def initWithYml(ios: InputStream): Unit = {
    val map: util.HashMap[String, Object] = yaml.loadAs(ios, classOf[java.util.HashMap[String, Object]])
    ymlStr = JSON.toJSONString(map, SerializerFeature.PrettyFormat)
  }

  def main(args: Array[String]): Unit = {

  }
}
