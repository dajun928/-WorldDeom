package com.cn.model.batch.spark

import com.cn.jbds.kafka.KafkaClusterEnum
import org.apache.logging.log4j.{LogManager, Logger}

object EnumDemo {
  val logger: Logger = LogManager.getLogger(this.getClass)
  val appName = "EnumDemo"
  def main(args: Array[String]): Unit = {
    val name: String = KafkaClusterEnum.getValueFrom("k22").name()


    logger.warn("name is:{}",name)
  }

}
