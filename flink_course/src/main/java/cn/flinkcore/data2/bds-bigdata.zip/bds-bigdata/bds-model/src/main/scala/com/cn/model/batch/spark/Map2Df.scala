package com.cn.model.batch.spark

import com.cn.bds.model.{DataFrameUtil, SparkModel}
import org.apache.spark.sql.{Dataset, SparkSession}

import scala.collection.mutable.ArrayBuffer

object Map2Df {
  def main(args: Array[String]): Unit = {

    val sparkModel = new SparkModel(args, "Map2Df",null )
    val session = sparkModel.getSparkSession()

//    map2Df2(session)
    session.stop()

  }


  def map2Df2(ss: SparkSession): Unit = {
    //2. 隐式转换 rdd转dataFrame
    import ss.implicits._
    //3. scala的Map数据结构
    val map = Map("aa" -> "aaa", "cc" -> "ccc", "bb" -> "bbb")
    //4. map的所有key
    val mk = map.keys
    //5. 创建rdd
    val rdd = ss.sparkContext.parallelize(Seq(map))
    //6. 根据map的key取出所有的值，构建新的rdd，并转成dataFrame
    val df = rdd.map(x => {
      val bb = new ArrayBuffer[String]()
      for (k: String <- mk) {
        bb.+=(x(k))
      }
      bb
    }).map(x => (x(0), x(1), x(2))).toDF("k1", "k2", "k3")
    df.show()

    val ds: Dataset[String] = df.toJSON
    ds.rdd.foreach(data => {
      data.toUpperCase()

    })
    ds.foreach(data => {
      val k1 = data.toUpperCase()
      println("k1:" + k1)

    })
  }
}
