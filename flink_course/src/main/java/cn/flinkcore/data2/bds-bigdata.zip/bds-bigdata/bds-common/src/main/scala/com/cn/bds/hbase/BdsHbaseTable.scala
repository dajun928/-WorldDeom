package com.cn.bds.hbase

class BdsHbaseTable {

}
