package com.cn.model.batch.rdd

import com.alibaba.fastjson.JSONObject
import com.cn.bds.model.SparkModel
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/**
 * 对比  repartition 与 coalesce 算子
 * 多变少,是窄依赖,使用 coalesce 比较好
 * 少变多,是宽依赖,使用 repartition 或者  coalesce(numPartition,true)
 */
object RddRepartition {
  val logger: Logger = LogManager.getLogger(this.getClass)
  val appName = "RddRepartitionDemo"

  def main(args: Array[String]): Unit = {
    val sm = new SparkModel(args, appName, null)
    val sparkSession: SparkSession = sm.getSparkSession()
    val sparkContext: SparkContext = sparkSession.sparkContext
    rddRepartition(sparkSession, sparkContext)
    sparkContext.stop()
    sparkSession.stop()
  }

  def rddRepartition(sparkSession: SparkSession, sparkContext: SparkContext): Unit = {
    val list = List("a")
    val rdd: RDD[String] = sparkContext.parallelize(list)
    logger.warn("rdd part:" + rdd.getNumPartitions)
    val rdd6 = rdd.coalesce(60, true)
    val rdd60 = rdd.repartition(600)
    logger.warn("rdd6 part:" + rdd6.getNumPartitions)
    logger.warn("rdd60 part:" + rdd60.getNumPartitions)
    val rdd1: RDD[((String, String), JSONObject)] = rdd60.mapPartitions(iter => {
      var map = Map[(String, String), JSONObject]()
      iter.foreach(data => {
        val json = new JSONObject()
        //        json.put("a1",null)
        //        json.put("a2","[]")
        map += (("", "1") -> json)
      })
      map.toIterator
    })

    logger.warn("rdd1 part:" + rdd1.getNumPartitions)
    rdd1.foreachPartition(iter => {

      iter.foreach(data => {
        val repoUrl = data._1._1
        val json = data._2
        logger.warn("data:" + repoUrl)
        logger.warn("data:" + json.getString("a1"))
      })

    })
  }

}
