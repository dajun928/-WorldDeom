package com.cn.bds.utils

import java.util
import scala.collection.JavaConverters

object JavaScalaTransformUtil {
  def javaMap2ScalaMap(javaMap: util.HashMap[String, String]): scala.collection.mutable.Map[String, String] = {
    val scalaMap: scala.collection.mutable.Map[String, String] = JavaConverters.mapAsScalaMapConverter(javaMap).asScala
    scalaMap
  }

  def scalaMap2JavaMap(scalaMap: scala.collection.mutable.Map[String, String]): util.Map[String, String] = {
    val javaMap: util.Map[String, String] = JavaConverters.mapAsJavaMapConverter(scalaMap).asJava
    javaMap
  }
}
