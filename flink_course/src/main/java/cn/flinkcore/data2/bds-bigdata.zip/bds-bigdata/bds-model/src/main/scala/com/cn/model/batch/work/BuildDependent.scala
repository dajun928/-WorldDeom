package com.cn.model.batch.work

import com.alibaba.fastjson.JSON
import com.alibaba.fastjson.annotation.JSONField
import com.cn.bds.ende.MD5Util
import com.cn.bds.model.SparkModel
import com.cn.bds.utils.BaseUtil
import org.apache.commons.lang3.StringUtils
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}

import java.io.{File, FileInputStream, FileOutputStream, IOException}
import java.util
import scala.beans.BeanProperty
import scala.collection.JavaConverters.asScalaBufferConverter
import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

object BuildDependent {
  val logger: Logger = LogManager.getLogger(this.getClass)
  val appName = "RddFlatMapDemo"

  def main(args: Array[String]): Unit = {
    val sm = new SparkModel(args, appName, null)
    val sparkSession: SparkSession = sm.getSparkSession()
    val sparkContext: SparkContext = sparkSession.sparkContext
    run(sparkSession, sparkContext)

    //    copyFile("F:\\src\\a.txt","F:\\dest1")
    sparkContext.stop()
    sparkSession.stop()

  }

  def run(sparkSession: SparkSession, sparkContext: SparkContext) {
    val data: String = getData()
    val resultStr: String = JSON.parseObject(data).getString("result")
    logger.warn("resultStr is :{}", resultStr)
    val javaList: util.List[BaseNodeVo] = JSON.parseArray(resultStr, classOf[BaseNodeVo])
    val scalaSeq: mutable.Seq[BaseNodeVo] = javaList.asScala
    val resultVo: mutable.Seq[BaseNodeVo] = scalaSeq.flatMap(vo => {
      val data = ArrayBuffer[BaseNodeVo]()
      generNode("", vo, data)
      data
    })
    logger.warn("resultVo size is:{}", resultVo.size)
    resultVo.foreach(vo => {
      logger.warn("data vo is:{}", vo.groupId + ":::" + vo.artifactId + ":::" + vo.version + ":::" + vo.parentId + ":::" + vo.id)
    })

    import sparkSession.implicits._
    val list=List("a")
    val rdd: RDD[String] = sparkContext.parallelize(list)



  }

  def generNode(pid: String, baseNodeVo: BaseNodeVo, data: ArrayBuffer[BaseNodeVo]): Unit = {
    if (StringUtils.isEmpty(pid) || (StringUtils.isNotEmpty(pid) && baseNodeVo.dependenies.size > 0)) {
      val nodeVo: BaseNodeVo = getNodeData(pid, baseNodeVo)
      data += nodeVo
      val id = nodeVo.getId
      logger.warn("data vo is:{}", nodeVo.groupId + ":::" + nodeVo.artifactId + ":::" + nodeVo.version + ":::" + nodeVo.parentId + ":::" + nodeVo.id + ":::" + id)
      for (elem <- baseNodeVo.dependenies) {
        logger.warn("data vo is:{}", elem.groupId + ":::" + elem.artifactId + ":::" + elem.version + ":::" + elem.parentId + ":::" + elem.id + ":::" + id)
        generNode(id, elem, data)
      }
    } else {
      val nodeVo: BaseNodeVo = getNodeData(pid, baseNodeVo)
      logger.warn("data vo is:{}", nodeVo.groupId + ":::" + nodeVo.artifactId + ":::" + nodeVo.version + ":::" + nodeVo.parentId + ":::" + nodeVo.id)
      data += nodeVo
    }
  }

  def generNodeBack(pid: String, baseNodeVo: BaseNodeVo, data: ArrayBuffer[BaseNodeVo]): Unit = {
    if (StringUtils.isEmpty(pid)) {
      val nodeVo: BaseNodeVo = getNodeData(pid, baseNodeVo)
      data += nodeVo
      val id = nodeVo.getId
      for (elem <- baseNodeVo.dependenies) {
        generNode(id, elem, data)
      }
    } else {
      if (baseNodeVo.dependenies != null && baseNodeVo.dependenies.size > 0) {
        val nodeVo: BaseNodeVo = getNodeData(pid, baseNodeVo)
        data += nodeVo
        val id = nodeVo.getId
        for (elem <- baseNodeVo.dependenies) {
          generNode(id, elem, data)
        }
      } else {
        val nodeVo: BaseNodeVo = getNodeData(pid, baseNodeVo)
        data += nodeVo
      }
    }
  }

  def getNodeData(pid: String, baseNodeVo: BaseNodeVo): BaseNodeVo = {
    val groupId = baseNodeVo.groupId
    val artifactId = baseNodeVo.artifactId
    val version = baseNodeVo.version
    val gavId = MD5Util.md5Hex(BaseUtil.concatMuilExcludeEmpty("#", groupId, artifactId, version))
    val id = MD5Util.md5Hex(BaseUtil.concatMuilExcludeEmpty("#", gavId, pid))
    BaseNodeVo(groupId, artifactId, version, gavId, baseNodeVo.dependenies, pid, id)
  }


  def getData(): String = {
    val dataStr =
      s"""
         |{
         |    "result": [
         |        {
         |            "artifact_id": "a1",
         |            "dependenies": [
         |                {
         |                    "artifact_id": "a11",
         |                    "dependenies": [],
         |                    "group_id": "g11",
         |                    "version": "v11"
         |                },
         |                {
         |                    "artifact_id": "a12",
         |                    "dependenies": [
         |                        {
         |                            "artifact_id": "a122",
         |                            "dependenies": [
         |                                {
         |                                    "artifact_id": "a1222",
         |                                    "dependenies": [],
         |                                    "group_id": "g1222",
         |                                    "version": "v1222"
         |                                }
         |                            ],
         |                            "group_id": "g122",
         |                            "version": "v122"
         |                        }
         |                    ],
         |                    "group_id": "g12",
         |                    "version": "v12"
         |                },
         |                {
         |                    "artifact_id": "a13",
         |                    "dependenies": [],
         |                    "group_id": "g13",
         |                    "version": "v13"
         |                }
         |            ],
         |            "group_id": "g1",
         |            "version": "v1"
         |        }
         |    ],
         |    "type": "maven"
         |}
         |
         |
         |
         |""".stripMargin
    dataStr
  }


}


case class BaseNodeVo(
                       @BeanProperty @JSONField(name = "group_id") var groupId: String,
                       @BeanProperty @JSONField(name = "artifact_id") artifactId: String,
                       @BeanProperty @JSONField(name = "version") var version: String,
                       @BeanProperty @JSONField(name = "gav_id") var gavId: String,
                       @BeanProperty @JSONField(name = "dependenies") var dependenies: Array[BaseNodeVo],
                       @BeanProperty @JSONField(name = "parent_id") var parentId: String,
                       @BeanProperty @JSONField(name = "id") var id: String,
                     )
