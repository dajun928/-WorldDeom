package com.cn.jbds.utils;

import com.alibaba.fastjson.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;

public class SortComparator implements Comparator<JSONObject> {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMM-dd HH:mm:ss");
    private String sortFiled;
    private String sortFiledType;
    private Boolean isAsc;

    public SortComparator(String sortFiled, String sortFiledType, Boolean isAsc) {
        this.sortFiled = sortFiled;
        this.sortFiledType = sortFiledType;
        this.isAsc = isAsc;
    }

    @Override
    public int compare(JSONObject json1, JSONObject json2) {

        String aSortItemValue = json1.getString(sortFiled);
        String bSortItemValue = json2.getString(sortFiled);

        if ("int".equalsIgnoreCase(this.sortFiledType)) {
            int aSortItemValueInt = Integer.parseInt(aSortItemValue);
            int bSortItemValueInt = Integer.parseInt(bSortItemValue);
            if (isAsc) {
                return aSortItemValueInt - bSortItemValueInt;
            } else {
                return bSortItemValueInt - aSortItemValueInt;
            }
        } else if ("datetime".equalsIgnoreCase(this.sortFiledType)) {
            Long aSortTimeLong = 0L;
            Long bSortTimeLong = 0L;
            try {

                aSortTimeLong = simpleDateFormat.parse(aSortItemValue).getTime();
                bSortTimeLong = simpleDateFormat.parse(bSortItemValue).getTime();
            } catch (ParseException parseException) {
                aSortTimeLong = 0L;
                bSortTimeLong = 0L;
                parseException.printStackTrace();
            } finally {
            }
            long diff = aSortTimeLong - bSortTimeLong;
            if (isAsc) {
                if (diff >= 0) {
                    return 1;
                } else {
                    return -1;
                }
            } else {
                if (diff >= 0) {
                    return -1;
                } else {
                    return 1;
                }
            }
        } else if ("string".equalsIgnoreCase(this.sortFiledType)) {
            if (isAsc) {
                return aSortItemValue.compareTo(bSortItemValue);
            } else {
                return bSortItemValue.compareTo(aSortItemValue);
            }
        } else {
            return 0;
        }
    }
}
