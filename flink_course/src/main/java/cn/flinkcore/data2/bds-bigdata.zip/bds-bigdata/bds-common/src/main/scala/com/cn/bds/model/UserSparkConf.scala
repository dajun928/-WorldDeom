package com.cn.bds.model

import org.apache.spark.SparkConf

object UserSparkConf {
  def getHiveConf(config: SparkConf): SparkConf = {
    config.set("hive.exec.dynamic.partition", "true")
    config.set("hive.exec.dynamic.partition.mode", "nonstrict")
    config.set("hive.exec.max.dynamic.partition", "50000")
    config.set("hive.exec.max.dynamic.partition.pernode", "5000")
    config.set("hive.input.format", "org.apache.hadoop.hive.ql.io.HiveInputFormat")
    config.set("hive.groupby.skewindata", "true")
    config.set("hive.merge.mapfiles", "true")
    config.set("hive.merge.mapredfiles", "true")
    config.set("mapreduce.input.fileinputformat.split.maxsize", "256000000")
    config.set("mapreduce.input.fileinputformat.split.minsize", "256000000")
    config.set("mapreduce.input.fileinputformat.split.minsize.per.node", "256000000")
    config.set("mapreduce.input.fileinputformat.split.minsize.per.rack", "256000000")

    config.set("hive.auto.convert.join", "false")
  }

  def getKafkaConf(config: SparkConf, siglePartNum: Int = 100): SparkConf = {
    // 确保在kill任务时，能够处理完最后一批数据，再关闭程序，不会发生强制kill导致数据处理中断，没处理完的数据丢失
    config.set("spark.streaming.stopGracefullyOnShutdown", "true")
    // 开启反压，开启后spark自动根据系统负载选择最优消费速率
    config.set("spark.streaming.backpressure.enabled", "true")
    // 开启的情况下，限制第一次批处理应该消费的数据，因为程序冷启动 队列里面有大量积压，防止第一次全部读取，造成系统阻塞
    config.set("spark.streaming.backpressure.initialRate", "1000")
    // 限制每秒每个消费线程读取每个kafka分区最大的数据量，吞吐量=该值*分区数*batchTime
    config.set("spark.streaming.kafka.maxRatePerPartition", "1000")

    config.set("spark.streaming.kafka.maxRetries", "3")
  }

  def getSqlConf(config: SparkConf): SparkConf = {
    config.set("spark.sql.adaptive.enabled", "true")
    config.set("spark.sql.adaptive.repartition.enabled", "true")
    config.set("spark.sql.adaptive.minNumPostShufflePartitions", "1")
    config.set("spark.sql.crossjoin.enabled", "true")
    config
  }

  def getSparkDynamicRes(config: SparkConf): SparkConf = {
      // 是否开启动态资源配置，根据工作负载来衡量是否应该增加或减少executor，默认false
    config.set("spark.dynamicAllocation.enabled", "false")
    config
  }
}
