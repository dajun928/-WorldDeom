package com.cn.model.batch.spark

import com.cn.bds.utils.FastJsonUtil
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

object RowToJson {
  val logger: Logger = LogManager.getLogger(this.getClass.getSimpleName);

  def main(args: Array[String]): Unit = {
    val name1 = this.getClass
    val name2 = this.getClass.getSimpleName

    logger.info("name1 is :{}", name1)
    logger.info("name2 is :{}", name2)

    val sparkConf = new SparkConf().setAppName("TestDf")
    val ss = SparkSession.builder
      .master("local[3]")
      .config(sparkConf).getOrCreate()
    //    ss.sparkContext.setLogLevel(Level.WARN.toString)
    ss.sparkContext.setLogLevel("WARN")
    val arr = Array("a,b")
    ss.udf.register("to_json", FastJsonUtil.toJson(_: String, _: Object, _: Object, _: Object))
    ss.udf.register("to_jsonArray", FastJsonUtil.toJsonArray(_: String))
    ss.udf.register("to_jsonArrayStr", FastJsonUtil.toJsonArrayStr(_: Array[String]))
    val df: DataFrame = getDf(ss).persist(StorageLevel.MEMORY_ONLY)
    df.createOrReplaceTempView("df")
    val df1 = ss.sql(
      s"""
         |select
         |a_a,
         |b_b,
         |c_c,
         |to_json("a,b,c",a_a,b_b,c_c)   as json,
         |nvl(c_c,"空")
         |from
         |df
         |where length(c_c)>0
         |""".stripMargin) // .show(false)

    df1.createOrReplaceTempView("df1")

    ss.sql(
      s"""
         |select
         |a_a,
         |b_b,
         |to_json("a,b,c",a_a,b_b,arrayStr1)   as arrayStr1,
         |to_json("a,b,c",a_a,b_b,arrayStr)   as json
         |from
         |(
         |select
         |a_a,
         |b_b,
         |to_jsonArrayStr(collect_set(json)) as arrayStr1,
         |collect_set(json) as arrayStr
         |from
         |df1
         |group by a_a,b_b
         |) aa
         |""".stripMargin)
      .show(false)

    val df3 = ss.sql(
      s"""
         |select
         |a_a,
         |b_b,
         |to_json("a,b,c_c_c",a_a,b_b,json)   as json
         |from
         |df1
         |""".stripMargin)

    val dtypes = df3.dtypes
    df3.show(false)

    println("a:" + dtypes(0))
    println("a:" + dtypes(1))
    println("a:" + dtypes(2))

    //    val voRdd: Dataset[VO] = df.mapPartitions(part => {
    //      val arrayBuffer = new ListBuffer[VO]()
    //      part.foreach(row => {
    //        val aa = row.getAs[String]("a_a")
    //        val bb: String = row.getAs[String]("b_b")
    //        val cc = row.getAs[String]("c_c")
    //        logger.info("aa is:{}", row)
    //        if (aa.equalsIgnoreCase("1")) {
    //          var vo = new VO(
    //            aa,
    //            bb,
    //            cc
    //          )
    //
    //          arrayBuffer.append(vo)
    //        }
    //
    //      })
    //      arrayBuffer.iterator
    //    })

    //    voRdd.mapPartitions(part=>{
    //      val arrayBuffer = new ListBuffer[VO]()
    //      part.foreach(vo=>{
    //        vo.
    //
    //        val vo: VO = JSON.parseObject(vo, classOf[VO])
    //
    //        arrayBuffer.append(vo.)
    //      })
    //
    //    })
    //

    //    logger.info("voRdd.count() is:{}", voRdd.count())

    ss.stop()
  }

  def getDf(ss: SparkSession): DataFrame = {
    import ss.implicits._
    val list: Seq[(String, String, String)] = List(
      ("1", "a", "c"),
      ("1", "a", "1"),
      ("1", "b", ""),
      ("2", "b", null)
    )
    ss.createDataset(list).toDF("a_a", "b_b", "c_c")
  }


  case class VO(
                 var aa: String,
                 var bb: String,
                 var cc: String
               )
}
