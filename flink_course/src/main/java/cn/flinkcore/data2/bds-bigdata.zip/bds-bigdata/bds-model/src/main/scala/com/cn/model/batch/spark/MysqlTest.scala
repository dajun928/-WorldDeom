package com.cn.model.batch.spark

import com.cn.bds.config.UserConfigUtil
import com.cn.bds.model.{DataFrameUtil, SparkModel}
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.sql.{DataFrame, SparkSession}

import java.util.Properties

object MysqlTest {
  val logger1: Logger = LogManager.getLogger(this.getClass)
  val logger2: Logger = LogManager.getLogger(this.getClass.getName)
  val logger3: Logger = LogManager.getLogger(this.getClass.getSimpleName)

  def main(args: Array[String]): Unit = {
    val sm: SparkModel = new SparkModel(args, "", null)
    val spark: SparkSession = sm.getSparkSession()
    logger1.info("init ss over:{}", "haha")
    val localPro: Properties = UserConfigUtil.getlocalMysqlPro()
    logger1.info("start to show:{}", "haha")
    val sqlStr = "select * from t_df1"
    val frame: DataFrame = DataFrameUtil.dbData2Df(spark, sqlStr, localPro)
    frame.show()
    logger1.info("over:{}", "haha")
    spark.stop()
  }
}
