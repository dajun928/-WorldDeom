package com.cn.model.batch.rdd

import com.alibaba.fastjson.{JSON, JSONObject}
import com.alibaba.fastjson.serializer.SerializerFeature
import com.cn.bds.model.SparkModel
import com.cn.bds.utils.BdsDateTimeUtil
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util.ArrayList
import scala.collection.immutable
import scala.collection.mutable.ArrayBuffer

/**
 * 使用groupbykey(惰性算子) 获取相同key值,然后按照某个字段排序获取前几名
 *
 */
object RddGroupByKey {
  val logger: Logger = LogManager.getLogger(this.getClass)
  val appName = "RddGroupBy"

  def main(args: Array[String]): Unit = {
    val sm = new SparkModel(args, appName, null)
    val sparkSession: SparkSession = sm.getSparkSession()
    val sparkContext: SparkContext = sparkSession.sparkContext
//    runGroupBy(sparkSession, sparkContext)
    runReduceByKey(sparkSession, sparkContext)
    sparkContext.stop()
    sparkSession.stop()
  }

  def runReduceByKey(sparkSession: SparkSession, sparkContext: SparkContext): Unit = {
    import sparkSession.implicits._
    val list = List(
      ("a1", "1", "1"),
      ("a1", "1", "2"),
      ("a2", "2", "2")
    )
    val rdd = sparkContext.parallelize(list).repartition(30)
    rdd.toDF().show(false)

    val rdd1: RDD[((String, String), JSONObject)] = rdd.mapPartitions(iter => {
      var map = Map[(String, String), JSONObject]()
      iter.foreach(data => {
        val key = data._1
        val value = data._2
        val value1 = data._3
        val json = new JSONObject()
        json.put("key", key)
        json.put("value", value)
        json.put("date_time", BdsDateTimeUtil.getNowDateTime("yyyy-MM-dd hh:mm:ss.ssssssss"))
        json.put("number", value1)
        map += ((key, value) -> json)
        println("=========")
      })
      map.toIterator
    })

    val rdd2: RDD[((String, String), JSONObject)] = rdd1.reduceByKey((x, y) => {
      val xNum = x.getInteger("number")
      val yNum = y.getInteger("number")
      if (xNum > yNum) {
        y
      } else {
        x
      }
    })
    rdd2.foreach(data => {
      val key = data._1
      val value = data._2
      logger.warn("kv is:{}", key + ":::" + value)
    })

    val rdd3: RDD[((String, String), JSONObject)] = rdd1.reduceByKey((x, y) => {
      val list=new ArrayList[JSONObject]()
      val json=new JSONObject()
      list.add(x)
      list.add(y)
      val arrStr: String = JSON.toJSONString(
        list,
        SerializerFeature.WriteNullStringAsEmpty,
        SerializerFeature.WriteMapNullValue,
        SerializerFeature.WriteNullListAsEmpty,
        SerializerFeature.WriteSlashAsSpecial,
        SerializerFeature.PrettyFormat
      )
      json.put("result",arrStr)
      json
    },10)

    rdd3.foreach(data => {
      val key = data._1
      val value = data._2
      logger.warn("kv is:{}", key + ":::" + value)
    })
  }

  /**
   * 获取某个字段排序,获取前几
   *
   * @param sparkSession
   * @param sparkContext
   */
  def runGroupBy(sparkSession: SparkSession, sparkContext: SparkContext): Unit = {
    import sparkSession.implicits._
    val list = List(
      ("a1", "1", "1"),
      ("a1", "1", "2"),
      ("a2", "2", "2")
    )
    val rdd = sparkContext.parallelize(list).repartition(30)
    rdd.toDF().show(false)

    val rdd1: RDD[((String, String), JSONObject)] = rdd.mapPartitions(iter => {
      var map = Map[(String, String), JSONObject]()
      iter.foreach(data => {
        val key = data._1
        val value = data._2
        val value1 = data._3
        val json = new JSONObject()
        json.put("key", key)
        json.put("value", value)
        json.put("date_time", BdsDateTimeUtil.getNowDateTime("yyyy-MM-dd hh:mm:ss.ssssssss"))
        json.put("number", value1)
        map += ((key, value) -> json)
        println("=========")
      })
      map.toIterator
    })

    logger.warn("rdd1 NumPartitions is :{}", rdd1.getNumPartitions)
    val res = rdd1.groupByKey().mapPartitions(iter => {
      var resMap = Map[(String, String), String]()
      iter.foreach(kv => {
        val key = kv._1
        val value: Iterable[JSONObject] = kv._2
        val arr: Array[JSONObject] = value.toArray.sortBy(data => {
          data.getString("number")
        }).reverse
        val json: JSONObject = value.toArray.sortBy(data => {
          data.getString("number")
        }).reverse.head
        val arrStr: String = JSON.toJSONString(
          json,
          SerializerFeature.WriteNullStringAsEmpty,
          SerializerFeature.WriteMapNullValue,
          SerializerFeature.WriteNullListAsEmpty,
          SerializerFeature.WriteSlashAsSpecial,
          SerializerFeature.PrettyFormat
        )
        resMap += (key -> arrStr)
      })
      resMap.toIterator
    })
    logger.warn("res NumPartitions is :{}", res.getNumPartitions)
    res.foreach(kv => {
      val key = kv._1
      val value = kv._2
      logger.warn("key is:{}", key)
      logger.warn("value is:{}", value)
    })
  }
}
