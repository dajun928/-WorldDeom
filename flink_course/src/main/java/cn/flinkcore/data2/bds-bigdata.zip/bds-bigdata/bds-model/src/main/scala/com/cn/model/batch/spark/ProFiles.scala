package com.cn.model.batch.spark

import com.cn.bds.config.ProFilesUtil
import com.cn.bds.model.SparkModel
import org.apache.logging.log4j.{LogManager, Logger}

object ProFiles {
  val logger: Logger = LogManager.getLogger(this.getClass)

  def main(args: Array[String]): Unit = {
    //    val api = ProFilesUtil.getJsonConfig().getString("api")
    //    println("api:" + api)
    val sparkModel = new SparkModel()
    val sparkSession = sparkModel.getSparkSession()

    testPro
    testYml
    sparkSession.stop()
  }


  def testPro(): Unit = {
    //    println("s:" + ProFilesUtil.get("env"))
    logger.info("env is:{}", ProFilesUtil.get("env"))
    logger.info("app.id is:{}", ProFilesUtil.get("app.id"))
    logger.info("app.name is:{}", ProFilesUtil.get("app.name"))
    logger.info("mysql.user is:{}", ProFilesUtil.get("mysql.user"))
    logger.info("mysql.pw is:{}", ProFilesUtil.get("mysql.pw"))
    logger.info("mysql.driver is:{}", ProFilesUtil.get("mysql.driver"))
    logger.info("kafka.offset.table is:{}", ProFilesUtil.get("kafka.offset.table"))
    logger.info("zk.address is:{}", ProFilesUtil.get("zk.address"))
    logger.info("zk.port is:{}", ProFilesUtil.get("zk.port"))
    logger.info("aa.port is:{}", ProFilesUtil.get("aa.port"))
  }

  def testYml(): Unit = {
    logger.info("env is:{}", ProFilesUtil.getYml("env"))
    logger.info("env1 is:{}", ProFilesUtil.getYml("env1"))
    logger.info("mysql.driver is:{}", ProFilesUtil.getYml("mysql.driver"))
    logger.info("app.zxz is:{}", ProFilesUtil.getYml("app.zxza"))
    logger.info("test is:{}", ProFilesUtil.getYml("test"))
    logger.info("kafka.offset.table is:{}", ProFilesUtil.getYml("kafka.offset_table"))
  }

}
