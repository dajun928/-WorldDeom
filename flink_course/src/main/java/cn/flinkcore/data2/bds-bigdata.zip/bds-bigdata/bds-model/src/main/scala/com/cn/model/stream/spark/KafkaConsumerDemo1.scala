package com.cn.model.stream.spark

import com.alibaba.fastjson.annotation.JSONField
import com.alibaba.fastjson.{JSON, JSONValidator}
import com.cn.bds.config.UserConfigUtil
import com.cn.bds.model.{DataFrameUtil, SparkModel}
import com.cn.bds.utils.{BaseUtil, BdsDateTimeUtil, BdsDbUtil}
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.TopicPartition
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.{CanCommitOffsets, HasOffsetRanges, KafkaUtils, OffsetRange}

import java.sql.Connection
import java.util.Properties
import scala.beans.BeanProperty
import scala.collection._
import scala.collection.mutable.{ArrayBuffer, ListBuffer}

object KafkaConsumerDemo1 {
  val logger: Logger = LogManager.getLogger(this.getClass)

  def main(args: Array[String]): Unit = {
    val sm: SparkModel = new SparkModel(args, "",null)
    val spark: SparkSession = sm.getSparkSession()
    import spark.implicits._
    val ssc: StreamingContext = sm.getStreamingContext(spark.sparkContext)
    val groupId = "testzxz1106-01"
    val srcTopicName = "testzxz"
    val topicSet = Set(srcTopicName)
    val localMysqlPro: Properties = UserConfigUtil.getlocalMysqlPro()

    val kafkaParams: Map[String, Object] = UserConfigUtil.getKafkaConsumerParamsMap(groupId) // earliest
    val inputDStream: InputDStream[ConsumerRecord[String, String]] = KafkaUtils.createDirectStream(ssc, PreferConsistent, Subscribe[String, String](topicSet, kafkaParams))

    // structType 定义
    val schemaStr = "id,name,age"
    val fields: Array[StructField] = schemaStr.split(",").map(filedName => StructField(filedName, StringType, nullable = true))
    val structType: StructType = StructType(fields)

    val emptyDataFrame: DataFrame = spark.emptyDataFrame
    val currentTime: Long = System.currentTimeMillis()

    var df1 = emptyDataFrame
    var df1CurrentTime = currentTime
    val initIsUpdate = false
    logger.info("time1 is :{}", BdsDateTimeUtil.getNowDateTime())


    val df1InsertSql: String = getDf1InsertSql()
    logger.info("df1InsertSql is :{}", df1InsertSql)

    inputDStream.foreachRDD(rdd => {
      // TODO 加上定时读取mysql或者hbase表数据，然后广播变量
      val df1Tuple: (DataFrame, Long, Boolean) = sm.getDbData2DfByTime(spark, "select * from t_df1", localMysqlPro,
        (df1, df1CurrentTime, initIsUpdate), 8)

      df1 = df1Tuple._1
      df1CurrentTime = df1Tuple._2
      val df1IsUpdate = df1Tuple._3
      //      df1.show(false)
      //      logger.info("df1IsUpdate is :{}", df1IsUpdate)
      //      logger.info("time22 is :{}", DateTimeUtil.getNowDateTime())

      // 过滤非json的数据
      val validRddTmp = rdd.filter(record => JSONValidator.from(record.value).validate()).map(record => record.value)

      if (!validRddTmp.isEmpty()) {
        println("validRddTmp:" + validRddTmp.count())
        val validRdd: RDD[String] = validRddTmp

        // vo类型
        val mapRddVo: RDD[AA] = validRdd.mapPartitions(part => {
          // todo 连接hbase  或者mysql数据库补充信息，过滤操作

          val array = new ArrayBuffer[AA]()
          part.foreach(row => {
            val vo: AA = JSON.parseObject(row, classOf[AA])
            val id: String = BaseUtil.isEmptyAs(vo.getId)
            var isVaildData = "N"
            if (id.toInt == 7) {
              isVaildData = "Y"
            }
            vo.setIsVaildData(isVaildData)
            array.append(vo)
          })
          // todo 关闭数据库连接信息

          // 最后返回数据
          array.toIterator
        })

        // row 类型
        val mapRddRow: RDD[Row] = validRdd.mapPartitions(part => {
          // todo 连接hbase  或者mysql数据库补充信息，过滤操作

          val array = new ArrayBuffer[Row]()
          part.foreach(row => {
            val vo: AA = JSON.parseObject(row, classOf[AA])
            val id: String = BaseUtil.isEmptyAs(vo.getId)
            val name: String = BaseUtil.isEmptyAs(vo.getName)
            var isVaildData = "N"
            if (id.toInt == 7) {
              isVaildData = "Y"
            }
            vo.setIsVaildData(isVaildData)
            if (isVaildData.equalsIgnoreCase("Y")) {
              array.append(Row(id, name, isVaildData))
            }
          })
          // todo 关闭数据库连接信息

          // z最后返回数据
          array.toArray.iterator
        })

        // 转换df和ds操作
        val rowDf: DataFrame = spark.createDataFrame(mapRddRow, structType)
        rowDf.show(false)

        val voDf: DataFrame = spark.createDataFrame(mapRddVo)
        voDf.show(false)
        val voDs: Dataset[AA] = spark.createDataset(mapRddVo)
        voDs.show(false)


        // 最终使用action算子输出,判断是否为空

        if (!mapRddVo.isEmpty()) {
          mapRddVo.foreachPartition(part => {
            // todo  连数据库
            val localConn: Connection = UserConfigUtil.getLocalMysqlConn()
            val localPs = localConn.prepareStatement(df1InsertSql)
            localConn.setAutoCommit(false)
            val list = new ListBuffer[String]
            part.foreach(vo => {
              val id: String = vo.getId
              val name: String = vo.getName
              val isVaildData: String = vo.getIsVaildData
              println("id:" + id)
              println("name:" + name)
              //              println("isVaildData:" + isVaildData)
              list.append("aa")
              // mysql是从1开始
              localPs.setString(1, id)
              localPs.setString(2, name)
              localPs.addBatch()
            })
            // todo 关闭连接
            localPs.executeBatch()
            localConn.commit()
            BdsDbUtil.closeConnect(localPs, localConn)
          })
        }


        // 工具类直接写mysql表
        DataFrameUtil.df2Db(voDf, localMysqlPro, "t_df1")


      }

      // offset 处理,注意rdd必须是，考虑封装
      if (!rdd.isEmpty()) {
        println("rdd:" + rdd.count())
        val offsetRanges: Array[OffsetRange] = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
        for (offsetRange <- offsetRanges) {
          val topic: String = offsetRange.topic
          val partition: Int = offsetRange.partition
          val offset: Long = offsetRange.fromOffset
          val topicPartition: TopicPartition = offsetRange.topicPartition()
          println("topic:" + topic)
          println("partition:" + partition)
          println("offset:" + offset)
          println("topicPartition:" + topicPartition)
        }
        inputDStream.asInstanceOf[CanCommitOffsets].commitAsync(offsetRanges)
      }
    })
    ssc.start()
    ssc.awaitTermination()
  }


  def getDf1InsertSql(): String = {
    val tableName = "t_df1"
    val fieldArray = Array[String]("id", "name")
    val updateFieldArray = Array[String]("id", "name")
    BdsDbUtil.getInsertOrUpdateSql(tableName, fieldArray, Option(updateFieldArray))
  }
}

case class AA(
               @BeanProperty @JSONField(name = "a") var id: String,
               @BeanProperty @JSONField(name = "b") var name: String,
               @BeanProperty @JSONField(name = "isVaildData") var isVaildData: String
             )