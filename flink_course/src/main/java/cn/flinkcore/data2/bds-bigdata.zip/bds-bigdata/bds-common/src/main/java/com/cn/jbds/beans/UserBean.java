package com.cn.jbds.beans;

import java.io.Serializable;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserBean implements Serializable {

    private static final long serialVersionUID = 3632815246206730600L;

    @JSONField(name="user_name")
    private String userName;

    @JSONField(name="userVersion")
    private String userVersion;

}
