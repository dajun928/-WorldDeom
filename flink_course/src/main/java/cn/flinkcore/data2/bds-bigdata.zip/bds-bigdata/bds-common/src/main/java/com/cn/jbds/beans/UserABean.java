package com.cn.jbds.beans;

public class UserABean {

}
