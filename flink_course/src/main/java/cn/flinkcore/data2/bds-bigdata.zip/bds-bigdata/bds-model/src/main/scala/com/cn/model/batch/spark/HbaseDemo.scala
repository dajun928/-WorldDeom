package com.cn.model.batch.spark

import com.alibaba.fastjson.JSONObject
import com.cn.bds.hbase.HbaseTableSink
import com.cn.bds.model.SparkModel
import org.apache.hadoop.hbase.client.Table
import org.apache.logging.log4j.{LogManager, Logger}

import java.nio.charset.StandardCharsets
import scala.collection.mutable.ListBuffer

object HbaseDemo {
  val logger: Logger = LogManager.getLogger(this.getClass)

  def main(args: Array[String]): Unit = {
    val sm = new SparkModel(args, "", null)
    val userKey = "aa"
    val data: Array[Byte] = userKey.getBytes(StandardCharsets.UTF_8)
    logger.info("aa is {}", data)

    val json = new JSONObject()
    json.put("aa", "a1")
    json.put("bb", "")
    json.put("cc", null)
    logger.info("json size is:{}", json.size())




    logger.info("aa value is:{}", json.getOrDefault("aaq", "0").toString.toInt)
    //    val hbaseConfig: Configuration = UserConfigUtils.getHbaseConfig()
    //    val hbaseConfigPro: Properties = UserConfigUtils.getHbaseConfigPro()
    //    val hbaseSink2: HbaseTableSink = HbaseTableSink(hbaseConfigPro)
    //    val test1Table: Table = hbaseSink2.getTable("default:test1")
    //        createTable(hbaseSink2,"test2")
    //                insertData(hbaseSink2,test1Table)
    //        getData(hbaseSink2,test1Table)
    //
    //    scanData2(hbaseSink2, test1Table)
    //    //    deleteData(hbaseSink2, test1Table)
    //
    //    val unit: RDD[(String, Map[String, String])] = hbaseSink2.getHbaseSingleTableRdd(sm.getSparkSession().sparkContext,"test1")


    //    val offsetTable: Table = hbaseSink2.getTable("t_kafka_offset_record")
    //    scanOffsetTable(hbaseSink2, offsetTable)


  }


  def createTable(hbaseSink2: HbaseTableSink, tableName: String): Unit = {
    val isSuccess: Boolean = hbaseSink2.createTable(tableName, Array("info"))
    logger.info("isSuccess is: {}", isSuccess)
  }

  def insertData(hbaseSink2: HbaseTableSink, test1Table: Table): Unit = {
    var map1: Map[String, String] = Map()
    map1 += ("rowkey" -> "11")
    map1 += ("id" -> "11")
    map1 += ("name" -> "zxz1")
    map1 += ("age" -> "21")

    var map2: Map[String, String] = Map()
    map2 += ("rowkey" -> "12")
    map2 += ("id" -> "12")
    map2 += ("name" -> "zxz2")
    map2 += ("age" -> "21")

    var map22: Map[String, String] = Map()
    map22 += ("rowkey" -> "122")
    map22 += ("id" -> "122")
    map22 += ("name" -> "zxz22")
    map22 += ("age" -> "22")

    val listBuffer = new ListBuffer[Map[String, String]]
    listBuffer.append(map1)
    listBuffer.append(map2)
    listBuffer.append(map22)

    hbaseSink2.insertDataList(test1Table, "info", listBuffer)
    //    logger.info("isSuccess is {}",isSuccess)
  }

  def getData(hbaseSink2: HbaseTableSink, test1Table: Table): Unit = {
    //    val list = new ListBuffer[String]();
    //    list.append("11")
    //    list.append("12")
    //    //    val map: Map[String, Map[String, String]] = hbaseSink2.getDataByRowkey(hbaseSink2.getTable("test1"),"info",list.toList)
    //    val map: Map[String, Map[String, String]] = hbaseSink2.getDataByRowkey(test1Table, "info", list
    //      .toList, Option(List("age")))
    //    println("1")
    //    map.foreach(elem => {
    //      elem._2.foreach(row => {
    //        println("2")
    //        logger.info("key is: {}", row._1)
    //        logger.info("value is: {}", row._2)
    //      })
    //    })
  }

  def scanData(hbaseSink2: HbaseTableSink, test1Table: Table): Unit = {
    //    val map = hbaseSink2.scanData(test1Table, "info", Option(List("name")), Option(null), Option("12"),
    //      Option("2"), true)
    //    map.foreach(elem => {
    //      elem._2.foreach(row => {
    //        logger.info("key is {}", row._1)
    //        logger.info("value is {}", row._2)
    //      })
    //    })


  }


  //  def scanOffsetTable(hbaseSink2: HbaseTableSink, test1Table: Table): Unit ={
  //     val DEF_SEPARATOR="#"
  //     val topic="testzxz"
  //     val groupId="testzxz1119-01"
  //
  //    val initRowKey = topic + DEF_SEPARATOR + groupId + DEF_SEPARATOR
  //    val startRowValue = Option(initRowKey + "!")
  //    val endRowValue = Option(initRowKey + "~")
  //
  //    val map: Map[String, Map[String, String]] = hbaseSink2.scanData(test1Table, offset_table_family_field, Option(null), Option(null),
  //      startRow = startRowValue, endRow = endRowValue, isAutoClose = true)
  //
  //    println("mapsize:"+map.size)
  //
  //    map.foreach(elem=>{
  //      val key: String = elem._1
  //      val mapValue: Map[String, String] = elem._2
  //      mapValue.foreach(row=>{
  //
  //        println("mapkey:"+row._1)
  //        println("mapvalue:"+row._2)
  //      })
  //
  //    })
  //
  //  }
  //
  //
  //  def scanData2(hbaseSink2: HbaseTableSink, test1Table: Table): Unit = {
  //
  //    val ageFilter = new SingleColumnValueFilter(Bytes.toBytes("info"), Bytes.toBytes("age"),
  //      CompareFilter.CompareOp.EQUAL, new SubstringComparator("21"))
  //
  //    val nameFilter = new SingleColumnValueFilter(Bytes.toBytes("info"), Bytes.toBytes("name"),
  //      CompareFilter.CompareOp.EQUAL, new SubstringComparator("zxz"))
  //
  //    val filterList = new FilterList
  //    // 提取rowkey以01结尾数据
  //    val rowFilter1 = new RowFilter(CompareFilter.CompareOp.EQUAL, new RegexStringComparator(".*1$"));
  //
  //    // 提取rowkey以包含201407的数据
  //    val rowFilter2 = new RowFilter(CompareFilter.CompareOp.EQUAL, new SubstringComparator("22"));
  //
  //    // 提取rowkey以123开头的数据
  //    val rowFilter3 = new RowFilter(CompareFilter.CompareOp.EQUAL, new BinaryPrefixComparator("1".getBytes()));
  //
  //    filterList.addFilter(rowFilter3)
  //    filterList.addFilter(ageFilter)
  //    filterList.addFilter(nameFilter)
  //
  //    val map = hbaseSink2.scanData(test1Table, "info", Option(null), Option(filterList), Option("10"), Option("2"),
  //      true)
  //    map.foreach(elem => {
  //      elem._2.foreach(row => {
  //        logger.info("key is :{}", row._1)
  //        logger.info("value is: {}", row._2)
  //      })
  //    })
  //  }

  def getSingleRdd(hbaseSink: HbaseTableSink): Unit = {


  }

  def deleteData(hbaseSink2: HbaseTableSink, test1Table: Table): Unit = {
    hbaseSink2.deleteDataByRowKey(test1Table, "info", List("11"), true, Option(List("name")))
  }

  def dropTable(): Unit = {

  }
}
