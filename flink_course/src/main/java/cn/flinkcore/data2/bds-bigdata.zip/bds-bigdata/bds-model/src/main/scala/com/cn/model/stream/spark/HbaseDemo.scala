package com.cn.model.stream.spark

import com.alibaba.fastjson.annotation.JSONField
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject, JSONValidator}
import com.cn.bds.config.UserConfigUtil
import com.cn.bds.kafka.BdsKafka
import com.cn.bds.model.SparkModel
import com.cn.bds.utils.{BdsDateTimeUtil, BdsDbUtil}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.client.{ConnectionFactory, Get, Put, Result, Table}
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{CellUtil, HBaseConfiguration, TableName}
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.catalyst.util.DateTimeUtils
import org.apache.spark.streaming.dstream.{DStream, InputDStream}
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent

import java.util
import java.util.UUID
import scala.beans.BeanProperty
import scala.collection.mutable.ArrayBuffer

object HbaseDemo {
  val logger: Logger = LogManager.getLogger(this.getClass)
  val appName = "HbaseDemo"
  val topicSet = Array("test_0425")
  val hbaseTableName = "bds:test_01"
  val groupId = appName + "_05192"
  // earliest latest
  val offset = "earliest"

  def main(args: Array[String]): Unit = {
    writeData2Hbase
  }


  def writeData2Hbase(): Unit = {
    val json=getData()
    println("json:"+json.toString.length)
    val config: Configuration = HBaseConfiguration.create()
    config.set("hbase.zookeeper.quorum", "192.168.1.111,192.168.1.112,192.168.1.113")
    config.set("hbase.zookeeper.property.clientPort", "2181")
    config.setInt("hbase.client.keyvalue.maxsize", 10485760*100)
    config.setInt("hbase.server.keyvalue.maxsize", 10485760*100)
    val conn = ConnectionFactory.createConnection(config)
   val table: Table = conn.getTable(TableName.valueOf("bds:test_01"))
    val put=new Put("113".getBytes())
    put.addColumn("info".getBytes, "mm".getBytes, json.toJSONString.getBytes)
    table.put(put)
    BdsDbUtil.closeConnect(table,conn)
    config.clear()
  }


  def getData(): JSONObject = {
    val uid = UUID.randomUUID()
    println("uid:" + uid)
    val array = new JSONArray()
    for (index <- 0 until 40000) {
      val json = new JSONObject()
      json.put("id1", UUID.randomUUID())
      json.put("id2", UUID.randomUUID())
      json.put("id3", UUID.randomUUID())
      json.put("id4", UUID.randomUUID())
      json.put("id5", UUID.randomUUID())
      json.put("id6", UUID.randomUUID())
      json.put("id7", UUID.randomUUID())
      json.put("id8", UUID.randomUUID())
      json.put("id9", UUID.randomUUID())
      json.put("id10", UUID.randomUUID())
      json.put("index", index)
      array.add(json)
    }
    val json = new JSONObject()
    json.put("result", array)
    json
  }

  def testKafka(args: Array[String]): Unit = {
    val sparkModel = new SparkModel(args, "HbaseDemo", null)
    val sparkSession = sparkModel.getSparkSession()
    val sparkContext = sparkSession.sparkContext
    val streamingContext = sparkModel.getStreamingContext(sparkContext)

    val kafkaParams: Map[String, Object] = UserConfigUtil.getKafkaConsumerParamsMap(groupId, offset, false)
    val inputDStream: InputDStream[ConsumerRecord[String, String]] = KafkaUtils.createDirectStream(streamingContext, PreferConsistent, Subscribe[String, String](topicSet, kafkaParams))

    val ds1: DStream[String] = inputDStream.filter(record => JSONValidator.from(record.value()).validate())
      .map(record => {
        val json: JSONObject = JSON.parseObject(record.value())
        json.put("timeStmp", record.timestamp())
        json.put("data", record.value())
        val jsonStr = json.toString
        jsonStr
      })


    val dsJson1: DStream[JSONObject] = ds1.mapPartitions(part => {
      val array = new ArrayBuffer[JSONObject]()
      part.foreach(data => {
        val json = new JSONObject()
        val vo = JSON.parseObject(data, classOf[HbaseTestVo])
        json.put("rowkey", vo.rowkey)
        json.put("name", vo.name)
        array.append(json)
      })
      array.toIterator
    })

    println("================")

    dsJson1.repartition(90).foreachRDD(rdd => {
      val a: RDD[JSONObject] = rdd
      val part_1 = rdd.getNumPartitions
      println("part 90 count:" + part_1 + "###" + rdd.count())
      println("r_1:dsJson1" + BdsDateTimeUtil.getNowDateTime())

      //      println("r_2:"+ BdsDateTimeUtil.getNowDateTime())
      //      Thread.sleep(5*1000)
      //      println("r_3:"+ BdsDateTimeUtil.getNowDateTime())
      //      Thread.sleep(5*1000)
      //      println("r_4:"+ BdsDateTimeUtil.getNowDateTime())
      //      Thread.sleep(5*1000)
      //      println("r_5:"+ BdsDateTimeUtil.getNowDateTime())

    })
    Thread.sleep(5 * 1000)


    inputDStream.foreachRDD(kafkaRdd => {
      println("r_1:inputDStream" + BdsDateTimeUtil.getNowDateTime())
      val aa: RDD[ConsumerRecord[String, String]] = kafkaRdd
      val part_1 = kafkaRdd.getNumPartitions
      println("commit:" + part_1 + "###" + BdsDateTimeUtil.getNowDateTime())
      kafkaRdd.foreachPartition(rdd => {
        rdd.foreach(data => {
          val timeStmp = data.timestamp()
          println("timeStmp:" + timeStmp)
          println("timeStmpStr:" + BdsDateTimeUtil.stamp2DateStr(timeStmp))
        })
      })
      //      bdsKafka.commitOffset(inputDStream, kafkaRdd)
    })

    streamingContext.start()
    streamingContext.awaitTermination()
  }


  def testHbasePut(args: Array[String]): Unit = {

    val sparkModel = new SparkModel(args, "HbaseDemo", null)
    val sparkSession = sparkModel.getSparkSession()
    val sparkContext = sparkSession.sparkContext
    val streamingContext = sparkModel.getStreamingContext(sparkContext)
    val config: Configuration = HBaseConfiguration.create()
    config.set("hbase.zookeeper.quorum", "192.168.1.111,192.168.1.112,192.168.1.113") //填写节点
    config.set("hbase.zookeeper.property.clientPort", "2181")
    val hBaseContext: HBaseContext = new HBaseContext(sparkContext, config)
    val kafkaParams: Map[String, Object] = UserConfigUtil.getKafkaConsumerParamsMap(groupId, offset)
    val inputDStream: InputDStream[ConsumerRecord[String, String]] = KafkaUtils.createDirectStream(streamingContext, PreferConsistent, Subscribe[String, String](topicSet, kafkaParams))
    dsPut(inputDStream, hBaseContext)
    streamingContext.start()
    streamingContext.awaitTermination()
  }

  def dsPut(inputDStream: InputDStream[ConsumerRecord[String, String]], hBaseContext: HBaseContext): Unit = {
    val dStream: DStream[String] = inputDStream.map(record => record.value()).filter(record => JSONValidator.from(record).validate())
    val dStream1: DStream[Get] = dStream.mapPartitions(part => {
      val arrayListPut = new util.ArrayList[Put]()
      val listGet = new ArrayBuffer[Get]()
      part.foreach(data => {
        val vo = JSON.parseObject(data, classOf[HbaseTestVo])
        val rowkey = vo.rowkey
        val name = vo.name
        val put = new Put(rowkey.getBytes())
        put.addColumn("info".getBytes(), "name".getBytes(), name.getBytes())
        arrayListPut.add(put)
      })
      import scala.collection.JavaConverters._
      val iterator: Iterator[Put] = arrayListPut.asScala.toIterator
      iterator
      listGet.toIterator
    })


    //        hBaseContext.streamBulkPut(dStream1, TableName.valueOf(hbaseTableName), (data:Put) => {
    //          data
    //        })


    val result: DStream[Result] = hBaseContext.streamBulkGet(TableName.valueOf(hbaseTableName), 1000
      , dStream1, (data: Get) => {
        data
      },
      (result: Result) => {
        result
      }
    )
    result.foreachRDD(rdd => {
      rdd.foreachPartition(part => {
        part.foreach(result => {
          val json = new JSONObject()
          if (result != null) {
            result.rawCells().foreach(cell => {
              val qualifier = Bytes.toString(CellUtil.cloneQualifier(cell))
              val value = Bytes.toString(CellUtil.cloneValue(cell))
              json.put(qualifier, value)
            })
            val rowKeyValue = Bytes.toString(result.getRow)
            json.put("rowkey", rowKeyValue)
          }
        })
      })
    })


  }


  case class HbaseTestVo(
                          @BeanProperty @JSONField(name = "rowkey") var rowkey: String,
                          @BeanProperty @JSONField(name = "content") var name: String
                        )

}
