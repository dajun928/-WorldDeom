package com.cn.bds.utils

import org.apache.commons.lang3.StringUtils

import scala.util.Random

object BaseUtil {
  def main(args: Array[String]): Unit = {
    val aa = concatMuilExcludeEmpty(null, "", null)
    println("aa:" + aa)
  }

  def strToInt(str: String): Int = {
    val regex = """([0-9]+)""".r
    val res = str match {
      case regex(num) => num
      case _ => "0"
    }
    val resInt = Integer.parseInt(res)
    resInt
  }

  def getFascicleName(fascicle: Int): String = fascicle match {
    case 1 => "上册"
    case 2 => "下册"
    case 3 => "全一册"
    case _ => "其他"
  }

  /**
   * 空值转换指定值
   *
   * @param any
   * @param defaultValue
   * @return
   */
  def isEmptyAs(any: Any, defaultValue: String = ""): String = {
    if (any == null || StringUtils.isEmpty(any.toString) || any.toString.equalsIgnoreCase("null")) {
      defaultValue
    } else {
      any.toString
    }
  }

  /**
   * 多个字段按指定分隔符拼接,空值不参与拼接
   *
   * @param splitStr 分隔符
   * @param valueStr 字段值
   * @return
   */
  def concatMuilExcludeEmpty(splitStr: String, valueStr: Any*): String = {
    val sbStr = new StringBuffer()
    for (valueStr <- valueStr) {
      if (StringUtils.isNotEmpty(isEmptyAs(valueStr))) {
        sbStr.append(valueStr)
        sbStr.append(splitStr)
      }
    }
    val length = sbStr.toString.length
    if (length > 0) {
      sbStr.substring(0, length - 1)
    } else {
      sbStr.toString
    }
  }

  def getRandNumberStr(bit: Int, isWhetherStartZero: Boolean = false): String = {
    val sb: StringBuilder = new StringBuilder()
    val random = new Random();
    for (i <- 0 until bit) {
      if (isWhetherStartZero) {
        sb.append(random.nextInt(10))
      } else {
        if (i == 0) {
          sb.append(random.nextInt(9) + 1)
        } else {
          sb.append(random.nextInt(10))
        }
      }
    }
    sb.toString()
  }

  def isNumber(str: String): Boolean = {
    for (i <- 0 until str.length) {
      if (!Character.isDigit(str.charAt(i))) {
        return false
      }
    }
    true
  }

}
