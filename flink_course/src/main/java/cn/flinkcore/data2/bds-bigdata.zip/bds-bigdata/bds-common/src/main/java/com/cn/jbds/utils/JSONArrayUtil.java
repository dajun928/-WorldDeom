package com.cn.jbds.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class JSONArrayUtil {
    public static JSONArray sortByTime(JSONArray jsonArray, String sortTimeName, String sortFiledType, boolean isAsc) {
        JSONArray resultJsonArray=new JSONArray();
        List<JSONObject> jsonObjectList = JSONArray.parseArray(jsonArray.toJSONString(), JSONObject.class);

        Collections.sort(jsonObjectList,new SortComparator(sortTimeName,sortFiledType,isAsc));

        for(int i=0;i<jsonObjectList.size();i++){
            resultJsonArray.add(jsonObjectList.get(i));
        }
        JSONArray sortJsonArray = JSONArray.parseArray(jsonObjectList.toString());
        return sortJsonArray;
    }

    public static JSONArray sortByTime2(JSONArray jsonArray, String sortTimeName,String sortFiledType,boolean isAsc) {
        JSONArray resultJsonArray=new JSONArray();
        List<JSONObject> jsonObjectList = JSONArray.parseArray(jsonArray.toJSONString(), JSONObject.class);
        Collections.sort(jsonObjectList, new Comparator<JSONObject>() {
            @Override
            public int compare(JSONObject json1, JSONObject json2) {
                String aSortItemValue = json1.getString(sortTimeName);
                String bSortItemValue = json2.getString(sortTimeName);
                if ("int".equalsIgnoreCase(sortFiledType)) {
                    int aSortItemValueInt = Integer.parseInt(aSortItemValue);
                    int bSortItemValueInt = Integer.parseInt(bSortItemValue);
                    if (isAsc) {
                        return aSortItemValueInt - bSortItemValueInt;
                    } else {
                        return bSortItemValueInt - aSortItemValueInt;
                    }

                } else if ("datetime".equalsIgnoreCase(sortFiledType)) {
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                    Long aSortTimeLong = 0L;
                    Long bSortTimeLong = 0L;
                    try {
                        aSortTimeLong = simpleDateFormat.parse(aSortItemValue).getTime();
                        bSortTimeLong = simpleDateFormat.parse(bSortItemValue).getTime();
                    } catch (ParseException e) {
                        e.printStackTrace();
                    } finally {
                    }
                    long diff = aSortTimeLong - bSortTimeLong;
                    System.out.println("diff==========" + diff);
                    Integer diffInt = Integer.valueOf(String.valueOf(diff));
                    if (isAsc) {
                        if (diff >= 0) {
                            return 1;
                        } else {
                            return -1;
                        }
                    } else {
                        if (diff >= 0) {
                            return -1;
                        } else {
                            return 1;
                        }
                    }
                } else {
                    return 0;
                }
            }
        });

        for(int i=0;i<jsonObjectList.size();i++){
            resultJsonArray.add(jsonObjectList.get(i));
        }
        JSONArray sortJsonArray = JSONArray.parseArray(jsonObjectList.toString());
        return sortJsonArray;
    }


    public static void main(String[] args) {
//        String timeStr = "2021-08-21 03:12:12.100";
//        String timePattern="yyyy-MM-dd HH:mm:ss.SSS";
//        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(timePattern);
//        long aTime=0L;
//        try {
//           aTime=  simpleDateFormat.parse(timeStr).getTime();
//        } catch (Exception exception){
//
//        }
//        System.out.println("aTime:"+aTime);

        String timePattern="yyyy-MM-dd HH:mm:ss.SSS";
        JSONArray jsonArray = new JSONArray();
        JSONObject json1=new JSONObject();
        json1.put("last_update_time","2021-08-21 03:17:12.100");
        json1.put("id","1");
        JSONObject json2=new JSONObject();
        json2.put("last_update_time","2021-08-21 03:13:12.100");
        json2.put("id","2");
        JSONObject json3=new JSONObject();
        json3.put("last_update_time","2021-08-21 03:15:12.100");
        json3.put("id","3");
        jsonArray.add(json1);
        jsonArray.add(json2);
        jsonArray.add(json3);

        System.out.println("排序前：" + jsonArray.toString());
        JSONArray array = sortByTime(jsonArray, "last_update_time", "datetime", true);
        System.out.println("排序后：" + array.toString());
    }
}
