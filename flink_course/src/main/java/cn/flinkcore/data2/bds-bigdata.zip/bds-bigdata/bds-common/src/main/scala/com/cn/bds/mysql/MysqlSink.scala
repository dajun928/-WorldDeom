package com.cn.bds.mysql

import com.cn.bds.config.UserConfigField
import com.cn.bds.config.UserConfigField.Mysql
import scalikejdbc.{ConnectionPool, ConnectionPoolSettings, DB, SQL, using}

import java.sql.Connection
import java.util.Properties
import scala.collection.mutable

class MysqlSink (getConnectionPool: () => ConnectionPool) extends Serializable {
  lazy val connectionPool = getConnectionPool()

  def getConnection(): Connection = {
    connectionPool.borrow()
  }

  def insert(insertSql: String, list: List[Map[String, Any]], param: String*): Unit = {
    using(DB(getConnection)) { db =>
      db.localTx { implicit Session =>
        SQL(insertSql).bind(param: _*).update().apply()
      }
    }
  }

  def query(sqlStr: String, param: String*): List[Map[String, Any]] = {
    using(DB(getConnection)) { db =>
      db.readOnly { implicit Session =>
        SQL(sqlStr).bind(param: _*).toMap().list().apply()
      }
    }
  }

  def update(sqlStr: String, param: String*): Unit = {
    using(DB(getConnection)) { db =>
      db.autoCommit { implicit Session =>
        SQL(sqlStr).bind(param: _*).update().apply()
      }
    }
  }

  def execute(sqlStr: String, param: Seq[Any]): Unit = {
    using(DB(getConnection)) { db =>
      db.autoCommit { implicit Session =>
        SQL(sqlStr).bind(param: _*).execute().apply()
      }
    }
  }

  def execute(sqlStr: String): Unit = {
    using(DB(getConnection)) { db =>
      db.autoCommit { implicit Session =>
        SQL(sqlStr).execute().apply()
      }
    }
  }

  def executeBatch(sqlStr: String, batchParams: Seq[Seq[Any]], batchSize: Int = 5000): Unit = {
    val batchNo = batchParams.size / batchSize + 1
    for (i <- 0 until batchNo) {
      using(DB(getConnection)) { db =>
        db.autoCommit { implicit Session =>
          SQL(sqlStr).batch(batchParams.slice(i * batchSize, (i + 1) * batchSize): _*).apply()
        }
      }
    }
  }

}

object MysqlSink {
  //一个库只初始化一个线程池
  val mySqlSinkMap = new mutable.HashMap[String, MysqlSink]()
  val dbName = Mysql.mysql_user_key

  def apply(pro: Properties): MysqlSink = {
    val dbUserName = pro.getOrDefault(dbName, "").toString
    println("dbUserName:"+dbUserName)
    val f = () => {
      //      SetupMySqlJdbc(pro)
      applyPro(pro)
      //TODO
      println("ffffffffffff")
      ConnectionPool(dbUserName)
      //            ConnectionPool()
    }

    //存在就返回,不走同代码块
    if (None != mySqlSinkMap.get(dbUserName)) {
      return mySqlSinkMap.getOrElse(dbUserName, new MysqlSink(f))
    }
    //防止多线程
    this.synchronized {
      if (None == mySqlSinkMap.get(dbUserName)) {
        mySqlSinkMap.put(dbUserName, new MysqlSink(f))
      }
    }
    mySqlSinkMap.getOrElse(dbUserName, new MysqlSink(f))
  }


  def apply(driver: String, url: String, user: String, pw: String): Unit = {
    init(driver, url, user, pw)
  }

  def applyPro(pro: Properties): Unit = {
    val driver = pro.getProperty(UserConfigField.Mysql.mysql_driver_key)
    val url = pro.getProperty(UserConfigField.Mysql.mysql_url_key)
    val user = pro.getProperty(UserConfigField.Mysql.mysql_user_key)
    val password = pro.getProperty(UserConfigField.Mysql.mysql_pw_key)

    //    val Array(driver_a, url_a, user_a, password_a) = Array(
    //      jdbcConfig.getProperty("mysql.driver"),
    //      jdbcConfig.getProperty("mysql.url"),
    //      jdbcConfig.getProperty("mysql.user"),
    //      jdbcConfig.getProperty("mysql.pw")
    //    )
    init(driver, url, user, password)
  }

  def init(driver: String, url: String, user: String, pw: String): Unit = {
    Class.forName(driver)
    val settings = ConnectionPoolSettings(
      initialSize = 10,
      maxSize = 20,
      connectionTimeoutMillis = 3000L
    )
    //单个库
    //    ConnectionPool.singleton(url, user, pw, settings)
    //多个库
    ConnectionPool.add(user, url, user, pw, settings)
  }
}
