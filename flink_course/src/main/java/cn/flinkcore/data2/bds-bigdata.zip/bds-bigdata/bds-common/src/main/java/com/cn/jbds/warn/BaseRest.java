package com.cn.jbds.warn;

import java.io.Serializable;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BaseRest implements Serializable {

    private static final long serialVersionUID = -7871639549749742173L;
    @JSONField(name="warn_id")
    private String warnId;


    @JSONField(name="warn_time")
    private String warnTime;

    public String getWarnId() {
        return warnId;
    }

    public void setWarnId(String warnId) {
        this.warnId = warnId;
    }

    public String getWarnTime() {
        return warnTime;
    }

    public void setWarnTime(String warnTime) {
        this.warnTime = warnTime;
    }
}
