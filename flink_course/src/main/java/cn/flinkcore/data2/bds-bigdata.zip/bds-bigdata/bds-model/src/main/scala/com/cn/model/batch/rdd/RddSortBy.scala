package com.cn.model.batch.rdd

import com.cn.bds.model.SparkModel
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}

object RddSortBy {
  val logger: Logger = LogManager.getLogger(this.getClass)
  val appName = "RddReduceByKey"

  def main(args: Array[String]): Unit = {
    val sm = new SparkModel(args, appName, null)
    val sparkSession: SparkSession = sm.getSparkSession()
    val sparkContext: SparkContext = sparkSession.sparkContext
    sortBy(sparkSession, sparkContext)
    sparkContext.stop()
    sparkSession.stop()
  }

  def sortBy(sparkSession: SparkSession, sparkContext: SparkContext): Unit = {
    import sparkSession.implicits._
    val rdd = getData(sparkContext)
    rdd.toDF().show(false)
    logger.warn("rdd numPartitions is:{}", rdd.getNumPartitions)

  val rdd1=  rdd.sortBy(data=>{
      val key = data._1
    (key.toInt,data._2.toInt)
    },false,1)

    rdd1.repartition(1).foreach(data=>{
      logger.warn("data is:{}",data)
    })
    logger.warn("**********************")
    rdd.sortBy(data=>{
      val key = data._1
      key.toInt
    },false,3)foreach(data=>{
      logger.warn("data is:{}",data)
    })

  }

  def getData(sparkContext: SparkContext): RDD[(String, String)] = {
    // 数据表示:  类目id,商品id
    val list = List(
      ("1", "11"),
      ("1", "11"),
      ("2", "21"),
      ("2", "22"),
      ("2", "22"),
      ("3", "31")
    )
    val rdd: RDD[(String, String)] = sparkContext.parallelize(list, 3)
    rdd
  }

}
