package com.cn.model.batch.spark

import com.typesafe.config.ConfigFactory

object Typesafe {
  def main(args: Array[String]): Unit = {
    val jsonConfig = ConfigFactory.load()
    val str = jsonConfig.getString("api")
    println("str:" + str)
  }

}
