package com.cn.model.batch.spark

import com.cn.bds.utils.BuildSendWarning

object WarnInfo {

  def main(args: Array[String]): Unit = {
    val aa: BuildSendWarning.Builder = BuildSendWarning.builder().setWarningId("111").setWarningTime("today")
    //  .setWarningPeople("wo")


    aa.sendWarningToKafka("aa", null)
  }

}
