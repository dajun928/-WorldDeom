package com.cn.bds.hbase

import com.alibaba.fastjson.JSONObject
import com.cn.bds.utils.BdsDbUtil
import org.apache.commons.lang3.StringUtils
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.client._
import org.apache.hadoop.hbase.filter._
import org.apache.hadoop.hbase.io.ImmutableBytesWritable
import org.apache.hadoop.hbase.mapreduce.{MultiTableInputFormat, TableInputFormat}
import org.apache.hadoop.hbase.protobuf.ProtobufUtil
import org.apache.hadoop.hbase.protobuf.generated.ClientProtos
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase._
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD

import java.util
import java.util.Properties
import scala.collection.mutable.ListBuffer

class HbaseTableSink (createConnection: () => (Configuration, Connection)) extends Serializable {
    val logger: Logger = LogManager.getLogger(this.getClass)
    lazy val (hbaseConfig, conn) = createConnection()

    def getTable(tableName: String): Table = {
      conn.getTable(TableName.valueOf(tableName))
    }

    /**
     *
     * @param tabName
     * @param colFamily
     * @return
     */
    def createTable(tabName: String, colFamily: Array[String], isAutoClose: Boolean = true): Boolean = {
      val admin = conn.getAdmin()
      val userTable: TableName = TableName.valueOf(tabName)
      val tableDescr: HTableDescriptor = new HTableDescriptor(userTable)
      for (col <- colFamily) {
        tableDescr.addFamily(new HColumnDescriptor(col))
      }
      val isSuccess = if (admin.tableExists(userTable)) {
        false
      } else {
        admin.createTable(tableDescr)
        true
      }
      if (isAutoClose) {
        BdsDbUtil.closeConnect(conn)
      }
      isSuccess
    }

    def reCreateTable(tabName: String, colFamily: Array[String], isAutoClose: Boolean = true): Unit = {
      val admin = conn.getAdmin()
      val userTable = TableName.valueOf(tabName)
      val tableDescr = new HTableDescriptor(userTable)
      for (col <- colFamily) {
        tableDescr.addFamily(new HColumnDescriptor(col.getBytes()))
      }
      if (admin.tableExists(userTable)) {
        admin.disableTable(userTable)
        admin.deleteTable(userTable)
      }
      admin.createTable(tableDescr)
      if (isAutoClose) {
        BdsDbUtil.closeConnect(conn)
      }
    }

    def insertDataList(table: Table, family: String, dataListBuffer: ListBuffer[Map[String, String]], isAutoClose: Boolean = true): Unit = {
      val listPut = new util.ArrayList[Put]()
      dataListBuffer.foreach(dataMap => {
        if (dataMap.contains("rowkey")) {
          val rowKey: String = dataMap.getOrElse("rowkey", "")
          var put = new Put(rowKey.getBytes)
          put = map2Hbase(put, family, dataMap)
          listPut.add(put)
        } else {
          throw new IllegalArgumentException
        }
      })
      table.put(listPut)
      if (isAutoClose) {
        BdsDbUtil.closeConnect(table, conn)
      }
    }

    def insertDataMap(table: Table, family: String, dataMap: Map[String, Map[String, String]], isAutoClose: Boolean = true): Unit = {
      val listPut = new util.ArrayList[Put]()
      dataMap.foreach(data => {
        val rowKey: String = data._1
        val map: Map[String, String] = data._2
        var put = new Put(rowKey.getBytes)
        put = map2Hbase(put, family, map)
        listPut.add(put)
      })
      table.put(listPut)
      if (isAutoClose) {
        BdsDbUtil.closeConnect(table, conn)
      }
    }

    private def map2Hbase(put: Put, family: String, dataMap: Map[String, String]): Put = {
      dataMap.foreach(data => {
        val key: String = data._1
        val value: String = data._2
        if (!key.equalsIgnoreCase("rowkey")) {
          put.addColumn(family.getBytes, key.getBytes, value.getBytes)
        }
      })
      put
    }

    def getDataByRowkey(table: Table, family: String, rowkey: List[String], qualifiers: Option[List[String]] = None,
                        filterList: Option[FilterList] = None, isAutoClose: Boolean = true): Map[String, Map[String, String]] = {
      val filter = filterList.getOrElse(null)
      var rowkeyGet: Get = null
      val listGet = new util.ArrayList[Get]()
      rowkey.foreach(rowkey => {
        rowkeyGet = new Get(rowkey.getBytes())
        if (filter != null) {
          rowkeyGet.setFilter(filter)
        }
        listGet.add(addFamilyAndQualifiers(rowkeyGet, family, qualifiers).asInstanceOf[Get])
      })
      getHbaseResult2Map(table, listGet, isAutoClose)
    }

    def scanData(table: Table, family: String, qulifiers: Option[List[String]] = None, filterList: Option[FilterList] = None,
                 startRow: Option[String] = None, endRow: Option[String] = None, isAutoClose: Boolean = true): Map[String, Map[String, String]] = {
      val scan = new Scan()
      val qulifierList: List[String] = qulifiers.getOrElse(null)
      if (qulifierList != null && !qulifierList.isEmpty) {
        qulifierList.foreach(item => {
          scan.addColumn(family.getBytes, item.getBytes())
        })
      } else {
        scan.addFamily(family.getBytes)
      }

      if (filterList.getOrElse(null) != null) {
        scan.setFilter(filterList.getOrElse(null))
      }
      if (StringUtils.isNotEmpty(startRow.getOrElse(""))) {
        scan.setStartRow(Bytes.toBytes(startRow.getOrElse("")))
      }
      if (StringUtils.isNotEmpty(endRow.getOrElse(""))) {
        scan.setStopRow(Bytes.toBytes(endRow.getOrElse("")))
      }
      getHbaseResult2Map(table, scan, isAutoClose)
    }

    def getDataWithColRange(table: Table, family: String, column: List[String], rowkey: List[String], start: String, end: String): Map[String, Map[String, String]] = {
      val filters = new FilterList(FilterList.Operator.MUST_PASS_ONE)
      val crf = new ColumnRangeFilter(Bytes.toBytes(start), true, Bytes.toBytes(end), true)
      filters.addFilter(crf)
      getDataByRowkey(table, family, rowkey, qualifiers = Option(column), filterList = Option(filters))
    }

    def getDataWithColRegex(table: Table, family: String, qualifiers: Option[List[String]] = None, regex: String): Map[String, Map[String, String]] = {
      val filters = new FilterList(FilterList.Operator.MUST_PASS_ONE)
      val rf = new RowFilter(CompareFilter.CompareOp.EQUAL, new RegexStringComparator(regex))
      filters.addFilter(rf)
      scanData(table, family, qualifiers, filterList = Option(filters))
    }

    def deleteDataByRowKey(table: Table, family: String, rowkeyParams: List[String], isDelByRow: Boolean, qualifiers: Option[List[String]] = None): Unit = {
      try {
        var rowkeyDelete: Delete = null
        val listDelete = new util.ArrayList[Delete]()
        if (rowkeyParams.isInstanceOf[List[String]]) {
          val rowkeyList: List[String] = rowkeyParams.asInstanceOf[List[String]]
          rowkeyList.foreach(rowkey => {
            rowkeyDelete = new Delete(rowkey.getBytes)
            if (isDelByRow) {
              listDelete.add(rowkeyDelete)
            } else {
              listDelete.add(addFamilyAndQualifiers(rowkeyDelete, family, qualifiers).asInstanceOf[Delete])
            }
          })
          table.delete(listDelete)
        } else {
          throw new IllegalArgumentException
        }
      } finally {
        BdsDbUtil.closeConnect(table)
      }
    }

    private def getHbaseResult2Map(table: Table, obj: Object, isAutoClose: Boolean = true): Map[String, Map[String, String]] = {
      var resultScanner: ResultScanner = null
      var result: Result = null
      try {
        var resultMap = Map[String, Map[String, String]]()
        if (obj.isInstanceOf[util.List[Get]]) {
          val results: Array[Result] = table.get(obj.asInstanceOf[util.List[Get]])
          for (result <- results) {
            val map = result2Map(result)
            if (StringUtils.isNotEmpty(map.getOrElse("rowkey", ""))) {
              resultMap += (map.getOrElse("rowkey", "") -> map)
            }
          }
          resultMap
        } else if (obj.isInstanceOf[Scan]) {
          resultScanner = table.getScanner(obj.asInstanceOf[Scan])
          result = resultScanner.next()
          while (result != null) {
            val map = result2Map(result)
            if (StringUtils.isNotEmpty(map.getOrElse("rowkey", ""))) {
              resultMap += (map.getOrElse("rowkey", "") -> map)
            }
            // 循环结束条件
            result = resultScanner.next()
          }
          resultMap
        } else {
          throw new IllegalArgumentException
        }
      } finally {
        if (isAutoClose) {
          BdsDbUtil.closeConnect(resultScanner, table, conn)
        }
      }
    }

    // =======================================工具=============================================

    private def addFamilyAndQualifiers[T](action: Object, family: String, qualifiers: Option[Object] = None): Object = {
      val qualifierObj: Object = qualifiers.getOrElse(null)
      var qualifierList: List[String] = null
      if (qualifierObj != null) {
        if (qualifierObj.isInstanceOf[List[String] @unchecked]) {
          qualifierList = qualifierObj.asInstanceOf[List[String]]
        } else if (qualifierObj.isInstanceOf[Class[T] @unchecked]) {

        } else {
          throw new IllegalArgumentException
        }
      }

      if (action.isInstanceOf[Get]) {
        var get: Get = action.asInstanceOf[Get]
        if (qualifierList != null && !qualifierList.isEmpty) {
          for (qualifier <- qualifierList) {
            get.addColumn(family.getBytes, qualifier.getBytes)
          }
        } else {
          get.addFamily(family.getBytes)
        }
        get
      } else if (action.isInstanceOf[Delete]) {
        var delete: Delete = action.asInstanceOf[Delete]
        if (qualifierList != null && !qualifierList.isEmpty) {
          for (qualifier <- qualifierList) {
            delete.addColumn(family.getBytes, qualifier.getBytes)
          }
        } else {
          delete.addFamily(family.getBytes)
        }
        delete
      } else {
        ""
      }
    }

    private def result2Map(result: Result): Map[String, String] = {
      var map = Map[String, String]()
      if (result != null) {
        result.rawCells().foreach(cell => {
          val qualifier = Bytes.toString(CellUtil.cloneQualifier(cell))
          val value = Bytes.toString(CellUtil.cloneValue(cell))
          map += (qualifier -> value)
        })
        val rowKeyValue = Bytes.toString(result.getRow)
        map += ("rowkey" -> rowKeyValue)
      }
      map
    }

    private def result2JSONObject(result: Result): JSONObject = {
      val jsonObject=new JSONObject()
      if (result != null) {
        result.rawCells().foreach(cell => {
          val qualifier = Bytes.toString(CellUtil.cloneQualifier(cell))
          val value = Bytes.toString(CellUtil.cloneValue(cell))
          jsonObject.put(qualifier,value)
        })
        val rowKeyValue = Bytes.toString(result.getRow)
        jsonObject.put("rowkey",rowKeyValue)
      }
      jsonObject
    }


    /**
     * 加载hbase单表，返回rowkey及数据集
     *
     * @param sc
     * @param tableName
     * @return
     */
    def getHbaseSingleTableRdd(sc: SparkContext, tableName: String, startRow: Option[String] = None, endRow: Option[String] = None): RDD[(String, Map[String, String])] = {
      hbaseConfig.set(TableInputFormat.INPUT_TABLE, tableName)
      if (StringUtils.isNotEmpty(startRow.getOrElse(""))) {
        hbaseConfig.set(TableInputFormat.SCAN_ROW_START, startRow.getOrElse(""))
      }
      if (StringUtils.isNotEmpty(endRow.getOrElse(""))) {
        hbaseConfig.set(TableInputFormat.SCAN_ROW_STOP, endRow.getOrElse(""))
      }
      val rdd: RDD[(ImmutableBytesWritable, Result)] = sc.newAPIHadoopRDD(hbaseConfig, classOf[TableInputFormat],
        classOf[org.apache.hadoop.hbase.io.ImmutableBytesWritable],
        classOf[org.apache.hadoop.hbase.client.Result])
      println("rddCount:" + rdd.count())
      hbaseRdd2Rdd(rdd)
    }

    /**
     * 加载hbase多表并返回rowkey和结果集
     *
     * @param tables
     * @param sc
     */
    def getHbaseMultiTablesRdd(sc: SparkContext, tables: List[String]): RDD[(String, Map[String, String])] = {
      initHbaseScans(tables)
      val rdd: RDD[(ImmutableBytesWritable, Result)] = sc.newAPIHadoopRDD(hbaseConfig, classOf[MultiTableInputFormat], classOf[ImmutableBytesWritable], classOf[Result])
      hbaseRdd2Rdd(rdd)
    }

    private def hbaseRdd2Rdd(hbaseRdd: RDD[(ImmutableBytesWritable, Result)]): RDD[(String, Map[String, String])] = {
      val rdd: RDD[(String, Map[String, String])] = hbaseRdd.map(result => {
        val map: Map[String, String] = result2Map(result._2)
        (Bytes.toString(result._1.get()), map)
      })
      rdd
    }

    /**
     * 多表时，初始化每个hbase表的scan并序列化，拼装成字符串存于conf
     * 集群启动任务时，反序列化加载相应的scan对象
     *
     * @param tables
     * @return
     */
    private def initHbaseScans(tables: List[String]) = {
      val list = new util.ArrayList[Scan]()
      tables.foreach(table => {
        val scan = new Scan()
        scan.setAttribute(Scan.SCAN_ATTRIBUTES_TABLE_NAME, Bytes.toBytes(table))
        list.add(scan)
      })
      val scans: Array[String] = getScan(list)
      hbaseConfig.set(MultiTableInputFormat.SCANS, scans.mkString(","))
      hbaseConfig
    }

    /**
     * 获取各个hbase的scan对象并序列化成数组
     *
     * @param scans
     * @return
     */
    private def getScan(scans: util.List[Scan]): Array[String] = {
      val scanStrings = new util.ArrayList[String]()
      val it: util.Iterator[Scan] = scans.iterator()
      while (it.hasNext) {
        val scan: Scan = it.next().asInstanceOf[Scan]
        scanStrings.add(convertScanToString(scan))
      }
      val arr = new Array[String](scanStrings.size())
      scanStrings.toArray(arr)
    }

    /**
     * 序列化scan对象
     *
     * @param scan
     * @return
     */
    private def convertScanToString(scan: Scan): String = {
      val proto: ClientProtos.Scan = ProtobufUtil.toScan(scan)

      //    Base64.encodeBytes(proto.toByteArray)
      ""
    }

  }


  object HbaseTableSink {
    val logger: Logger = LogManager.getLogger(this.getClass)
    def apply(userConfig: Option[Configuration] = None): HbaseTableSink = {
      val config = userConfig.getOrElse {
        HBaseConfiguration.create()
      }
      apply(config)
    }


    def apply(userConfigPro: Properties): HbaseTableSink = {
      val config: Configuration = HBaseConfiguration.create()
      val zkAddress= userConfigPro.getProperty("hbase.zookeeper.quorum")
      val zkPort= userConfigPro.getProperty("hbase.zookeeper.property.clientPort")
      if (StringUtils.isNotEmpty(zkAddress)) {
        logger.info("zkAddress is:{}",zkAddress)
        config.set("hbase.zookeeper.quorum", zkAddress) //填写节点
      }
      if (StringUtils.isNotEmpty(zkPort)) {
        logger.info("zkPort is:{}",zkPort)
        config.set("hbase.zookeeper.property.clientPort", zkPort) //填写节点
      }
      config.setInt("hbase.client.retries.number", 3);
      config.setInt("zookeeper.recovery.retry", 3);
      config.setInt("hbase.zookeeper.property.maxClientCnxns", 0);


      apply(config)
    }

    // 主要是一些配置
    def apply(config: Configuration): HbaseTableSink = {
      val f = () => {
        val conn = ConnectionFactory.createConnection(config)
        sys.addShutdownHook {
          BdsDbUtil.closeConnect(conn)
        }
        (config, conn)
      }
      new HbaseTableSink(f)
    }

    def closeConnect(closeable: AutoCloseable*): Unit = {
      for (connect <- closeable) {
        try {
          if (connect != null) {
            connect.close()
          }
        } catch {
          case e: Exception => println(e)
        } finally {
        }
      }
    }
}
