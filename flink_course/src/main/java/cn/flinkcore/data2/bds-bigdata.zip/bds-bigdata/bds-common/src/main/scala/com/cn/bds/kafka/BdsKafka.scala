package com.cn.bds.kafka

import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.clients.producer.ProducerConfig
import org.apache.kafka.common.TopicPartition
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.{SparkContext, SparkFiles}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.{Durations, StreamingContext}

import java.io.{File, FileInputStream, FileOutputStream, IOException}
import java.util.Properties

object BdsKafka {
  @volatile private var instance: Broadcast[KafkaSink[String, String]] = null

  /**
   * 获取kafka生产者
   *
   * @param sc
   * @param pro
   * @return
   */
  def getKafkaProduce(sc: SparkContext,kafkaName:String): Broadcast[KafkaSink[String, String]] = {
    if (instance == null) {
      this.synchronized {
        if (instance == null) {
          val kafkaConfig: Properties = {
            val pro=new Properties()
            pro
          }
          instance = sc.broadcast(KafkaSink[String, String](Option(kafkaConfig)))
        }
      }
    }
    instance
  }


  def getConsumerParams(kafkaName:String): Unit = {


  }


  def addJks2Executor(sc: SparkContext): Unit = {
    val kafkaJksDir = ""
    sc.addFile(kafkaJksDir)
    val jksIndex = kafkaJksDir.lastIndexOf("/") + 1
    val kafkaJksFileName = kafkaJksDir.substring(jksIndex)
    val localPath = SparkFiles.get(kafkaJksFileName)
    val inFile = new File(localPath)
    val localWorkTemp = System.getProperty("user.dir" + File.separator + inFile.getName)
    copyFile(localPath, localWorkTemp)
  }

  /**
   * 体交kafka的偏移量,注意:1.InputDStream和rdd是最开始的,不能有任何处理
   *
   * @param stream
   * @param rdd
   */
  def commitOffset(stream: InputDStream[ConsumerRecord[String, String]], rdd: RDD[ConsumerRecord[String, String]]): Unit = {
    val ranges: Array[OffsetRange] = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
    stream.asInstanceOf[CanCommitOffsets].commitAsync(ranges)
  }

  def getStreamingContext(sparkContext: SparkContext, durations: Int = 15): StreamingContext = {
    new StreamingContext(sparkContext, Durations.seconds(durations))
  }


  //  // 可以配置多个
  //  val topics = Array("topic01")
  //  val topicPartitions: Array[TopicPartition] = Array(new TopicPartition("topic01", 0))
  //  val offsets: Map[TopicPartition, Long] = Map(new TopicPartition("topic01", 0) -> 2220L)
  //

  /**
   * 订阅所有的partition数据
   *
   * @param ssc
   * @param topicArray
   * @param kafkaParams
   * @return
   */
  def getInputDStream(sparkContext: SparkContext, durations: Int = 15, topicArray: Array[String], kafkaParams: Map[String, Object]): InputDStream[ConsumerRecord[String, String]] = {
    val ssc = getStreamingContext(sparkContext, durations)
    KafkaUtils.createDirectStream(ssc, PreferConsistent, Subscribe[String, String](topicArray, kafkaParams))
  }

  /**
   * 订阅所有的 partition 数据,但是可以指定某些 partition 的 offset
   *
   * @param ssc
   * @param topicArray
   * @param kafkaParams
   * @param offsets
   * @return
   */
  def getInputDStream(ssc: StreamingContext, topicArray: Array[String], kafkaParams: Map[String, Object], offsets: Map[TopicPartition, Long]): InputDStream[ConsumerRecord[String, String]] = {
    KafkaUtils.createDirectStream(ssc, PreferConsistent, Subscribe[String, String](topicArray, kafkaParams, offsets))
  }

  /**
   * 可以指定的 partition数据和指定的 offset
   *
   * @param ssc
   * @param topicPartitions
   * @param kafkaParams
   * @param offsets
   * @return
   */
  def getInputDStream(ssc: StreamingContext, topicPartitions: Array[TopicPartition], kafkaParams: Map[String, Object], offsets: Map[TopicPartition, Long]): InputDStream[ConsumerRecord[String, String]] = {
    KafkaUtils.createDirectStream(ssc, PreferConsistent, ConsumerStrategies.Assign[String, String](topicPartitions, kafkaParams, offsets))
  }



  def getProduceParams(bootstrapServers: String, acks: Int = 0, retries: Int = 3): Properties = {
    val pros = new Properties()
    pros.put(ProducerConfig.ACKS_CONFIG, acks.toString)
    pros.put(ProducerConfig.RETRIES_CONFIG, retries.toString)
    pros.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer")
    pros.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer")
    pros.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers)
    pros
  }

  def getSecParams(bootStrap: String, groupId: String, offsetReset: String = "latest", autoCommit: java.lang.Boolean = true): Map[String, Object] = {
    var paramsMap = getNoSecParams(bootStrap, groupId, offsetReset, autoCommit)
    paramsMap += ("security.protocol" -> "SASL_PLAINTEXT")
    paramsMap += ("sasl.mechanism" -> "PLAIN")
    paramsMap
  }

  def getNoSecParams(bootStrap: String, groupId: String, offsetReset: String = "latest", autoCommit: java.lang.Boolean = true): Map[String, Object] = {
    var commonKafkaParamsMap: Map[String, Object] = Map()
    commonKafkaParamsMap += ("bootstrap.servers" -> bootStrap)
    commonKafkaParamsMap += ("key.deserializer" -> classOf[StringDeserializer])
    commonKafkaParamsMap += ("value.deserializer" -> classOf[StringDeserializer])
    commonKafkaParamsMap += ("group.id" -> groupId)
    commonKafkaParamsMap += ("auto.offset.reset" -> offsetReset)
    commonKafkaParamsMap += ("enable.auto.commit" -> autoCommit)
    commonKafkaParamsMap
  }


  def copyFile(localPath: String, localWorkTemp: String): Unit = {
    if (!new File(localWorkTemp).exists()) {
      this.synchronized {
        try {
          val fis = new FileInputStream(localPath)
          val fos = new FileOutputStream(localWorkTemp)
          val buf = new Array[Byte](1024)
          var len = 0
          while ( {
            len = fis.read(buf)
            len
          } != -1) {
            fos.write(buf, 0, len)
          }
          fos.close()
          fis.close()
        } catch {
          case ie: IOException => ie.printStackTrace()
        }
      }
    }
  }
}
