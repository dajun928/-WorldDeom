package com.cn.model.hbase

import com.cn.bds.model.SparkModel
import org.apache.hadoop.hbase.client.{Admin, ConnectionFactory}
import org.apache.hadoop.hbase._

import java.util.Locale
object CreateHbase {
  val hbaseDelimeter = ":"
  val defaultDatabaseName = "bds"
  val defaultFamily = "info"

  def main(args: Array[String]): Unit = {

    val sparkModel = new SparkModel(args, "", null)

    val sparkSession = sparkModel.getSparkSession()
    val sparkContext = sparkSession.sparkContext
    val conf = sparkContext.getConf
    val configuration = HBaseConfiguration.create()

    configuration.set(HConstants.ZOOKEEPER_QUORUM, "")
    configuration.set(HConstants.ZOOKEEPER_CLIENT_PORT, "24002")

    val firstParams = args(0)
    val hbaseNameSpace = if (firstParams.contains(hbaseDelimeter)) {
      firstParams.split(firstParams)(0).toLowerCase(Locale.ROOT)
    } else {
      defaultDatabaseName
    }

    val hbaseTable = if (firstParams.contains(hbaseDelimeter)) {
      firstParams
    } else {
      defaultDatabaseName + firstParams
    }

    val hbaseTableName: TableName = TableName.valueOf(hbaseTable)
    val secondParam = args(1)

    val hbaseFamily = if (!secondParam.matches("\\d+")) {
      secondParam
    } else {
      defaultFamily
    }


    // 创建hbase连接信息
    val connection = ConnectionFactory.createConnection(configuration)

    val hbaseAdmin: Admin = connection.getAdmin

    // 创建hbase表空间

    var nameSpaceExists: Boolean = false

    val listNameSpace = hbaseAdmin.listNamespaceDescriptors()
    for (nameSpace <- listNameSpace if !nameSpaceExists) {
      if (hbaseNameSpace.equals(nameSpace.getName)) {
        nameSpaceExists = true
      }
    }

    if (!nameSpaceExists) {
      println("namespace of hbase not exist! create new namespace:{}" + hbaseNameSpace)
      hbaseAdmin.createNamespace(NamespaceDescriptor.create(hbaseNameSpace).build())
    }


    // 创建hbase表首先判断表名是否存在
    val thirdParameter = args(2)

    if (hbaseAdmin.isTableAvailable(hbaseTableName)) {
      println("hbase table not exists! create new table:{}" + hbaseTable)


      val tableDesc = new HTableDescriptor(hbaseTableName)
      val tableColumn = new HColumnDescriptor(hbaseFamily.getBytes())

      if (thirdParameter.matches("\\d")) {
        tableColumn.setTimeToLive(String.valueOf(thirdParameter))
      }
      tableDesc.addFamily(tableColumn)
      hbaseAdmin.createTable(tableDesc)
      println("hbase table is create" + hbaseTable)
    } else {
      println("hbase table is already" + hbaseTable)
    }

    connection.close()
    hbaseAdmin.close()
    sparkSession.stop()

  }

}
