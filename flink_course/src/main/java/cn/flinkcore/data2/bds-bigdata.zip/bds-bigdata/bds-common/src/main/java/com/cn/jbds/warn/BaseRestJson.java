package com.cn.jbds.warn;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BaseRestJson extends BaseRest implements Serializable {


    private static final long serialVersionUID = 1153834918490535017L;
    @JSONField(name="warn_people")
    private String warnPeople;

    public String getWarnPeople() {
        return warnPeople;
    }

    public void setWarnPeople(String warnPeople) {
        this.warnPeople = warnPeople;
    }
}
