package com.cn.jbds.kafka;

import java.util.Objects;

public enum KafkaClusterEnum {

    Test("k1", "k11"),

    Test2("k2", "k22");


    private  String kafkaName;
    private  String ip;

    KafkaClusterEnum(String kafkaName, String ip) {
        this.kafkaName = kafkaName;
        this.ip = ip;
    }

    public static KafkaClusterEnum getValueFrom(String userParams) {
        for (KafkaClusterEnum value : KafkaClusterEnum.values()) {
            if (Objects.equals(value.kafkaName, userParams)) {
                return value;
            }
        }
        return null;
    }
}
