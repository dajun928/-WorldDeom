package com.cn.model.stream.spark

import com.alibaba.fastjson.JSONObject
import com.cn.bds.config.UserConfigUtil
import com.cn.bds.kafka.{BdsKafka, KafkaSink}
import com.cn.bds.model.SparkModel
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}

import java.util.Properties

object KafkaProducer {
  def main(args: Array[String]): Unit = {
    val sparkConf = new SparkConf().setAppName("KafkaProducer")
    val sm: SparkModel = new SparkModel(args, "", sparkConf)

    val kafkaParamsMap: Properties = UserConfigUtil.getKafkaProducerParams()

    val session: SparkSession = sm.getSparkSession()
    val produce: Broadcast[KafkaSink[String, String]] = BdsKafka.getKafkaProduce(session.sparkContext, "kafkaName")
    //        sendStr(produce)
    sendDf(session, produce)
  }

  def sendStr(produce:Broadcast[KafkaSink[String, String]]): Unit = {
    var i = 0
    while (true) {
      val json = new JSONObject()
      json.put("aa", "aa1")
      json.put("seq", i.toString)
      produce.value.sendValue(topic = "testzxz", json.toString)
      Thread.sleep(2000)
      println("send=i:" + i)
      i += 1
    }
  }

  def sendDf(session: SparkSession, produce: Broadcast[KafkaSink[String, String]]): Unit = {
    val sc: SparkContext = session.sparkContext
    import session.implicits._
    val df = sc.parallelize(List(
      (1, "ming", 20, 15552211521L),
      (2, "hong", 19, 13287994007L),
      (3, "zhi", 21, 15552211523L),
      (4, "ming", 20, 15552211521L),
      (5, "hong", 19, 13287994007L),
      (6, "zhi", 21, 15552211523L),
      (7, "ming", 20, 15552211521L)
    )).toDF()
    df.show(false)
    df.rdd.repartition(2).foreachPartition(part => {
      part.foreach(row => {
        val seq: String = row.getAs[Int](0).toString
        val name: String = row.getAs[String](1)
        val age: String = row.getAs[Int](2).toString
        val time: String = row.getAs[Long](3).toString
        val json = new JSONObject()
        json.put("seq", seq)
        json.put("name", name)
        json.put("age", age)
        json.put("time", time)
        println("seq:" + seq)
        produce.value.sendValue("testzxz", json.toJSONString)
      })
    })
  }
}
