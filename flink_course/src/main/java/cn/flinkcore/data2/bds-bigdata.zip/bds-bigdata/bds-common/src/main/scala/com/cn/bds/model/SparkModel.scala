package com.cn.bds.model

import com.cn.bds.config.HdfsConfigSink
import com.cn.bds.utils.BaseUtil
import org.apache.commons.lang3.StringUtils
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.streaming.{Durations, StreamingContext}

import java.util.Properties

class SparkModel(userParamsMap: java.util.Map[String, String], codeAppName: String, userSparkConf: SparkConf) extends Serializable {
  val logger: Logger = LogManager.getLogger(this.getClass)
  val appName = getUserParamsVal("appName", "")
  val durations: Long = getUserParamsVal("durations", "5").toLong
  val finalAppName = getFinalAppName()
  val inputTypeArray = getUserParamsVal("input.type", "hive").toLowerCase().split(",")
  val sparkConf: SparkConf = getSparkConf()

  private val sink: HdfsConfigSink = HdfsConfigSink("dev")

  def this(args: Array[String]=null, codeAppName: String="default_spark", userSparkConf: SparkConf=null) = {
    this(BaseModel.args2Map(args), codeAppName, userSparkConf)
  }

  def getUserParamsVal(key: String, defaulVal: String=""): String = {
    val value = userParamsMap.get(key)
    if (value == null) defaulVal else value
  }

  def getFinalAppName(): String = {
    if (StringUtils.isNotEmpty(appName)) {
      appName
    } else if (StringUtils.isNotEmpty(codeAppName)) {
      codeAppName
    } else {
      "default_spark"
    }
  }

  def getSparkConf(): SparkConf = {
    val sparkConf = if (userSparkConf == null) {
      var defaultConfig = new SparkConf()
      logger.warn("info userSparkConf is null:{}" )
      if (inputTypeArray.contains("sql")) {
        defaultConfig = UserSparkConf.getSqlConf(defaultConfig)
      }

      if (inputTypeArray.contains("hive")) {
        defaultConfig = UserSparkConf.getHiveConf(defaultConfig)
      }
      // kafka 参数设置
      if (inputTypeArray.contains("kafka")) {
        defaultConfig = UserSparkConf.getKafkaConf(defaultConfig)
      }

      defaultConfig.setAppName(finalAppName)
      defaultConfig
    } else {
      userSparkConf
    }
    sparkConf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
  }

  def getSparkSession(): SparkSession = {
    var builder: SparkSession.Builder = SparkSession.builder.config(sparkConf)
    if (BaseModel.isRunningOnWin()) {
      builder = builder.master("local[3]")
    }
    builder.getOrCreate()
  }

  def getStreamingContext(sparkContext: SparkContext): StreamingContext = {
    new StreamingContext(sparkContext, Durations.seconds(durations))
  }


  // 定时读取数据库表
  def getDbData2DfByTime(ss: SparkSession, sql: String, dbPro: Properties, paramsTuple: (DataFrame, Long, Boolean),
                         second: Int)
  : (DataFrame, Long, Boolean) = {
    if (paramsTuple == null || second <= 0) {
      // 如果 paramsTuple 为 null 或者 second<=0,只读取一次数据
      val df: DataFrame = SparkModelUtil.dbData2Df(ss, sql, dbPro)
      (df, System.currentTimeMillis(), true)
    } else if (paramsTuple != null && second > 0) {
      // 如果 paramsTuple 不为 null 或者 second>0,定时读取数据
      SparkModelUtil.getDbDataByTime(ss, sql, dbPro, paramsTuple, second)
    } else {
      null
    }
  }

}

object SparkModel {

  def dfShow(isShow: Boolean, typeName: String, df: DataFrame, showNumber: Int = 30): Unit = {
    if (isShow) println("[输入日志]：" + typeName + "####>>>" + df.show(showNumber, false))
  }

  def isLog(flag: Boolean, typeName: String, obj: Object): Unit = {
    if (flag) println("[输入日志]：" + typeName + "####>>>" + obj)
  }
}
