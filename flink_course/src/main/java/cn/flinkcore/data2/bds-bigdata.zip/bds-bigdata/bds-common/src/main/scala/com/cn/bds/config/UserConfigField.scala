package com.cn.bds.config

object UserConfigField {
  /**
   * UserConfigSink中配置的字段
   */
  object UserConfig {

  }

  object Mysql {
    val mysql_driver_key = "mysql.driver"
    val mysql_driver_value = "com.mysql.jdbc.Driver"
    val mysql_url_key = "mysql.url"
    val mysql_url_value = ""

    val roType = "mysql.ro"
    val rwType = "mysql.rw"

    val mysql_user_key = "mysql.user"
    val mysql_rw_local_user_value = "root"

    val mysql_pw_key = "mysql.pw"
    val mysql_rw_local_pw_value = "123456"

    val mysql_dbName_key = "mysql.dbName"

    val mysql_local_ip = "127.0.0.1"
  }


  object Hbase {

  }

  object Kafka {

  }
}
