//package com.cn.model.batch.spark
//
//import slick.driver.MySQLDriver.api._
//
//case class Person(id: String = "1",
//                  name: String = null,
//                  birth: Long = 0,
//                  sex: String = null,
//                  heigh: Option[Long] = Some(0)
//                 )
//
//object Person {
//  //表结构: 定义字段类型, * 代表结果集字段
//  class T(tag: Tag) extends Table[Person](tag, "Person") {
//    def id = column[String]("id")
//
//    def name = column[String]("name")
//
//    def birth = column[Long]("birth")
//
//    def sex = column[String]("sex")
//
//    def heigh = column[Option[Long]]("heigh")
//
//    def * = (id, name, birth, sex, heigh) <> ((Person.apply _).tupled, Person.unapply)
//
//  }
//
//  //库表实例
//  val q = TableQuery[T]
//}
