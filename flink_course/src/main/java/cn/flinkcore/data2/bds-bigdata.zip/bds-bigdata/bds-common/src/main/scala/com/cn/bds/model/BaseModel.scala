package com.cn.bds.model

import java.util

object BaseModel {
  def main(args: Array[String]): Unit = {


  }

  // emr专用
  def args2Map(args: Array[String]): util.HashMap[String, String] = {
    var map = new util.HashMap[String, String]()
    if (args != null && args.length > 0) {
      val indices: Range = args.indices
      for (indice <- indices) {
        val element = args(indice)
        if (element.startsWith("--") && !element.startsWith("--conf")) {
          map.put(element, args(indice + 1))
        } else if (element.contains("=")) {
          val arr: Array[String] = element.split("=")
          map.put(arr(0), arr(1))
        } else if (element.startsWith("--conf")) {
          // todo
          map.put(element, args(indice + 1))
        } else {
          ;
        }
      }

      //      args.foreach(item => {
      //        val arr: Array[String] = item.split("=")
      //        map.put(arr(0), arr(1))
      //      })
    }
    map
  }


  def getOsName(): String = {
    val osName: String = System.getProperties.getProperty("os.name")
    osName
  }

  def isRunningOnWin(): Boolean = {
    if (getOsName.toLowerCase.contains("win")) true else false
  }

  //	用户帐号名
  def getOsUserName(): String = {
    val osName: String = System.getProperties.getProperty("user.name")
    osName
  }

}
