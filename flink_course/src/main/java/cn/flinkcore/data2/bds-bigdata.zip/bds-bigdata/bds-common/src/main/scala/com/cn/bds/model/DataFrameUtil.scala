package com.cn.bds.model

import com.alibaba.fastjson.{JSON, JSONObject}
import com.cn.bds.config.UserConfigField
import com.cn.bds.config.UserConfigField.Mysql
import com.cn.bds.mysql.MysqlSink
import com.cn.bds.utils.{BdsDateTimeUtil, BdsDbUtil}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.sql.types.{BooleanType, ByteType, DateType, DecimalType, DoubleType, FloatType, IntegerType, LongType, ShortType, StringType, TimestampType}

import java.sql.{Connection, Date, PreparedStatement, Timestamp}
import java.util.Properties
import scala.collection.mutable.ArrayBuffer

object DataFrameUtil {

  def dbData2Df(ss: SparkSession, selectSql: String, pro: Properties, numPartitions: Int = 10): DataFrame = {
    var sqlStr = ""
    if (selectSql.contains("from")) {
      //条件查询
      sqlStr = "(" + selectSql + ") as t1"
    } else {
      //全表查询
      sqlStr = selectSql
    }
    ss.read
      .format("jdbc")
      .option("url", pro.getProperty(Mysql.mysql_url_key, ""))
      .option("driver", pro.getProperty(UserConfigField.Mysql.mysql_driver_key, ""))
      .option("dbtable", sqlStr)
      .option("user", pro.getProperty(UserConfigField.Mysql.mysql_user_key, ""))
      .option("password", pro.getProperty(UserConfigField.Mysql.mysql_pw_key, ""))
      .option("numPartitions", numPartitions)
      .load()
  }

  /**
   * 说明：df列名和db中的列名一致，否则报错
   *
   * @param resultDataFrame
   * @param dbPro
   * @param tableName
   * @param batchSize
   */
  def df2Db(resultDataFrame: DataFrame, dbPro: Properties, tableName: String, batchSize: Int = 2000): Unit = {
    val columnDataTypes = resultDataFrame.schema.fields.map(_.dataType)
    val columnDataNames = resultDataFrame.schema.fields.map(_.name)
    val sqlStr = BdsDbUtil.getInsertSqlStr(tableName, columnDataNames)
    println("sqlStr:" + sqlStr)
    resultDataFrame.rdd.foreachPartition(itor => {
      val mysqlSink = MysqlSink(dbPro)
      val conn: Connection = mysqlSink.getConnection()
      val ps: PreparedStatement = conn.prepareStatement(sqlStr)
      var count = 0
      try {
        conn.setAutoCommit(false)
        itor.foreach(row => {
          for (i <- 1 to columnDataNames.length) {
            setData(columnDataTypes, ps, row, i)
          }
          ps.addBatch()
          count = count + 1
          if (count % batchSize == 0) {
            connectPs(ps, conn)
          }
        })
        connectPs(ps, conn)
      } catch {
        case e: Exception => println(e)
      } finally {
        BdsDbUtil.closeConnect(ps, conn)
      }
    })
  }

  private def connectPs(ps: PreparedStatement, conn: Connection): Unit = {
    ps.executeBatch()
    conn.commit()
    ps.clearBatch()
  }

  private def setData(columnDataTypes: _root_.scala.Array[_root_.org.apache.spark.sql.types.DataType],
                      stmt: _root_.java.sql.PreparedStatement, row: _root_.org.apache.spark.sql.Row, i: Int): Unit = {
    val dataTypes = columnDataTypes(i - 1)
    dataTypes match {
      case _: ByteType => stmt.setInt(i, row.getAs[Int](i - 1))
      case _: ShortType | IntegerType => stmt.setInt(i, row.getAs[Int](i - 1))
      case _: LongType => stmt.setLong(i, row.getAs[Long](i - 1))
      case _: BooleanType => stmt.setBoolean(i, row.getAs[Boolean](i - 1))
      case _: FloatType => stmt.setFloat(i, row.getAs[Float](i - 1))
      case _: DoubleType => stmt.setDouble(i, row.getAs[Double](i - 1))
      case _: StringType => stmt.setString(i, row.getAs[String](i - 1))
      case _: TimestampType => stmt.setTimestamp(i, row.getAs[Timestamp](i - 1))
      case _: DateType => stmt.setDate(i, row.getAs[Date](i - 1))
      case _: DecimalType => stmt.setBigDecimal(i, row.getAs[java.math.BigDecimal](i - 1))
      case _ => throw new RuntimeException(s"nonsupport $dataTypes !!!")
    }
  }


  def map2Df(ss: SparkSession, map: Map[String, String]): DataFrame = {
    import ss.implicits._
    val result = ArrayBuffer[(String, String)]()
    map.foreach(data => {
      result.append(data)
    }
    )
    result.toDF("key", "value")
  }

  /**
   * dataList为一行的值   nameList为列名
   * 注表格里值一定要统一格式 ，全转化为String(null除外，没意义) 如果没有则toDF方法报错
   *
   * @param spark
   */
  def list2Df(spark: SparkSession, dataList: List[String], nameList: List[String]): DataFrame = {
    import org.apache.spark.sql.functions._
    import spark.implicits._
    var df = List((dataList.toArray)).toDF("features")
    val elements = nameList.toArray
    val sqlExpr = elements.zipWithIndex.map { case (alias, idx) => col("features").getItem(idx).as(alias) }
    df.select(sqlExpr: _*)
  }





  def array2Df(ss: SparkSession): Unit = {
    import ss.implicits._
    val seq = Array(2, 3, 6).toSeq
    val df = ss.sparkContext.parallelize(seq).map(data => {
      data
    }).toDF("seq")
    df.show()
  }

  def map2Df2(ss: SparkSession): Unit = {
    //2. 隐式转换 rdd转dataFrame
    import ss.implicits._
    //3. scala的Map数据结构
    val map = Map("aa" -> "aaa", "cc" -> "ccc", "bb" -> "bbb")
    //4. map的所有key
    val mk = map.keys
    //5. 创建rdd
    val rdd = ss.sparkContext.parallelize(Seq(map))
    //6. 根据map的key取出所有的值，构建新的rdd，并转成dataFrame
    val df = rdd.map(x => {
      val bb = new ArrayBuffer[String]()
      for (k: String <- mk) {
        bb.+=(x(k))
      }
      bb
    }).map(x => (x(0), x(1), x(2))).toDF("k1", "k2", "k3")
    df.show()

    val ds: Dataset[String] = df.toJSON
    ds.rdd.foreach(data => {
      data.toUpperCase()

    })
    ds.foreach(data => {
      val k1 = data.toUpperCase()
      println("k1:" + k1)

    })
  }

  def regularBroadCastDf(): Unit = {

  }

  val second = 1000
  val minute = 60 * second
  val one_hour = 60 * minute

  //  def getDbDataByTime(ss: SparkSession, dbPro: Properties, paramsTuple: (DataFrame, Long), second: Int, sql: String): (DataFrame, Long) = {
  //    val paramsDf: DataFrame = paramsTuple._1
  //    val paramsTime: Long = paramsTuple._2
  //    val currTime = System.currentTimeMillis()
  //    if (paramsDf.count() == 0 || (currTime - paramsTime) > second * 1000) {
  //      println("get data from db")
  //      if (paramsDf.count() > 0) {
  //        paramsDf.unpersist()
  //      }
  //      (dbData2Df(ss, dbPro, sql), System.currentTimeMillis())
  //    } else {
  //      paramsTuple
  //    }
  //  }
  //
  //  def getDbDataBroadByTime(ss: SparkSession, paramsSc: Option[SparkContext] = None, dbPro: Properties, paramsTuple: (Broadcast[DataFrame], Long), second: Int, sql: String): (Broadcast[DataFrame], Long) = {
  //    val tuple: (DataFrame, Long) = getDbDataByTime(ss, dbPro, (paramsTuple._1.value, paramsTuple._2), second, sql)
  //    val sc = paramsSc.getOrElse(ss.sparkContext)
  //    (sc.broadcast(tuple._1), tuple._2)
  //  }

  def getBetweenDayDf(ss: SparkSession, startTime: String, endTime: String, offsetType: String = "dd", pattern: String = BdsDateTimeUtil.ymdPattern): DataFrame = {
    import ss.implicits._
    val buffer: ArrayBuffer[String] = BdsDateTimeUtil.getBetweenDay(startTime, endTime, offsetType, pattern)
    ss.createDataset(buffer).toDF()
  }

  def df2Ds(ss: SparkSession): Unit = {
    import ss.implicits._
    val data = Array(
      (2, 3, 6),
      (22, 33, 66),
      (23, 33, 66),
      (24, 33, 66)
    ).toSeq

    val dataSet: Dataset[(Int, Int, Int)] = ss.createDataset(data)
    val dataFrame: DataFrame = dataSet.toDF("a", "b", "c")

    dataSet.show()
    dataFrame.show()
    val jj: Dataset[String] = dataFrame.toJSON
    val d1 = dataFrame.toJSON.mapPartitions(part => {
      part.map(data => {
        val json: JSONObject = JSON.parseObject(data)
        val a: String = json.getString("a")
        val b: String = json.getString("b")
        val c: String = json.getString("c")
        (a, b, c)
        //        json
      })
    })


    d1.show()


    //    seqDf.toJSON.foreachPartition(part => {
    //
    //      part.foreach(row => {
    //
    //        val json: JSONObject = JSON.parseObject(row)
    //        println(json)
    //        println(json.getString("a"))
    //        println(json.getString("b"))
    //
    //      })
    //    })


  }

  def main(args: Array[String]): Unit = {
  }
}
