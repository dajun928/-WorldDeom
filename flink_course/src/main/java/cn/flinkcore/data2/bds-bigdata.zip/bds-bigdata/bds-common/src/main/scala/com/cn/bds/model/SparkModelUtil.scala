package com.cn.bds.model

import com.cn.bds.config.UserConfigField
import com.cn.bds.config.UserConfigField.Mysql
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType}
import org.apache.spark.storage.StorageLevel

import java.util.Properties

object SparkModelUtil {
  val logger: Logger = LogManager.getLogger(this.getClass)
  val one_second = 1000
  val one_minute = 60 * one_second
  val one_hour = 60 * one_minute

  def getDbDataByTime(ss: SparkSession, sql: String, dbPro: Properties, paramsTuple: (DataFrame, Long, Boolean), second: Int)
  : (DataFrame, Long, Boolean) = {
    val paramsDf: DataFrame = paramsTuple._1
    val paramsTime: Long = paramsTuple._2
    val isUpDate: Boolean = paramsTuple._3
    val currTime = System.currentTimeMillis()
    val isEmptyDf: Boolean = paramsDf.isEmpty
    if (isEmptyDf || (currTime - paramsTime) > second * one_second) {
      if (!isEmptyDf) {
        paramsDf.unpersist()
      }
      val df = dbData2Df(ss, sql, dbPro).persist(StorageLevel.MEMORY_AND_DISK)
      (df, System.currentTimeMillis(), true)
    } else {
      paramsTuple
    }
  }

  def dbData2Df(ss: SparkSession, selectSql: String, pro: Properties, numPartitions: Int = 10): DataFrame = {
    var sqlStr = ""
    if (selectSql.contains("from")) {
      //条件查询
      sqlStr = "(" + selectSql + ") as t1"
    } else {
      //全表查询
      sqlStr = selectSql
    }
    ss.read
      .format("jdbc")
      .option("url", pro.getProperty(Mysql.mysql_url_key, ""))
      .option("driver", pro.getProperty(UserConfigField.Mysql.mysql_driver_key, ""))
      .option("dbtable", sqlStr)
      .option("user", pro.getProperty(UserConfigField.Mysql.mysql_user_key, ""))
      .option("password", pro.getProperty(UserConfigField.Mysql.mysql_pw_key, ""))
      .option("numPartitions", numPartitions)
      .load()
  }


  /**
   * 读取hdfs数据，转换成datafrmae
   */
  def rdd2Df(ss: SparkSession): DataFrame = {
    //SQLContext要依赖SparkContext
    val sc = ss.sparkContext
    //创建SQLContext
    //从指定的地址创建RDD
    val personRDD = sc.textFile("F:\\data\\log.csv").map(_.split(","))
    //通过StructType直接指定每个字段的schema
    val schema = StructType(
      List(
        StructField("id", StringType, true),
        StructField("name", IntegerType, true),
        StructField("age", StringType, true)
      )
    )
    //将RDD映射到rowRDD
    val rowRDD = personRDD.map(p => Row(p(0).toString, p(1).toInt, p(2).toString))
    //将schema信息应用到rowRDD上
    val personDataFrame = ss.createDataFrame(rowRDD, schema)
    personDataFrame
  }
}
