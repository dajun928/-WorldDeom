package com.cn.bds.utils

import org.apache.commons.lang3.StringUtils

import java.net.InetAddress
import java.util.regex.Pattern

object IpUtil {
  private val ipMatch="(?!^255(\\.255{3}$)^((25[0-5]|2[0-4]\\d|[1]{1}\\d{1}\\d{1}|[1-9]{1}\\d{1}|\\d{1})($|(?!\\.$)\\.)){4}$)"

  def main(args: Array[String]): Unit = {
    println("=100.10.10.10".matches(ipMatch))

    val address = getHostAddress

    println("address:"+address)
  }


  def getHostAddress(): String ={
   InetAddress.getLocalHost().getHostAddress
  }


  def isIp(ip:String): Boolean ={
    if(StringUtils.isBlank(ip)){
      false
    }else{
      val regex="^(([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.){3}([01])?\\d\\d?|2[0-4]\\d|25[0-5]$"
      Pattern.compile(regex).matcher(ip.trim).matches()
    }
  }
}
