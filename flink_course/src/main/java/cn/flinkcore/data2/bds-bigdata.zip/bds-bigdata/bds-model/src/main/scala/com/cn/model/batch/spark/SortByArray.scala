package com.cn.model.batch.spark

import com.alibaba.fastjson.serializer.SerializerFeature
import com.alibaba.fastjson.{JSON, JSONObject}
import com.cn.bds.model.SparkModel
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}

import java.util

object SortByArray {
  val logger: Logger = LogManager.getLogger(this.getClass.getSimpleName);

  def main(args: Array[String]): Unit = {

    val sm = new SparkModel(args, "", null)
    val ss = sm.getSparkSession()
    import ss.implicits._
    val df = getDf(ss)

    val df2: RDD[((String, String), JSONObject)] = df.rdd.map(data => {
      val id = data.getAs[String]("id")
      val name = data.getAs[String]("name")
      val age1 = data.getAs[String]("age1")
      val age2 = data.getAs[String]("age2")
      val map = new util.LinkedHashMap[String, Object]()
      val json = new JSONObject(map)
      json.put("age1", age1)
      json.put("age2", age2)
      ((id, name), json)
    })


    val df3 = df2.groupByKey()
      .map(kv => {
        val key = kv._1
        val value = kv._2.toSet.toArray
        val arr: Array[JSONObject] = value.sortBy(json => {
          json.getString("age1")
        }).reverse

        val resJson: String = JSON.toJSONString(arr,
          SerializerFeature.PrettyFormat
        )
        (key, resJson)
      })

    df3.toDF().show(false)
    ss.stop()
  }

  def getDf(ss: SparkSession): DataFrame = {
    import ss.implicits._
    val list: Seq[(String, String, String, String)] = List(
      ("1", "a", "c", "c"),
      ("1", "a", "2", "c"),
      ("1", "a", "3", "c"),
      ("1", "b", "1", "c"),
      ("2", "b", null, "c")
    )
    ss.createDataset(list).toDF("id", "name", "age1", "age2")
  }
}
