package com.cn.jbds.utils;

import com.alibaba.fastjson.JSON;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;

import javax.net.ssl.SSLContext;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class HttpUtil {
    private static String DEFAULT_CHARSET = "UTF-8";

    public static void main(String[] args) throws Exception {
        Map<String, String> map = new HashMap<>();
        map.put("a", "1");
        map.put("b", "2");
        String str = getFinalUrl("http://aaa/a/", map);

        System.out.println("str:" + str);
    }

    public static String doGet(String url, Map<String, String> paramsMap, Map<String, String> headerMap,
                               Map<String, String> bodyMap) throws Exception {
        HttpClient httpClient = getHttpClient();
        String finalUrl = getFinalUrl(url, paramsMap);
        HttpGet httpGet = new HttpGet(finalUrl);
        httpGet.setConfig(setConfig());
        setHttpHeader(httpGet, headerMap);
        String responseStr = executeHttp(httpClient, httpGet);
        return responseStr;
    }

    public static String doPost(String url, Map<String, String> paramsMap, Map<String, String> headerMap,
                                Map<String, String> bodyMap) throws Exception {
        HttpClient httpClient = getHttpClient();
        String finalUrl = getFinalUrl(url, paramsMap);
        HttpPost httpPost = new HttpPost(finalUrl);
        httpPost.setConfig(setConfig());
        setHttpHeader(httpPost, headerMap);
        // todo  gson改成fastjson
        String jsonStr = JSON.toJSONString(bodyMap);
//        String gsonStr = new Gson().toJson(bodyMap);
        StringEntity stringEntity = new StringEntity(jsonStr, DEFAULT_CHARSET);
        httpPost.setEntity(stringEntity);
        String responseStr = executeHttp(httpClient, httpPost);
        return responseStr;
    }

    private static String executeHttp(HttpClient httpClient, Object http) {
        HttpResponse httpResponse = null;
        String responseStr = "";
        try {
            if (http instanceof HttpGet) {
                httpResponse = httpClient.execute((HttpGet) http);
            } else if (http instanceof HttpPost) {
                httpResponse = httpClient.execute((HttpPost) http);
            } else if (http instanceof HttpPut) {
                httpResponse = httpClient.execute((HttpPut) http);
            } else if (http instanceof HttpDelete) {
                httpResponse = httpClient.execute((HttpDelete) http);
            } else {
                ;
            }
            if (httpResponse != null) {
                HttpEntity entity = httpResponse.getEntity();
                if (entity != null) {
                    responseStr = EntityUtils.toString(entity, DEFAULT_CHARSET);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return responseStr;
    }


    private static String getFinalUrl(String url, Map<String, String> paramsMap) throws UnsupportedEncodingException {
        StringBuffer paramsBuffer = new StringBuffer();
        if (isVaildMap(paramsMap)) {
            for (Map.Entry<String, String> entry : paramsMap.entrySet()) {
                paramsBuffer.append(entry.getKey());
                paramsBuffer.append("=");
                paramsBuffer.append(URLEncoder.encode(entry.getValue(), DEFAULT_CHARSET));
                paramsBuffer.append("&");
            }
            String paramsStr = paramsBuffer.substring(0, paramsBuffer.length() - 1);
            return url + "?" + paramsStr;
        } else {
            return url;
        }
    }

    private static boolean isVaildMap(Map<String, String> map) {
        if (map != null && map.size() > 0) {
            return true;
        } else {
            return false;
        }
    }

    private static void setHttpHeader(Object httpObj, Map<String, String> headerMap) {
        if (isVaildMap(headerMap)) {
            for (String key : headerMap.keySet()) {
                if (httpObj instanceof HttpGet) {
                    ((HttpGet) httpObj).setHeader(key, headerMap.get(key));
                } else if (httpObj instanceof HttpPost) {
                    ((HttpPost) httpObj).setHeader(key, headerMap.get(key));
                } else if (httpObj instanceof HttpPut) {
                    ((HttpPut) httpObj).setHeader(key, headerMap.get(key));
                } else if (httpObj instanceof HttpDelete) {
                    ((HttpDelete) httpObj).setHeader(key, headerMap.get(key));
                }
            }
        }
    }

    private static SSLContext getSSLContext() {
        SSLContext sslContext = null;
        try {
            sslContext = SSLContextBuilder.create().setProtocol(SSLConnectionSocketFactory.SSL)
                    .loadTrustMaterial((x, y) -> true).build();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        }
        return sslContext;
    }

    private static HttpClient getHttpClient() {
        HttpClient httpClient = HttpClientBuilder.create().setSSLContext(getSSLContext()).setSSLHostnameVerifier((x, y) -> true).build();
        return httpClient;
    }

    private static void setHttpGetHeader(HttpGet httpGet, Map<String, String> headerMap) {
        if (isVaildMap(headerMap)) {
            for (String key : headerMap.keySet()) {
                httpGet.setHeader(key, headerMap.get(key));
            }
        }
    }

    private static RequestConfig setConfig() {
        RequestConfig config = RequestConfig.custom()
                .setConnectTimeout(1000 * 3)
                .setConnectionRequestTimeout(1000 * 3)
                .setSocketTimeout(1000 * 3)
                .build();
        return config;
    }

    private static void setHttpPostHeader(HttpPost httpPost, Map<String, String> headerMap) {
        if (isVaildMap(headerMap)) {
            for (String key : headerMap.keySet()) {
                httpPost.setHeader(key, headerMap.get(key));
            }
        }
    }

    private static void setHttpPuttHeader(HttpPut httpPut, Map<String, String> headerMap) {
        if (isVaildMap(headerMap)) {
            for (String key : headerMap.keySet()) {
                httpPut.setHeader(key, headerMap.get(key));
            }
        }
    }
}
