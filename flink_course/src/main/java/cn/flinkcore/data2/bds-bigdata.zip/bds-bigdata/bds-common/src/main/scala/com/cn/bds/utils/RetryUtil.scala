package com.cn.bds.utils

import scala.util.{Failure, Success, Try}

object RetryUtil {
  private val className = getClass.getSimpleName

  /**
   * 递归实现Retry
   *
   * @param times   重试次数, 默认5次
   * @param delay   重试延迟, 默认5秒
   * @param any     需要重试的任何函数
   * @param anyFail 任何函数 -> 失败时额外调用，默认可以不传
   * @return 传入的对象的执行结果
   */
  def retry[A](times: Int = 5, delay: Long = 5000)(any: => A, anyFail: => A = null): A = {
    Try(any) match {
      case Success(v) =>
        println(s"[$className] Success: left $times times")
        v
      case Failure(e) =>
        println(s"[$className] Failure: left $times times")
        anyFail
        if (times > 0) {
          println(e)
          Thread.sleep(delay)
          retry(times - 1, delay)(any, anyFail)
        } else throw e
    }
  }



  def main(args: Array[String]): Unit = {
    // 方式一
    //    RetryUtil.retry()(1 / 0)

    //    // 方式二
    //    lazy val a = 2 / 0
    //    RetryUtil.retry()(a)
    //
    //    // 方式三
    //    val value: Any = RetryUtil.retry()(hello())
    //    println("value:"+value)
    //    // 其他……
    val bb=   RetryUtil.retry() {
      hello()
    }
    println("bb:"+bb)
  }

  def hello(): Int = {
    3 / 1
  }

}
