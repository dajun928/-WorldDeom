package com.cn.bds.utils

import com.alibaba.fastjson.JSON
import com.alibaba.fastjson.serializer.SerializerFeature
import com.cn.bds.kafka.KafkaSink
import com.cn.jbds.warn.BaseRestJson
import org.apache.commons.lang3.StringUtils
import org.apache.spark.broadcast.Broadcast

object BuildSendWarning {

  def builder(): Builder = new Builder


  class Builder {
    var restInfo = new BaseRestJson

    def setWarningId(id: String): Builder = {
      restInfo.setWarnId(id)
      this
    }

    def setWarningTime(time: String): Builder = {
      restInfo.setWarnTime(time)
      this
    }

    def setWarningPeople(people: String): Builder = {
      restInfo.setWarnPeople(people)
      this
    }

    def sendWarningToKafka(topicName:String,produce:Broadcast[KafkaSink[String,String]]): Unit ={

//        if(restInfo!=null && StringUtils.isNotEmpty(topicName)){
//          val conent=JSON.toJSONString(restInfo,SerializerFeature.PrettyFormat)
//          produce.value.sendValue(topicName,conent)
//       }

      val conent=JSON.toJSONString(restInfo,SerializerFeature.PrettyFormat)
     println("conent:"+conent)
    }


  }
}
