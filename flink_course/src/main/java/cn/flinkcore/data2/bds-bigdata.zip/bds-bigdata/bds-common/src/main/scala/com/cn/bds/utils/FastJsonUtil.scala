package com.cn.bds.utils

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject, JSONValidator}
import com.alibaba.fastjson.annotation.JSONField
import com.alibaba.fastjson.serializer.SerializerFeature
import org.apache.spark.sql.types.ArrayType

import java.util
import scala.beans.BeanProperty
import scala.collection.JavaConversions.asScalaBuffer
import scala.collection.mutable.ArrayBuffer

object FastJsonUtil {

  def main(args: Array[String]): Unit = {
    //    toJavaObject()

    //    var reg:String = "(aa"
    //    reg= reg.replaceAll("\\(","\\\\(")
    //
    //    if ("aa(".matches(reg)) {
    //      println("true")
    //    }
    //    parseArray()
    val arr=  "a,b"
    //   val nObject = toJson("a-a,b-b")("a","b")
    //    println("aa:"+nObject)
  }

  def toJson(keyStr:String,valueObj:Object*): String = {
    val json=new JSONObject(true)
    val fieldArray = keyStr.split(",")
    for (i <- 0 until fieldArray.length){
      json.put(fieldArray(i),valueObj(i))
    }
    json.toJSONString()
    toJsonStr(json)
  }

  def toJsonArrayStr(strArr:Array[String]): String = {
    val jsonArray=new JSONArray()
    strArr.foreach(data=>{
      jsonArray.add(data)
    })
    toJsonStr(jsonArray)
  }
  def toJsonArray(strArr:String): Array[String] = {
    val array: JSONArray = JSON.parseArray(strArr)
    val arrayBuffer=new ArrayBuffer[String]()
    array.foreach(data=>{
      arrayBuffer.append(data.toString)

    })
    arrayBuffer.toArray
  }

  def toJsonArray2(splitStr:String,str:String): String = {
    val jsonArray=new JSONArray()
    val strArr = str.split(splitStr)
    strArr.foreach(data=>{
      jsonArray.add(data)
    })
    jsonArray.toJSONString
  }

  def toJson22(keyStr:String,valueObj:Object*): String = {
    val json=new JSONObject(true)
    val fieldArray = keyStr.split(",")
    for (i <- 0 until fieldArray.length){
      val value=  valueObj(i)

      if(value.isInstanceOf[ArrayType]){
        println("type is array")
        json.put(fieldArray(i),value.asInstanceOf[ArrayType])
      }else{
        println("type is not array")
        json.put(fieldArray(i),valueObj(i))
      }
    }
    json.toJSONString
  }

  //  def toJson2(fieldStr:String)(obj:Object*): String = {
  //    toJson(fieldStr,obj)
  //  }

  def toJson1(a:String): String = {
    val json=new JSONObject(true)
    json.put("a","a1")
    json.put("c","c1")
    json.put("b","b1")
    json.toJSONString
  }

  def isValidJson(jsonStr: String): Boolean = {
    JSONValidator.from(jsonStr).validate()
  }

  def toJsonStr(any: Object) = {
    val str: String = JSON.toJSONString(any,
      SerializerFeature.PrettyFormat
    )
    str
  }

  def parseArray(): Unit = {
    val aList = new util.ArrayList[JSONObject]()
    val json = new JSONObject()
    json.put("a_a", "aa")
    json.put("b_b", "bb")
    aList.add(json)
    println("aList:" + aList)
    println("aList2:" + toJsonStr(aList))
    val list: util.List[AA] = JSON.parseArray(toJsonStr(aList), classOf[AA])
    for (a <- list) {
      val aa: String = a.aa
      val bb: String = a.bb
      println("aa:" + aa)
      println("bb:" + bb)
    }
  }


}


case class AA(
               @BeanProperty @JSONField(name = "a_a") var aa: String,
               @BeanProperty @JSONField(name = "b_b") var bb: String
             )
