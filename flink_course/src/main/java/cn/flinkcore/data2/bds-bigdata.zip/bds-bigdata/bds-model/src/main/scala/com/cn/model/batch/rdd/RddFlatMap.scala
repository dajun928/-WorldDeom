package com.cn.model.batch.rdd

import com.cn.bds.model.SparkModel
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object RddFlatMap {
  val logger: Logger = LogManager.getLogger(this.getClass)
  val appName = "RddFlatMapDemo"

  def main(args: Array[String]): Unit = {
    val sm = new SparkModel(args, appName, null)
    val sparkSession: SparkSession = sm.getSparkSession()
    val sparkContext: SparkContext = sparkSession.sparkContext
    run(sparkSession, sparkContext)
    sparkContext.stop()
    sparkSession.stop()
  }

  def run(sparkSession: SparkSession, sparkContext: SparkContext): Unit = {
    import sparkSession.implicits._
    val list1 = List(List("ab", "bc"),List("ab", "bc"))

    val value: RDD[List[String]] = sparkContext.parallelize(list1)
    value.toDF().show()
    val list = List("a,b", "b,c")
    val rdd: RDD[String] = sparkContext.parallelize(list)
    val rddArr: RDD[Array[String]] = rdd.map(line => {
      val array: Array[String] = line.split(",")
      array
    })
    rddArr.foreach(arr => {
      arr.foreach(println(_))

    })
    logger.warn("=====================")
    val rddStr: RDD[String] = rdd.flatMap(line => {
      val arr: Array[String] = line.split(",")
      arr
    })
    rddStr.foreach(println(_))
  }
}
