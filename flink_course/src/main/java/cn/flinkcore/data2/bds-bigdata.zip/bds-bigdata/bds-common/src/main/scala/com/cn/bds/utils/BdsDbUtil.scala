package com.cn.bds.utils

import com.cn.bds.config.ProFilesUtil
import org.apache.commons.lang3.StringUtils

import java.sql.{Connection, DriverManager}

object BdsDbUtil {
  val MYSQL_DRIVER = ProFilesUtil.getYml("mysql.driver")
  initMysqlDriver()

  def main(args: Array[String]): Unit = {
    val str: String = getInsertOrUpdateSql("aa", Array("a", "b", "c"))
    println("str:" + str)

    val str2: String = getInsertOrUpdateSql("aa", Array("a", "b", "c"), Option(Array("a")))
    println("str2:" + str2)

    println("MYSQL_DRIVER:" + MYSQL_DRIVER)

  }

  def initMysqlDriver(): Unit = {
    //注册数据库驱动
    try {
      Class.forName(MYSQL_DRIVER).newInstance()
    } catch {
      case ex: Exception => {

      }
    } finally {

    }
  }

  //数据库url
  def getDbUrl(ip: String, dbName: String, port: Int = 3306): String = {
    val initUrl = ip + ":" + port.toString + "/" + dbName
    val dbUrl = "jdbc:mysql://" + initUrl + "?useUnicode=true&characterEncoding=UTF-8&rewriteBatchedStatements=true" +
      "&serverTimezone=UTC"
    dbUrl
  }

  def getDbConn(ip: String, dbName: String, port: Int, mysqlUserName: String, mysqlPw: String): Connection = {
    val dbUrl = getDbUrl(ip, dbName, port)
    DriverManager.getConnection(dbUrl, mysqlUserName, mysqlPw)
  }

  def closeConnect(closeable: AutoCloseable*): Unit = {
    for (connect <- closeable) {
      try {
        if (connect != null) {
          connect.close()
        }
      } catch {
        case e: Exception => println(e)
      } finally {
      }
    }
  }

  def getInsertOrUpdateSql(tableName: String, array: Array[String], updateArray: Option[Array[String]] = None): String = {
    val sb = new StringBuffer()
    if (StringUtils.isEmpty(tableName) || array.isEmpty) {
      throw new IllegalArgumentException
    }
    sb.append("insert into " + tableName + " (")
    sb.append(array.mkString(","))
    sb.append(") values(")
    array.indices.foreach(i => {
      if (i == array.length - 1) {
        sb.append("?)")
      } else {
        sb.append("?,")
      }
    })
    val updateCols: Array[String] = updateArray.getOrElse(null)
    if (updateCols != null && !updateCols.isEmpty) {
      sb.append(" ON DUPLICATE KEY UPDATE ")
      val indices = updateCols.indices
      for (i <- indices) {
        if (i == updateCols.length - 1) {
          sb.append(updateCols(i) + "=values(" + updateCols(i) + ")")
        } else {
          sb.append(updateCols(i) + "=values(" + updateCols(i) + ")" + ",")
        }
      }
    }
    sb.toString
  }

  def getInsertSqlStr(tableName: String, columnDataNames: Array[String]): String = {
    val sbStr = new StringBuilder(s"insert into $tableName")
    sbStr.append(s"(${columnDataNames.mkString(",")})")
    sbStr.append(" values(")
    for (index <- columnDataNames.indices) {
      sbStr.append("?,")
    }
    sbStr.delete(sbStr.length - 1, sbStr.length).append(")")
    sbStr.toString()
  }
}
