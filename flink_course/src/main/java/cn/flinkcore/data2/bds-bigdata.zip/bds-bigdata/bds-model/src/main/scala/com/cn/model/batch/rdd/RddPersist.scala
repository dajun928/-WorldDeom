package com.cn.model.batch.rdd

import com.cn.bds.model.SparkModel
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
 * 在一个数据集多次使用,使用 Persist(惰性算子)把数据缓存起来,否则会多次执行
 *
 */
object RddPersist {
  val logger: Logger = LogManager.getLogger(this.getClass)
  val appName = "RddFlatMapDemo"

  def main(args: Array[String]): Unit = {
    val sm = new SparkModel(args, appName, null)
    val sparkSession: SparkSession = sm.getSparkSession()
    val sparkContext: SparkContext = sparkSession.sparkContext
    run(sparkSession, sparkContext)
    sparkContext.stop()
    sparkSession.stop()

  }

  def run(sparkSession: SparkSession, sparkContext: SparkContext): Unit = {
    import sparkSession.implicits._
    val df = getDataFrame(sparkSession, sparkContext).toDF("a", "b")
    df.show(false)
    val rdd1 = df.rdd.mapPartitions(iter => {
      val array = new ArrayBuffer[(String, String)]()
      iter.foreach(data => {
        val a = data.getAs[String]("a")
        val b = data.getAs[String]("b")
        val node = (a, b)
        array += node
        println("******11111******")
      })
      array.toIterator
    })

    val kvRdd = rdd1.reduceByKey((value1, value2) => {
      if (value1 > value2) {
        value1
      } else {
        value2
      }
    })

    kvRdd.foreachPartition(iter=>{
      iter.foreach(data=>{
        println("=====data======"+data)
      })

    })
    // todo
    //    rdd1.persist(StorageLevel.MEMORY_AND_DISK)
    println("===============")
//    rdd1.foreach(println(_))
    //    rdd1.foreach(println(_))
  }

  def getDataFrame(sparkSession: SparkSession, sparkContext: SparkContext): DataFrame = {
    import sparkSession.implicits._
    // 数据表示:  类目id,商品id
    val list = List(
      ("1", "11"),
      ("1", "11"),
      ("1", "11"),
      ("3", "31")
    )
    val rdd: RDD[(String, String)] = sparkContext.parallelize(list)
    rdd.toDF()
  }
}
