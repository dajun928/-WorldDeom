package com.cn.model.batch.spark

import com.cn.bds.model.SparkModel
import org.apache.spark.sql.{DataFrame, SparkSession}

object CreateDf {
  def main(args: Array[String]): Unit = {

    val sparkModel = new SparkModel(args, "Demo", null)
    val sparkSession = sparkModel.getSparkSession()
//    val test1 = sparkModel.getUserParamsVal("test1", "")
//    val test2 = sparkModel.getUserParamsVal("test2", "")
//    println("test1:" + test1)
//    println("test2:" + test2)
//    val session = sparkModel.getSparkSession()
//    val list = List(
//      ("a1", "b1"),
//      ("a1", "b1"),
//      ("a2", "b2")
//    )
//    val frame = session.createDataFrame(list).toDF("aa", "bb")
//    frame.show(false)

   val df= getDf(sparkSession)
    df.show(false)
    df.createOrReplaceTempView("df")
 val resDf=   sparkSession.sql(
      s"""
         |select
         | row_number()over(PARTITION by name order by age1 desc) rn,
         |t.*
         |from
         |df t
         |where age2!='cc'
         |""".stripMargin)
    resDf.show(false)
    sparkSession.stop()
  }


  def getDf(ss: SparkSession): DataFrame = {
    import ss.implicits._
    val list: Seq[(String, String, Int, String)] = List(
      ("1", "a", 1, "c"),
      ("1", "a", 2, "c"),
      ("1", "a", 3, "cc"),
      ("1", "b", 1, "c"),
      ("2", "b", 0, "c")
    )
    ss.createDataset(list).toDF("id", "name", "age1", "age2")
  }

}
