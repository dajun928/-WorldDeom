//package com.cn.jbds.utils
//
//import com.alibaba.fastjson.{JSONArray, JSONObject}
//import com.jayway.jsonpath.{JsonPath, Predicate}
//
///**
// * 参考: https://blog.51cto.com/u_10980859/5304466
// *
// */
//object JaywayJsonUtil {
//
//  def main(args: Array[String]): Unit = {
////    val dataJson = getData()
////    println("dataJson:" + dataJson.toJSONString)
////    redeData(dataJson.toString,null)
//
//
//    val code: Int ="aaa".hashCode
//  }
//
//  def  redeData(data:String, filters: Predicate): Unit ={
//  val elem=  JsonPath.read(data.toString,"$['store']['book'][1]['author']")
//
//    println("elem:" + elem)
//
//  }
//
//
//  def getData(): JSONObject = {
//
//    val bicycle = new JSONObject()
//    bicycle.put("color", "red")
//    bicycle.put("price", 19.95)
//
//    val bookJson1 = new JSONObject()
//    bookJson1.put("author", "Nigel Rees")
//    bookJson1.put("category", "reference")
//    bookJson1.put("price", 8.95)
//    bookJson1.put("title", "Sayings of the Century")
//
//    val bookJson2 = new JSONObject()
//    bookJson2.put("author", "Evelyn Waugh")
//    bookJson2.put("category", "fiction")
//    bookJson2.put("isbn", "0-553-21311-3")
//    bookJson2.put("price", 12.99)
//    bookJson2.put("title", "Sword of Honour")
//
//    val array = new JSONArray()
//    array.add(bookJson1)
//    array.add(bookJson2)
//
//    val store = new JSONObject()
//    store.put("bicycle", bicycle)
//    store.put("book", array)
//
//    val result = new JSONObject()
//    result.put("store", store)
//    result
//  }
//
//
//}
