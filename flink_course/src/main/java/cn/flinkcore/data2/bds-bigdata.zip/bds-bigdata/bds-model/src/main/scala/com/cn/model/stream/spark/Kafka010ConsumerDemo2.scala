package com.cn.model.stream.spark

import com.alibaba.fastjson.annotation.JSONField
import com.alibaba.fastjson.{JSON, JSONValidator}
import com.cn.bds.config.{ProFilesUtil, UserConfigUtil}
import com.cn.bds.kafka.SaveKafkaOffsetUtil
import com.cn.bds.model.{DataFrameUtil, SparkModel}
import com.cn.bds.utils.BaseUtil
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.TopicPartition
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka010.{HasOffsetRanges, OffsetRange}

import scala.beans.BeanProperty
import scala.collection.mutable.ArrayBuffer

object Kafka010ConsumerDemo2 {
  val logger: Logger = LogManager.getLogger(this.getClass)
  val saveOffsetType = "kafka"
  val groupId = "test1-1127"
  val srcTopicName = "test_z"
  val topicSet = Set(srcTopicName)

  def main(args: Array[String]): Unit = {
    val sm: SparkModel = new SparkModel(args,"", null)
    val bootstrapServers: String = ProFilesUtil.getYml("kafka.bootstrap_servers")
    logger.info("start bootstrapServers is:{}",bootstrapServers)
    val spark: SparkSession = sm.getSparkSession()
    import spark.implicits._
    val ssc: StreamingContext = sm.getStreamingContext(spark.sparkContext)
    val localMysqlPro = UserConfigUtil.getlocalMysqlPro()
    val sqlStr = "select * from t_df1"
    val frame: DataFrame = DataFrameUtil.dbData2Df(spark, sqlStr, localMysqlPro)
    frame.show()

    val kafkaParams: Map[String, Object] = UserConfigUtil.getKafkaConsumerParamsMap(groupId,"earliest") // earliest

    val inputDStream: InputDStream[ConsumerRecord[String, String]] = SaveKafkaOffsetUtil.getDirectStreamFromOffset(ssc,kafkaParams, topicSet, true, saveOffsetType)
    // 初始化变量
    val emptyDataFrame: DataFrame = spark.emptyDataFrame
    val currentTime: Long = System.currentTimeMillis()
    var df1 = emptyDataFrame
    var df1CurrentTime = currentTime
    val initIsUpdate = false
    inputDStream.foreachRDD(kafkaRdd => {
      val df1Tuple: (DataFrame, Long, Boolean) = sm.getDbData2DfByTime(spark, "select * from t_df1", localMysqlPro,
        (df1, df1CurrentTime, initIsUpdate), 8)
      df1Tuple._1.show()
      // 过滤非json的数据
      val validRdd: RDD[String] = kafkaRdd.filter(record => JSONValidator.from(record.value).validate()).map(record => record.value)
      logger.info("validRdd count is:{}",validRdd.count())
      // offset 处理,注意rdd必须是，考虑封装
      if (!validRdd.isEmpty()) {
        // vo类型
        val mapRddVo: RDD[AVo] = validRdd.mapPartitions(part => {
          // todo 连接hbase  或者mysql数据库补充信息，过滤操作
          val array = new ArrayBuffer[AVo]()
          part.foreach(row => {
            val vo: AVo = JSON.parseObject(row, classOf[AVo])
            val id: String = BaseUtil.isEmptyAs(vo.getId)
            var age = 10
            if (id.toInt == 7) {
              age = 7
            }
            vo.setAge(age)
            array.append(vo)
          })
          // todo 关闭数据库连接信息
          // 最后返回数据
          array.toIterator
        })

        mapRddVo.toDF().show(false)

        val offsetRanges: Array[OffsetRange] = kafkaRdd.asInstanceOf[HasOffsetRanges].offsetRanges
        for (offsetRange <- offsetRanges) {
          val topic: String = offsetRange.topic
          val partition: Int = offsetRange.partition
          val fromOffset: Long = offsetRange.fromOffset
          val untilOffset: Long = offsetRange.untilOffset
          val topicPartition: TopicPartition = offsetRange.topicPartition()
          //          logger.info("topic is:{}",topic)
          //          logger.info("partition is:{}",partition)
          //          logger.info("fromOffset is:{}",fromOffset)
          //          logger.info("untilOffset is:{}",untilOffset)
          //          logger.info("topicPartition is:{}",topicPartition)
        }
      }
      SaveKafkaOffsetUtil.saveKafkaOffSet(inputDStream,kafkaRdd, groupId, saveOffsetType)
    })
    ssc.start()
    ssc.awaitTermination()
  }
}

case class AVo(
                @BeanProperty @JSONField(name = "aa") var id: String,
                @BeanProperty @JSONField(name = "bb") var name: String,
                @BeanProperty @JSONField(name = "c_c") var age: Int
              )
