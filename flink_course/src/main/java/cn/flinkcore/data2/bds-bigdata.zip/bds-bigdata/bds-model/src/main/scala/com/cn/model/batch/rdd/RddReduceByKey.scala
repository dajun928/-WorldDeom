package com.cn.model.batch.rdd

import com.cn.bds.model.SparkModel
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.SparkContext
import org.apache.spark.api.java.JavaRDD
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

import scala.collection.immutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}

/**
 * 案例:https://blog.csdn.net/qq_37554565/article/details/105594430
 *
 */
object RddReduceByKey {
  val logger: Logger = LogManager.getLogger(this.getClass)
  val appName = "RddReduceByKey"

  def main(args: Array[String]): Unit = {
    val sm = new SparkModel(args, appName, null)
    val sparkSession: SparkSession = sm.getSparkSession()
    val sparkContext: SparkContext = sparkSession.sparkContext
    runReduceByKey(sparkSession, sparkContext)
    sparkContext.stop()
    sparkSession.stop()
  }

  def runReduceByKey(sparkSession: SparkSession, sparkContext: SparkContext): Unit = {
    import sparkSession.implicits._
    val dataFrame = getDataFrame(sparkSession, sparkContext)
    dataFrame.show()
    // 功能1
    val resultDf1: RDD[(String, String, Int)] = fun1(dataFrame)
    resultDf1.toDF().show()
    fun2(resultDf1)

  }

  def fun3(rdd: RDD[(String, String, Int)]): Unit = {

    val aa: RDD[(String, (String, Int, Int))] = rdd.map(x => (x._1, (x._2, x._3, x._3)))


    val data: RDD[((String, String), (String, Int))] = rdd.mapPartitions(iter => {
      val array = new ArrayBuffer[((String, String), (String, Int))]()
      iter.foreach(data => {
        val data = (("a", "b"), ("a", 1))
        array += data
      })
      array.toIterator
    })

    val data11: RDD[((String, String), (String, Int))] = rdd.mapPartitions(iter => {
      var map = Map[(String, String), (String, Int)]()
      iter.foreach(data => {
        val data = (("a", "b"), ("a", 1))
        map+=(("a", "b")-> ("a", 1))
      })
      map.toIterator
    })


 val data2: RDD[((String, String), (String, Int))] =   data.reduceByKey((value1, value2)=>{
      val v1 = value1._2
      val v2 = value2._2
      if(v1>v2){
        value1
      }else{
        value2
      }
    })

  }


  // 推荐2个销售最高的类目,并且推荐每个类目下销售最好的一个商品
  def fun2(rdd: RDD[(String, String, Int)]): Unit = {


    val resultRdd: Array[(String, String, Int, Int)] = rdd.map(x => (x._1, (x._2, x._3, x._3)))
      .reduceByKey((x, y) => if (x._2 > y._2) (x._1, x._2, x._3 + y._3) else (y._1, y._2, x._3 + y._3))

      .map(x => (x._1, x._2._1, x._2._2, x._2._3))
      .sortBy(_._3, false)
      .take(2)
    resultRdd.foreach(data => {
      logger.warn("res is:{}", data._1 + ":::" + data._2 + ":::" + data._3 + ":::" + data._4)
    })
  }

  // 需求1:统计每个类目id下,各个商品的销售量
  def fun1(dataFrame: DataFrame): RDD[(String, String, Int)] = {
    val resultRdd: RDD[(String, String, Int)] = dataFrame.rdd
      // 先使用map打标记
      .map(data => (data, 1))
      // 分组聚合
      .reduceByKey((x, y) => {
        x + y
      })
      // 再使用map格式下
      .map(data => {
        (data._1.getAs[String](0), data._1.getAs[String](1), data._2)
      })
    resultRdd
  }


  def getDataFrame(sparkSession: SparkSession, sparkContext: SparkContext): DataFrame = {
    import sparkSession.implicits._
    // 数据表示:  类目id,商品id
    val list = List(
      ("1", "11"),
      ("1", "11"),
      ("1", "11"),
      ("2", "21"),
      ("2", "21"),
      ("2", "21"),
      ("2", "21"),
      ("2", "22"),
      ("3", "31")
    )
    val rdd: RDD[(String, String)] = sparkContext.parallelize(list)
    rdd.toDF()
  }
}
