package com.cn.bds.kafka

import com.cn.bds.config.{ProFilesUtil, UserConfigUtil}
import com.cn.bds.hbase.HbaseTableSink
import com.cn.bds.utils.BdsDbUtil
import org.apache.hadoop.hbase.CompareOperator
import org.apache.hadoop.hbase.client.Table
import org.apache.hadoop.hbase.filter.{FilterList, SingleColumnValueFilter, SubstringComparator}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.kafka.clients.consumer.{ConsumerConfig, ConsumerRecord}
import org.apache.kafka.common.TopicPartition
import org.apache.logging.log4j.{LogManager, Logger}
import org.apache.spark.rdd.RDD
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010._

import java.util.Properties
import scala.collection.mutable.ListBuffer

/**
 * 功能:消费kafka数据，保存偏移量到hbase表中
 *
 */
object SaveKafkaOffsetUtil {
  val logger: Logger = LogManager.getLogger(this.getClass)
  //todo  此处的分割符与查询offset相关，慎重
  //  val DEF_SEPARATOR = "@#$"
  val DEF_SEPARATOR = "#"
  // 存储消费kafka偏移量的hbase表
  //  val defaultKafkaOffsetTable = "t_kafka_offset_record"
  private val defaultKafkaOffsetTable: String = ProFilesUtil.getYml("kafka.offset.table")

  val offset_table_family_field = "info"
  val offset_table_topic_field = "topic"
  val offset_table_group_id_field = "group_id"
  val offset_table_partition_field = "partition"
  val offset_table_offset_field = "offset"
  val offset_table_topic_partition_field = "topic_partition"


  /**
   * direct stream 方式读取kafka主题，可以自动从hbase记录的offset断点开始处理()
   *
   * @param ssc
   * @param kafkaParams
   * @param topics
   * @param forceInit 是否强制从kafka config初始化
   * @return
   */
  def getDirectStreamFromOffset(ssc: StreamingContext, kafkaParams: Map[String, Object], topics: Set[String]
                                , forceInit: Boolean = false, saveOffsetType: String = "kafka")
  : InputDStream[ConsumerRecord[String, String]] = {
    val groupId: String = kafkaParams.getOrElse(ConsumerConfig.GROUP_ID_CONFIG, "default").toString
    var fromOffsets: (Array[TopicPartition], Map[TopicPartition, Long]) = null
    val isSaveOffsetKafka: Boolean = saveOffsetType.equalsIgnoreCase("kafka")
    if (isSaveOffsetKafka || forceInit) {
      logger.info("isSaveOffsetKafka is :{}", isSaveOffsetKafka)
      logger.info("forceInit is :{}", forceInit)
    } else {
      fromOffsets = initKafkaOffSets(topics, groupId, saveOffsetType, offsetTable = defaultKafkaOffsetTable)
    }

    val inputDStream: InputDStream[ConsumerRecord[String, String]] = if (isSaveOffsetKafka || fromOffsets == null || forceInit) {
      logger.info("init input stream with kafka config")
      KafkaUtils.createDirectStream(ssc, PreferConsistent, Subscribe[String, String](topics, kafkaParams))
    } else {
      logger.info("init input stream with specified offset")
      val topicPartition: Array[TopicPartition] = fromOffsets._1
      val topicPartitionOffset: Map[TopicPartition, Long] = fromOffsets._2
      KafkaUtils.createDirectStream(ssc, PreferConsistent, ConsumerStrategies.Assign[String, String](topicPartition, kafkaParams, topicPartitionOffset))
    }
    inputDStream
  }


  private def initKafkaOffSets(topics: Set[String], groupId: String, saveOffsetType: String, offsetTable: String):
  (Array[TopicPartition], Map[TopicPartition, Long]) = {
    var offsetListMap: ListBuffer[Map[String, String]]= null
    if (saveOffsetType.equalsIgnoreCase("hbase")) {
      val hbaseConfigPro: Properties = UserConfigUtil.getHbaseConfigPro()
      val hbaseTableSink: HbaseTableSink = HbaseTableSink(hbaseConfigPro)
      offsetListMap = initKafkaOffSetsFromHbase(topics, groupId, hbaseTableSink, offsetTable)
    } else if (saveOffsetType.equalsIgnoreCase("mysql")) {
      null
    } else if (saveOffsetType.equalsIgnoreCase("kafka")) {
      null
    } else {
      null
    }

    // 遍历
    if (offsetListMap == null && offsetListMap.isEmpty) {
      null
    } else {
      val offsetListMapSize = offsetListMap.size
      logger.info("offsetListMapSize is :{}", offsetListMap.size)
      val topicPartitions = new ListBuffer[TopicPartition]
      var TopicPartitionOffsets: Map[TopicPartition, Long] = Map()
      offsetListMap.foreach(singleMap => {
        val topicStr: String = singleMap.getOrElse(offset_table_topic_field, "").toString
        val partitionInt: Int = singleMap.getOrElse(offset_table_partition_field, "0").toString.toInt
        val offsetLong: Long = singleMap.getOrElse(offset_table_offset_field, "0").toString.toLong
        val topicAndPartition: TopicPartition = new TopicPartition(topicStr, partitionInt)
        topicPartitions.append(topicAndPartition)
        TopicPartitionOffsets += (topicAndPartition -> offsetLong)
      })
      (topicPartitions.toArray, TopicPartitionOffsets)
    }
  }

  /**
   * 将offset保存到hbase，适合用在foreachRDD中，即一次保存所有分区的offset
   *
   * @param kafkaRdd
   * @param groupId
   */
  def saveKafkaOffSet(inputDStream: InputDStream[ConsumerRecord[String, String]], kafkaRdd: RDD[ConsumerRecord[String,
    String]], groupId: String, saveOffsetType: String, offsetTable: String = defaultKafkaOffsetTable)
  : Unit = {
    if (!kafkaRdd.isEmpty()) {
      if (saveOffsetType.equalsIgnoreCase("kafka")) {
        saveOffSetToKafka(inputDStream, kafkaRdd)
        return
      }

      val listBuffer: ListBuffer[Map[String, String]] = getOffsetListMap(kafkaRdd, groupId)
      if (saveOffsetType.equalsIgnoreCase("hbase")) {
        //        val hbaseConfig: Configuration = UserConfigUtils.getHbaseConfig()
        val hbaseConfigPro: Properties = UserConfigUtil.getHbaseConfigPro()
        val hbaseTableSink: HbaseTableSink = HbaseTableSink(hbaseConfigPro)
        val table: Table = hbaseTableSink.getTable(offsetTable)
        hbaseTableSink.insertDataList(table, offset_table_family_field, listBuffer, true)
      } else if (saveOffsetType.equalsIgnoreCase("mysql")) {
        ;
      } else {
        ;
      }
    }

  }


  def saveOffSetToKafka(inputDStream: InputDStream[ConsumerRecord[String, String]], kafkaRdd: RDD[ConsumerRecord[String,
    String]]): Unit = {
    val offsetRanges: Array[OffsetRange] = kafkaRdd.asInstanceOf[HasOffsetRanges].offsetRanges
    inputDStream.asInstanceOf[CanCommitOffsets].commitAsync(offsetRanges)
  }

  /**
   * 在hbase中查询offset记录，返回指定topics的offset对象
   *
   * @param topics
   * @param groupId
   * @return
   */
  private def initKafkaOffSetsFromHbase(topics: Set[String], groupId: String, hbaseTableSink: HbaseTableSink,
                                        offsetTable: String): ListBuffer[Map[String, String]] = {
    val resultListMap: ListBuffer[Map[String, String]] =ListBuffer[Map[String, String]]()
    val isCreateSuss: Boolean = hbaseTableSink.createTable(offsetTable, Array[String](offset_table_family_field), false)
    if (isCreateSuss) {
      // 创建成功说明之前没有表
      BdsDbUtil.closeConnect(hbaseTableSink.conn)
    } else {
      val table: Table = hbaseTableSink.getTable(offsetTable)
      for (topic <- topics) {
        val initRowKey = topic + DEF_SEPARATOR + groupId + DEF_SEPARATOR
        logger.info("initRowKey is:{}", initRowKey)
        val startRowValue = Option(initRowKey + "!")
        val endRowValue = Option(initRowKey + "~")
        val filterList = new FilterList
        val familyByte = Bytes.toBytes(offset_table_family_field)
        val topicByte = Bytes.toBytes(offset_table_topic_field)
        val topicColumnValueFilter = new SingleColumnValueFilter(familyByte, topicByte, CompareOperator.EQUAL, new SubstringComparator(topic))
        val groupIdColumnValueFilter = new SingleColumnValueFilter(familyByte, topicByte, CompareOperator.EQUAL, new SubstringComparator(groupId))
        filterList.addFilter(topicColumnValueFilter)
        filterList.addFilter(groupIdColumnValueFilter)

        val scanResultMap: Map[String, Map[String, String]] = hbaseTableSink.scanData(table, offset_table_family_field, Option(null), Option
        (filterList), startRow = startRowValue, endRow = endRowValue, isAutoClose = false)
        resultListMap.appendAll(scanResultMap.values.toList)
      }
      BdsDbUtil.closeConnect(table, hbaseTableSink.conn)
    }
    resultListMap
  }


  private def getOffsetListMap(kafkaRdd: RDD[ConsumerRecord[String, String]], groupId: String): ListBuffer[Map[String,
    String]] = {
    val listBuffer = new ListBuffer[Map[String, String]]
    val offsetRanges: Array[OffsetRange] = kafkaRdd.asInstanceOf[HasOffsetRanges].offsetRanges
    offsetRanges.foreach(offsetRange => {
      val topicName: String = offsetRange.topic
      val partitionInt: Int = offsetRange.partition
      val offsetLong: Long = offsetRange.untilOffset
      val topicPartition: TopicPartition = offsetRange.topicPartition()
      val rowkey = topicName + DEF_SEPARATOR + groupId + DEF_SEPARATOR + partitionInt
      var map: Map[String, String] = Map()
      map += ("rowkey" -> rowkey)
      map += (offset_table_topic_field -> topicName)
      map += (offset_table_group_id_field -> groupId)
      map += (offset_table_partition_field -> partitionInt.toString)
      map += (offset_table_offset_field -> offsetLong.toString)
      map += (offset_table_topic_partition_field -> topicPartition.toString)
      listBuffer.append(map)
    })
    listBuffer
  }

  /**
   * 订阅所有的partition数据
   *
   * @param ssc
   * @param topicArray
   * @param kafkaParams
   * @return
   */
  def getInputDStream(ssc: StreamingContext, topicArray: Array[String], kafkaParams: Map[String, Object]): InputDStream[ConsumerRecord[String, String]] = {
    KafkaUtils.createDirectStream(ssc, PreferConsistent, Subscribe[String, String](topicArray, kafkaParams))
  }

  /**
   * 订阅所有的 partition 数据,但是可以指定某些 partition 的 offset
   *
   * @param ssc
   * @param topicArray
   * @param kafkaParams
   * @param offsets
   * @return
   */
  def getInputDStream(ssc: StreamingContext, topicArray: Array[String], kafkaParams: Map[String, Object], offsets: Map[TopicPartition, Long]): InputDStream[ConsumerRecord[String, String]] = {
    KafkaUtils.createDirectStream(ssc, PreferConsistent, Subscribe[String, String](topicArray, kafkaParams, offsets))
  }

  def getInputDStream(ssc: StreamingContext, topicPartitions: Array[TopicPartition], kafkaParams: Map[String, Object], offsets: Map[TopicPartition, Long]): InputDStream[ConsumerRecord[String, String]] = {
    KafkaUtils.createDirectStream(ssc, PreferConsistent, ConsumerStrategies.Assign[String, String](topicPartitions, kafkaParams, offsets))
  }

  def commitOffset(stream: InputDStream[ConsumerRecord[String, String]], rdd: RDD[ConsumerRecord[String, String]]): Unit = {
    val ranges: Array[OffsetRange] = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
    stream.asInstanceOf[CanCommitOffsets].commitAsync(ranges)
  }
}
