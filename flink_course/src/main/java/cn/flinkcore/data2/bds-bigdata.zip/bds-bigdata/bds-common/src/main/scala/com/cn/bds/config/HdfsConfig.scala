package com.cn.bds.config

import org.apache.hadoop.conf.Configuration

class HdfsConfig(sink: HdfsConfigSink) extends Serializable {

  private val userConfiguration: Configuration = sink.getHdfsUserConfig()
  private val sysConfiguration: Configuration = sink.getHdfsSysConfig()

  def this(env: String) = {
    this(HdfsConfigSink(env))
  }

  def getZk(): String ={
    userConfiguration.get("mysql.user","test")

  }

}
