package com.cn.model.batch.spark

import com.alibaba.fastjson.{JSON, JSONObject}
import com.alibaba.fastjson.serializer.SerializerFeature
import com.cn.jbds.beans.{HbaseTableBean, UserBean}

object Bean {

  def main(args: Array[String]): Unit = {
   val userBean=new UserBean()
    userBean.setUserName("zhang")
    userBean.setUserVersion("v.1.2")

    val str1: String = JSON.toJSONString(userBean,
            SerializerFeature.WriteNullStringAsEmpty,
      SerializerFeature.WriteMapNullValue,
      SerializerFeature.WriteNullListAsEmpty,
      SerializerFeature.WriteSlashAsSpecial,
      SerializerFeature.PrettyFormat
    )
    println("str1:" + str1)

    val json=new JSONObject()
    json.put("userName","UU")
    json.put("user_Version","VV")

    val userBean2: UserBean = JSON.parseObject(json.toString, classOf[UserBean])
    val str2: String = JSON.toJSONString(userBean2,
      SerializerFeature.WriteNullStringAsEmpty,
      SerializerFeature.WriteMapNullValue,
      SerializerFeature.WriteNullListAsEmpty,
      SerializerFeature.WriteSlashAsSpecial,
      SerializerFeature.PrettyFormat
    )

    println("str2:" + str2)
    println("userBean2:" + userBean2)

  }

}
