package com.cn.bds.utils

import org.apache.commons.lang3.StringUtils

import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.{Calendar, Date}
import scala.collection.mutable.ArrayBuffer

object BdsDateTimeUtil {
  val ymdPattern = "yyyy-MM-dd"
  private val dateTimePattern = "yyyy-MM-dd HH:mm:ss"

  //  private val format: FastDateFormat = FastDateFormat.getInstance(ymdPattern)
  val patternArray = Array("yyyy-MM-dd'T'HH:mm:ss'Z'",
    "yyyy-MM-dd'T'HH:mm:ssZ",
    "yyyy-MM-dd'T'HH:mm:ss",
    "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
    "yyyy-MM-dd'T'HH:mm:ss.SSSZ",
    "yyyy-MM-dd HH:mm:ss",
    "yyyy-MM-dd HH:mm:ss.SSS",
    "MM/dd/yyyy HH:mm:ss",
    "MM/dd/yyyy'T'HH:mm:ss.SSS'Z'",
    "MM/dd/yyyy'T'HH:mm:ss.SSSZ",
    "MM/dd/yyyy'T'HH:mm:ss.SSS",
    "MM/dd/yyyy'T'HH:mm:ssZ",
    "MM/dd/yyyy'T'HH:mm:ss",
    "yyyy:MM:dd HH:mm:ss",
    "yyyyMMdd")


  def main(args: Array[String]): Unit = {
    println("hahahhhhhh")
    //    val aa = getBefHour(ymdh_pattern, -2)
    //    println("aa:" + aa)
    //    val stamp: Long = date2Stamp("2021-02-21 12:12:12.30")
    //    println("stamp:" + stamp)
    //
    //    val str: String = stamp2Date(stamp.toString)
    //    println("str:" + str)
    //
    //    val str1: String = dateAddOffsetMin(str, 1)
    //    val str2: String = dateSubOffsetMin(str, 1)
    //    println("str1:" + str1)
    //    println("str2:" + str2)
    val myDate = "2021-02-20 12:12:12.30"
    //    val myDate = "0"
    println("new:y:" + offsetDate(-1, "y", Option(myDate)))
    println("new:y:" + offsetDate(1, "y", Option(myDate)))
    println("new:y:" + offsetDate(-1, "y"))
    println("new:y:" + offsetDate(1, "y"))
    println("===================")
    println("new:M:" + offsetDate(-1, "M", Option(myDate)))
    println("new:M:" + offsetDate(1, "M", Option(myDate)))
    println("new:M:" + offsetDate(-1, "M"))
    println("new:M:" + offsetDate(1, "M"))
    println("===================")
    println("new:d:" + offsetDate(-1, "d", Option(myDate)))
    println("new:d:" + offsetDate(1, "d", Option(myDate)))
    println("new:d:" + offsetDate(-1, "d"))
    println("new:d:" + offsetDate(1, "d"))
    println("===================")
    println("new:H:" + offsetDate(-1, "H", Option(myDate)))
    println("new:H:" + offsetDate(1, "H", Option(myDate)))
    println("new:H:" + offsetDate(-1, "H"))
    println("new:H:" + offsetDate(1, "H"))
    println("===================")
    println("new:m:" + offsetDate(-1, "m", Option(myDate)))
    println("new:m:" + offsetDate(1, "m", Option(myDate)))
    println("new:m:" + offsetDate(-1, "m"))
    println("new:m:" + offsetDate(1, "m"))
    println("===================")
    println("new:s:" + offsetDate(-1, "s", Option(myDate)))
    println("new:s:" + offsetDate(1, "s", Option(myDate)))
    println("now:" + getNowDateTime())
    println("new:s:" + offsetDate(-1, "s"))
    println("new:s:" + offsetDate(1, "ss"))
    println("new:s:" + offsetDate(0, "w"))
    println("new:s:" + offsetDate(0))

    val long: Long = date2Stamp(getNowDateTime())
    println("long:" + long)
    //    println("heihei:" + myParse("2021-02-21 12:12:12.30"))


    val arr: ArrayBuffer[String] = getBetweenDay("2021-02-20  00", "2021-02-21  00", "HH", "yyyy-MM-dd HH")
    arr.foreach(println(_))
    println(Int.MaxValue)
    println(Long.MaxValue)
    println(date2Stamp("2021-05-20 12:12:12"))
    println(reverseDate("2021-05-20 12:12:12"))

    val dateId = getDateId("2022-05-20 12:12:12", "yyyyMMdd")
    println("dateId:" + dateId)


    val aa=date2Stamp("2021-01","qq")
    println("aa:" + aa)
  }


  /**
   *
   * @param startDate
   * @param endDate
   * @return
   */
  def compareTime(startDate: String, endDate: String): Long = {
    0L
  }

  /**
   *
   * @param pattern
   * @return
   */
  def getNowDateTime(pattern: String = dateTimePattern): String = {
    getSimpleDateFormat(pattern).format(new Date)
  }

  def getNowDateTime2(pattern: String = dateTimePattern): String ={
    LocalDateTime.now().format(DateTimeFormatter.ofPattern(pattern))
  }

  /**
   *
   * @param date
   * @param pattern
   * @return
   */
  def date2Stamp(date: String, pattern: String = dateTimePattern): Long = {
    val sdf: SimpleDateFormat = getSimpleDateFormat(pattern)
    try {
      sdf.parse(date).getTime()
    } catch {
      case e: Exception => 0
    }
  }

  /**
   *
   * @param stamp
   * @param pattern
   * @return
   */
  def stamp2DateStr(stamp: Long, pattern: String = dateTimePattern): String = {
    val stampLong = new java.lang.Long(stamp)
    val date: Date = new Date(stampLong)
    try {
      getSimpleDateFormat(pattern).format(date)
    } catch {
      case e: Exception => ""
    }
  }

  def reverseDate(date: String, pattern: String = dateTimePattern): Long = {
    Long.MaxValue - date2Stamp(date, pattern)
  }

  def getDateId(dateParams: String, pattern: String = "yyyyMMdd"): Int = {
    val sDate: String = BaseUtil.isEmptyAs(dateParams)
    if (sDate.length > pattern.length) {
      val date: Date = getSimpleDateFormat(pattern).parse(sDate)
      getSimpleDateFormat(pattern).format(date).toInt
    } else {
      0
    }

  }

  /**
   *
   * @param pattern
   * @return
   */
  def getSimpleDateFormat(pattern: String = dateTimePattern): SimpleDateFormat = {
    var sdf:SimpleDateFormat=null
    try {
      sdf=  new SimpleDateFormat(pattern)
    } catch {
      case e: Exception => println(e)
    }
    sdf
  }

  /**
   *
   * @param offset
   * @param offsetType
   * @param dateParams
   * @param pattern
   * @return
   */
  def offsetDate(offset: Int, offsetType: String = "ss", dateParams: Option[String] = None, pattern: String = dateTimePattern): String = {
    val sdf = getSimpleDateFormat(pattern)
    val cal = Calendar.getInstance()
    var date = dateParams.getOrElse("")
    if (StringUtils.isNotEmpty(date)) {
      date = dateParams.get
    } else {
      date = getNowDateTime(pattern)
    }
    try {
      cal.setTime(sdf.parse(date))
    } catch {
      case ex: Exception => ex.printStackTrace()
    }
    offsetCalendar(cal, offsetType, offset)
    sdf.format(cal.getTime())
  }

  def getBetweenDay(startTime: String, endTime: String, offsetType: String = "dd", pattern: String = ymdPattern): ArrayBuffer[String] = {
    val arrayBuffer = ArrayBuffer[String]()
    val sdf: SimpleDateFormat = getSimpleDateFormat(pattern)
    val d1: Date = sdf.parse(startTime)
    val d2: Date = sdf.parse(endTime)
    val calendar: Calendar = Calendar.getInstance(); //定义日期实例
    arrayBuffer.append(sdf.format(d1))
    calendar.setTime(d1); //设置日期起始时间
    while (calendar.getTime.before(d2)) {
      offsetCalendar(calendar, offsetType, 1)
      arrayBuffer.append(sdf.format(calendar.getTime()))
    }
    arrayBuffer
  }

  private def offsetCalendar(cal: Calendar, offsetType: String, offset: Int): Unit = {
    if (offsetType.startsWith("y")) {
      cal.add(Calendar.YEAR, offset)
    } else if (offsetType.startsWith("M")) {
      cal.add(Calendar.MONTH, offset)
    } else if (offsetType.startsWith("d")) {
      cal.add(Calendar.DATE, offset)
    } else if (offsetType.startsWith("H")) {
      cal.add(Calendar.HOUR, offset)
    } else if (offsetType.startsWith("m")) {
      cal.add(Calendar.MINUTE, offset)
    } else if (offsetType.startsWith("s")) {
      cal.add(Calendar.SECOND, offset)
    } else if (offsetType.startsWith("w")) {
      cal.add(Calendar.WEDNESDAY, offset)
    } else if (offset == 0) {
      cal.add(Calendar.SECOND, 0)
    } else {
      throw new IllegalArgumentException
    }
  }

  def getDateTimeWithMin(dateStr:String): String ={
    if(StringUtils.isNotEmpty(dateStr) && dateStr.length<12){
      dateStr.replaceAll(" +","")+ " 00:00:00"
    }else{
      dateStr
    }
  }

  def getDateTimeWithMax(dateStr:String): String ={
    if(StringUtils.isNotEmpty(dateStr) && dateStr.length<12){
      dateStr.replaceAll(" +","")+ " 23:59:59"
    }else{
      dateStr
    }
  }

}
